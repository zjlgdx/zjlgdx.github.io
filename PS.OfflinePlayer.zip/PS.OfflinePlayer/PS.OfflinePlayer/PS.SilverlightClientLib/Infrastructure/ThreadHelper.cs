﻿namespace PS.SilverlightClientLib.Infrastructure
{
    using System;

    internal class ThreadHelper
    {
        #region Fields

        [ThreadStatic]
        private static bool IsModelThread;

        #endregion Fields

        #region Methods

        public static void MarkThisThreadAsTheModelThread()
        {
            IsModelThread = true;
        }

        public static void ThrowIfNotModelThread()
        {
            if (!IsModelThread)
            {
                throw new InvalidOperationException("Expected to be running on the model thread.");
            }
        }

        #endregion Methods
    }
}