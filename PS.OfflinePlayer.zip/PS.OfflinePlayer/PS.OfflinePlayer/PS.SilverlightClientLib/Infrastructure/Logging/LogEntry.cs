﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;
    using System.Collections.Generic;

    internal class LogEntry
    {
        #region Fields

        public readonly System.Exception Exception;
        public readonly PS.SilverlightClientLib.Infrastructure.Logging.LogLevel Level;
        public readonly string Message;
        public readonly Dictionary<string, object> Properties;
        public readonly DateTime TimeStampUtc = DateTime.UtcNow;

        #endregion Fields

        #region Constructors

        public LogEntry(PS.SilverlightClientLib.Infrastructure.Logging.LogLevel level, string message, System.Exception exception, Dictionary<string, object> properties)
        {
            this.Level = level;
            this.Message = message;
            this.Exception = exception;
            this.Properties = properties;
        }

        #endregion Constructors
    }
}