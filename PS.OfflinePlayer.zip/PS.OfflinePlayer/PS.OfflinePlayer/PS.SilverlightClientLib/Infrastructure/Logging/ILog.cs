﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public interface ILog
    {
        #region Methods

        void Debug(string message, Exception exception = null, Dictionary<string, object> properties = null);

        void Error(string message, Exception exception = null, Dictionary<string, object> properties = null);

        void Fatal(string message, Exception exception = null, Dictionary<string, object> properties = null);

        void Info(string message, Exception exception = null, Dictionary<string, object> properties = null);

        void Warn(string message, Exception exception = null, Dictionary<string, object> properties = null);

        #endregion Methods
    }
}