﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;

    public static class LogManager
    {
        #region Fields

        private static readonly ILogEntryFormatter logEntryFormatter = new DefaultLogEntryFormatter();
        private static readonly ILogStrategy logStrategy = new DefaultLogStrategy();

        #endregion Fields

        #region Methods

        public static ILog GetLogger(Type type)
        {
            return new Logger(logEntryFormatter, logStrategy);
        }

        public static void Initialize(string logFilePath)
        {
            DefaultLogStrategy.Initialize(logFilePath);
        }

        #endregion Methods
    }
}