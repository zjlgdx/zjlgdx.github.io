﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public static class ILogExtensions
    {
        #region Methods

        public static void Debug(this ILog log, Exception x, Dictionary<string, object> properties = null)
        {
            log.Debug("", x, properties);
        }

        public static void Error(this ILog log, Exception x, Dictionary<string, object> properties = null)
        {
            log.Error("", x, properties);
        }

        public static void Fatal(this ILog log, Exception x, Dictionary<string, object> properties = null)
        {
            log.Fatal("", x, properties);
        }

        public static void Info(this ILog log, Exception x, Dictionary<string, object> properties = null)
        {
            log.Info("", x, properties);
        }

        public static void Warn(this ILog log, Exception x, Dictionary<string, object> properties = null)
        {
            log.Warn("", x, properties);
        }

        #endregion Methods
    }
}