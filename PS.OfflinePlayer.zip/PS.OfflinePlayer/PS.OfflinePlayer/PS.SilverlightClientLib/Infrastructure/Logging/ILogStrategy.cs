﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;

    internal interface ILogStrategy
    {
        #region Methods

        void Log(string formattedLogEntry);

        #endregion Methods
    }
}