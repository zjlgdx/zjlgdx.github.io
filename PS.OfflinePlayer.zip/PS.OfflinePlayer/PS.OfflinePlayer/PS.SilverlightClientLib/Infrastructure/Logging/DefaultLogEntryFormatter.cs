﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    using PS.SilverlightClientLib.Infrastructure.Shared;

    internal class DefaultLogEntryFormatter : ILogEntryFormatter
    {
        #region Fields

        private const string EmptyFieldPlaceholder = "-";

        #endregion Fields

        #region Methods

        public string FormatLogEntry(LogEntry logEntry)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("{0} ", new object[] { this.FormatTimeStamp(logEntry.TimeStampUtc) });
            sb.AppendFormat("{0} ", new object[] { this.FormatLogLevel(logEntry.Level) });
            sb.AppendFormat("{0} ", new object[] { this.FormatMessage(logEntry.Message) });
            sb.AppendFormat("{0} ", new object[] { this.FormatException(logEntry.Exception) }).AppendLine();
            AppendProperties(sb, logEntry);
            return sb.ToString();
        }

        private static void AppendProperties(StringBuilder sb, LogEntry logEntry)
        {
            if (logEntry.Properties != null)
            {
                foreach (KeyValuePair<string, object> pair in logEntry.Properties)
                {
                    sb.AppendFormat(" {0}={1}", new object[] { pair.Key, pair.Value }).AppendLine();
                }
            }
        }

        private string FormatException(Exception exception)
        {
            if (exception != null)
            {
                return exception.ToString();
            }
            return "-";
        }

        private string FormatLogLevel(PS.SilverlightClientLib.Infrastructure.Logging.LogLevel level)
        {
            return level.ToString().ToUpperInvariant();
        }

        private string FormatMessage(string message)
        {
            if ((message != null) && message.HasContent())
            {
                return message;
            }
            return "-";
        }

        private string FormatTimeStamp(DateTime timeStampUtc)
        {
            return timeStampUtc.ToString("yyyy-MM-dd-HH-mm-ss.fffZ");
        }

        #endregion Methods
    }
}