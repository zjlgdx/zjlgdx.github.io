﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;

    internal interface ILogEntryFormatter
    {
        #region Methods

        string FormatLogEntry(LogEntry logEntry);

        #endregion Methods
    }
}