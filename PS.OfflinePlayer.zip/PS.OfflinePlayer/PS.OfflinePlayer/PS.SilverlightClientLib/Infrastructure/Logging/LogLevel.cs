﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;

    #region Enumerations

    internal enum LogLevel
    {
        Debug = 1,
        Error = 4,
        Fatal = 5,
        Info = 2,
        Warn = 3
    }

    #endregion Enumerations
}