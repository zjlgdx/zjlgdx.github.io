﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    internal class Logger : ILog
    {
        #region Fields

        private readonly ILogEntryFormatter logEntryFormatter;
        private readonly ILogStrategy logStrategy;

        #endregion Fields

        #region Constructors

        internal Logger(ILogEntryFormatter logEntryFormatter, ILogStrategy logStrategy)
        {
            this.logEntryFormatter = logEntryFormatter;
            this.logStrategy = logStrategy;
        }

        #endregion Constructors

        #region Methods

        public void Debug(string message, Exception exception = null, Dictionary<string, object> properties = null)
        {
            LogEntry logEntry = new LogEntry(PS.SilverlightClientLib.Infrastructure.Logging.LogLevel.Debug, message, exception, properties);
            this.Log(logEntry);
        }

        public void Error(string message, Exception exception = null, Dictionary<string, object> properties = null)
        {
            LogEntry logEntry = new LogEntry(PS.SilverlightClientLib.Infrastructure.Logging.LogLevel.Error, message, exception, properties);
            this.Log(logEntry);
        }

        public void Fatal(string message, Exception exception = null, Dictionary<string, object> properties = null)
        {
            LogEntry logEntry = new LogEntry(PS.SilverlightClientLib.Infrastructure.Logging.LogLevel.Fatal, message, exception, properties);
            this.Log(logEntry);
        }

        public void Info(string message, Exception exception = null, Dictionary<string, object> properties = null)
        {
            LogEntry logEntry = new LogEntry(PS.SilverlightClientLib.Infrastructure.Logging.LogLevel.Info, message, exception, properties);
            this.Log(logEntry);
        }

        public void Warn(string message, Exception exception = null, Dictionary<string, object> properties = null)
        {
            LogEntry logEntry = new LogEntry(PS.SilverlightClientLib.Infrastructure.Logging.LogLevel.Warn, message, exception, properties);
            this.Log(logEntry);
        }

        private void Log(LogEntry logEntry)
        {
            string formattedLogEntry = this.logEntryFormatter.FormatLogEntry(logEntry);
            this.logStrategy.Log(formattedLogEntry);
        }

        #endregion Methods
    }
}