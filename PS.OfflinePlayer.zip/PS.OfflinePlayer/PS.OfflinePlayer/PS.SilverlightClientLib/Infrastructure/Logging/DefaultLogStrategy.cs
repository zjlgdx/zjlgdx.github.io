﻿namespace PS.SilverlightClientLib.Infrastructure.Logging
{
    using System;
    using System.IO;

    internal class DefaultLogStrategy : ILogStrategy
    {
        #region Fields

        private const int MaxBytesBeforeDeleting = 0xa00000;

        private readonly object monitor = new object();

        private static string LogFilePath = "";

        #endregion Fields

        #region Properties

        private static long LogFileLength
        {
            get
            {
                return new FileInfo(LogFilePath).Length;
            }
        }

        #endregion Properties

        #region Methods

        public static void Initialize(string logFilePath)
        {
            LogFilePath = logFilePath;
            DeleteLargeLogFile();
        }

        public void Log(string formattedLogEntry)
        {
            try
            {
                lock (this.monitor)
                {
                    File.AppendAllText(LogFilePath, formattedLogEntry);
                }
            }
            catch
            {
            }
        }

        private static void DeleteLargeLogFile()
        {
            if (File.Exists(LogFilePath) && (LogFileLength > 0xa00000L))
            {
                File.Delete(LogFilePath);
            }
        }

        #endregion Methods
    }
}