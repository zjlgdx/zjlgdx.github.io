﻿namespace PS.SilverlightClientLib.Infrastructure.Notifications
{
    using System;
    using System.ComponentModel;
    using System.Linq.Expressions;

    using Shared;

    public abstract class ModelWithNotificationBase<TConcreteType> : INotifyPropertyChanged
    {
        #region Constructors

        protected ModelWithNotificationBase()
        {
        }

        #endregion Constructors

        #region Events

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Events

        #region Methods

        public bool IsPropertyName(Expression<Func<TConcreteType, object>> property, string propertyName)
        {
            return (ExpressionUtils.MemberName<TConcreteType>(property) == propertyName);
        }

        protected void NotifyEntireModelChanged()
        {
            PropertyChangedEventArgs args = new PropertyChangedEventArgs("");
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged.TryFirePropertyChangeFromModelThread(this, args);
            }
        }

        protected void NotifyPropertyChanged(params Expression<Func<TConcreteType, object>>[] members)
        {
            if (members == null)
            {
                throw new ArgumentNullException("members");
            }
            if (this.PropertyChanged != null)
            {
                foreach (Expression<Func<TConcreteType, object>> expression in members)
                {
                    this.NotifyPropertyChanged(expression);
                }
            }
        }

        protected void NotifyPropertyChanged(Expression<Func<TConcreteType, object>> member)
        {
            if (member == null)
            {
                throw new ArgumentNullException("member");
            }
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged.TryFirePropertyChangeFromModelThread(this, new PropertyChangedEventArgs(ExpressionUtils.MemberName<TConcreteType>(member)));
            }
        }

        #endregion Methods
    }
}