﻿namespace PS.SilverlightClientLib.Infrastructure.Notifications
{
    using System;
    using System.Linq.Expressions;

    public static class ExpressionUtils
    {
        #region Methods

        public static string MemberName<T>(Expression<Func<T, object>> expression)
        {
            if (expression == null)
            {
                throw new ArgumentNullException("expression");
            }
            MemberExpression operand = null;
            if (expression.Body is UnaryExpression)
            {
                UnaryExpression body = (UnaryExpression) expression.Body;
                operand = (MemberExpression) body.Operand;
            }
            if (expression.Body is MemberExpression)
            {
                operand = (MemberExpression) expression.Body;
            }
            if (operand == null)
            {
                throw new ArgumentException("Expected UnaryExpression or MemberExpression", "expression");
            }
            return operand.Member.Name;
        }

        #endregion Methods
    }
}