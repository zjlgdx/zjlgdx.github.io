﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Threading;

    public class SyncContextHelper
    {
        #region Fields

        private readonly SynchronizationContext ctx;

        #endregion Fields

        #region Constructors

        private SyncContextHelper(SynchronizationContext ctx)
        {
            this.ctx = ctx;
        }

        #endregion Constructors

        #region Properties

        public bool NullContext
        {
            get
            {
                return (null == this.ctx);
            }
        }

        #endregion Properties

        #region Methods

        public static SyncContextHelper MakeEmptySyncContextHelper()
        {
            return new SyncContextHelper(null);
        }

        public static SyncContextHelper MakeSyncContextHelper()
        {
            return new SyncContextHelper(SynchronizationContext.Current);
        }

        public void Post(Action action)
        {
            if (this.ctx == null)
            {
                action();
            }
            else
            {
                this.ctx.Post(noStateNecessary => action(), null);
            }
        }

        public void Post<T>(T state, Action<T> action)
        {
            if (this.ctx == null)
            {
                action(state);
            }
            else
            {
                this.ctx.Post(s => action((T) s), state);
            }
        }

        #endregion Methods
    }
}