﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.ComponentModel;
    using System.Runtime.CompilerServices;

    using PS.SilverlightClientLib.Infrastructure;
    using PS.SilverlightClientLib.Infrastructure.App;

    public static class EventHandlerExtensions
    {
        #region Methods

        public static void TryFireEvent(this EventHandler anEvent, object sender)
        {
            if (anEvent != null)
            {
                anEvent(sender, EventArgs.Empty);
            }
        }

        public static void TryFireEventFromModelThread(this EventHandler anEvent, object sender)
        {
            ThreadHelper.ThrowIfNotModelThread();
            anEvent.TryFireEvent(sender);
        }

        public static void TryFireEventFromModelThread<T>(this EventHandler<T> anEvent, object sender, T args)
            where T : EventArgs
        {
            ThreadHelper.ThrowIfNotModelThread();
            anEvent.TryFireEvent<T>(sender, args);
        }

        public static void TryFirePropertyChangeFromModelThread(this PropertyChangedEventHandler propertyChangedHandler, object sender, PropertyChangedEventArgs args)
        {
            if (!AppState.Instance.IsExiting)
            {
                ThreadHelper.ThrowIfNotModelThread();
                if (propertyChangedHandler != null)
                {
                    propertyChangedHandler(sender, args);
                }
            }
        }

        private static void TryFireEvent<T>(this EventHandler<T> anEvent, object sender, T args)
            where T : EventArgs
        {
            if (anEvent != null)
            {
                anEvent(sender, args);
            }
        }

        #endregion Methods
    }
}