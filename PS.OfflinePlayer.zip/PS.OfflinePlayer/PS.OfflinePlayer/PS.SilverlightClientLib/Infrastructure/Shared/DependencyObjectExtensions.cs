﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using System.Threading;
    using System.Windows;
    using System.Windows.Media;

    public static class DependencyObjectExtensions
    {
        #region Methods

        public static IEnumerable<T> Descendents<T>(this DependencyObject parent)
            where T : DependencyObject
        {
            return (from descendent in parent.Descendents() select descendent as T).SkipNulls<T>();
        }

        public static DependencyObject FindAncestor(DependencyObject dependencyObject, Func<DependencyObject, bool> predicate)
        {
            if (predicate(dependencyObject))
            {
                return dependencyObject;
            }
            DependencyObject obj2 = null;
            FrameworkElement reference = dependencyObject as FrameworkElement;
            if (reference != null)
            {
                obj2 = reference.Parent ?? VisualTreeHelper.GetParent(reference);
            }
            if (obj2 != null)
            {
                return FindAncestor(obj2, predicate);
            }
            return null;
        }

        public static IEnumerable<DependencyObject> FindDescendants(DependencyObject dependencyObject, Func<DependencyObject, bool> predicate)
        {
            if (predicate(dependencyObject))
            {
                yield return dependencyObject;
            }
            int childrenCount = VisualTreeHelper.GetChildrenCount(dependencyObject);
            for (int i = 0; i < childrenCount; i++)
            {
                foreach (DependencyObject iteratorVariable2 in FindDescendants(VisualTreeHelper.GetChild(dependencyObject, i), predicate))
                {
                    yield return iteratorVariable2;
                }
            }
        }

        public static T FindParent<T>(this DependencyObject childElement)
            where T : DependencyObject
        {
            return childElement.FindParent<T>(0);
        }

        public static DependencyObject FindParent(this DependencyObject element, Func<DependencyObject, bool> filter)
        {
            DependencyObject parent = VisualTreeHelper.GetParent(element);
            if (parent == null)
            {
                return null;
            }
            if (filter(parent))
            {
                return parent;
            }
            return parent.FindParent(filter);
        }

        public static T FindParent<T>(this DependencyObject childElement, int depth)
            where T : DependencyObject
        {
            DependencyObject parent = VisualTreeHelper.GetParent(childElement);
            T local = parent as T;
            if (parent == null)
            {
                return default(T);
            }
            if (local != null)
            {
                if (depth == 0)
                {
                    return local;
                }
                depth -= depth;
            }
            return parent.FindParent<T>(depth);
        }

        private static IEnumerable<DependencyObject> Descendents(this DependencyObject parent)
        {
            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
            foreach (DependencyObject iteratorVariable1 in from i in Enumerable.Range(0, childrenCount) select VisualTreeHelper.GetChild(parent, i))
            {
                yield return iteratorVariable1;
                foreach (DependencyObject iteratorVariable2 in iteratorVariable1.Descendents())
                {
                    yield return iteratorVariable2;
                }
            }
        }

        #endregion Methods
    }
}