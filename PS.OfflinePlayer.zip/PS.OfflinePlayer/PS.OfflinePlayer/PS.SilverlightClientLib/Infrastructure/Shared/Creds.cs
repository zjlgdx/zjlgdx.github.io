﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Runtime.CompilerServices;

    public class Creds : IEquatable<Creds>
    {
        #region Properties

        public string Password
        {
            get; set;
        }

        public string Username
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        public static bool operator !=(Creds left, Creds right)
        {
            return !object.Equals(left, right);
        }

        public static bool operator ==(Creds left, Creds right)
        {
            return object.Equals(left, right);
        }

        public bool Equals(Creds other)
        {
            if (object.ReferenceEquals(null, other))
            {
                return false;
            }
            return (object.ReferenceEquals(this, other) || (object.Equals(other.Username, this.Username) && object.Equals(other.Password, this.Password)));
        }

        public override bool Equals(object obj)
        {
            if (object.ReferenceEquals(null, obj))
            {
                return false;
            }
            if (object.ReferenceEquals(this, obj))
            {
                return true;
            }
            if (obj.GetType() != typeof(Creds))
            {
                return false;
            }
            return this.Equals((Creds) obj);
        }

        public override int GetHashCode()
        {
            return ((((this.Username != null) ? this.Username.GetHashCode() : 0) * 0x18d) ^ ((this.Password != null) ? this.Password.GetHashCode() : 0));
        }

        public override string ToString()
        {
            return string.Format("Username: {0}", this.Username);
        }

        #endregion Methods
    }
}