﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Runtime.CompilerServices;

    public static class ObservableCollectionExtensions
    {
        #region Methods

        public static void AddRange<T>(this ObservableCollection<T> collection, IEnumerable<T> items)
        {
            foreach (T local in items)
            {
                collection.Add(local);
            }
        }

        #endregion Methods
    }
}