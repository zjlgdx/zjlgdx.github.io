﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;
    using System.Runtime.CompilerServices;
    using System.Security.Cryptography;
    using System.Threading;

    using PS.SilverlightClientLib.Infrastructure.Cryptography;
    using PS.SilverlightClientLib.Infrastructure.Logging;

    public class BufferingSeekableDecryptionStream : Stream, IDisposable
    {
        #region Fields

        private const int ReadAheadBufferSize = 0x4000;

        private static readonly ILog log = LogManager.GetLogger(typeof(BufferingSeekableDecryptionStream));

        private readonly FileStream bufferStream;
        private readonly long clipLength;
        private readonly CryptoStream cryptoStream;
        private readonly ICryptoTransform decryptor;
        private readonly Stream encryptedStream;
        private readonly AutoResetEvent readAheadWriteCompleteEvent = new AutoResetEvent(false);
        private readonly object syncRoot = new object();
        private readonly string tempPath;

        private volatile bool classInstanceBeingDisposed;
        private bool disposed;
        private long highestBufferedPosition;
        private volatile bool readAheadCompletelyDone;
        private long virtualPos;

        #endregion Fields

        #region Constructors

        public BufferingSeekableDecryptionStream(Stream encryptedStream, long clipLength)
        {
            this.encryptedStream = encryptedStream;
            this.clipLength = clipLength;
            this.decryptor = CryptographyHelper.MakeDecryptor();
            this.cryptoStream = new CryptoStream(encryptedStream, this.decryptor, CryptoStreamMode.Read);
            this.tempPath = this.CreateTempFilePath();
            this.bufferStream = new FileStream(this.tempPath, FileMode.Create, FileAccess.ReadWrite, FileShare.ReadWrite);
            this.virtualPos = 0L;
            ThreadPool.QueueUserWorkItem(new WaitCallback(this.ReadAheadThreadWorker));
        }

        #endregion Constructors

        #region Properties

        public override bool CanRead
        {
            get
            {
                return true;
            }
        }

        public override bool CanSeek
        {
            get
            {
                return true;
            }
        }

        public override bool CanWrite
        {
            get
            {
                return false;
            }
        }

        public long HighestPosition
        {
            get
            {
                lock (this.syncRoot)
                {
                    return this.highestBufferedPosition;
                }
            }
        }

        public override long Length
        {
            get
            {
                return this.clipLength;
            }
        }

        public override long Position
        {
            get
            {
                return this.virtualPos;
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        #endregion Properties

        #region Methods

        public override void Flush()
        {
            this.cryptoStream.Flush();
        }

        void IDisposable.Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            this.EnsureBufferedData(count);
            this.SyncBufferStreamToVirtualPos();
            int num = this.bufferStream.Read(buffer, offset, count);
            this.virtualPos += num;
            return num;
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            long requestedPosition = 0L;
            switch (origin)
            {
                case SeekOrigin.Begin:
                    requestedPosition = offset;
                    break;

                case SeekOrigin.Current:
                    requestedPosition = this.virtualPos + offset;
                    break;

                case SeekOrigin.End:
                    requestedPosition = this.Length + offset;
                    break;
            }
            if (requestedPosition > this.Length)
            {
                throw new InvalidOperationException("Seek beyond end not supported on this stream");
            }
            this.BlockForWriteAheadOrThrow(requestedPosition);
            this.virtualPos = requestedPosition;
            return this.bufferStream.Seek(offset, origin);
        }

        public override void SetLength(long value)
        {
            throw new InvalidOperationException("This stream does not support setting the length");
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            throw new InvalidOperationException("Stream is not writable");
        }

        protected override void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    try
                    {
                        this.classInstanceBeingDisposed = true;
                        while (!this.readAheadCompletelyDone)
                        {
                            this.readAheadWriteCompleteEvent.WaitOne(200);
                        }
                        this.cryptoStream.Close();
                        this.decryptor.Dispose();
                        this.bufferStream.Dispose();
                        this.encryptedStream.Dispose();
                        FileHelpers.DeleteQuietly(this.tempPath);
                    }
                    catch (CryptographicException exception)
                    {
                        log.Debug(exception, null);
                    }
                    catch (IOException exception2)
                    {
                        log.Error(exception2, null);
                    }
                }
                this.disposed = true;
            }
        }

        private void BlockForWriteAheadOrThrow(long requestedPosition)
        {
            while ((requestedPosition > this.HighestPosition) && !this.readAheadCompletelyDone)
            {
                this.readAheadWriteCompleteEvent.WaitOne();
            }
            if (requestedPosition > this.HighestPosition)
            {
                throw new IOException("Blocking seek failed");
            }
        }

        private void ConsumeCryptoStreamBeforeClosing(byte[] buffer)
        {
            while (this.cryptoStream.Read(buffer, 0, buffer.Length) > 0)
            {
            }
        }

        private string CreateTempFilePath()
        {
            return Paths.LocalClipPath(FileHelpers.CreateRandomLocalClipPath());
        }

        private void EnsureBufferedData(int count)
        {
            long requestedPosition = Math.Min(this.Length, this.virtualPos + count);
            if (requestedPosition > this.HighestPosition)
            {
                this.BlockForWriteAheadOrThrow(requestedPosition);
            }
        }

        private void ReadAheadThreadWorker(object state)
        {
            try
            {
                using (FileStream stream = new FileStream(this.tempPath, FileMode.Open, FileAccess.Write, FileShare.ReadWrite))
                {
                    int num;
                    byte[] buffer = new byte[0x4000];
                    while ((num = this.cryptoStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        if (this.classInstanceBeingDisposed)
                        {
                            this.ConsumeCryptoStreamBeforeClosing(buffer);
                            return;
                        }
                        stream.Write(buffer, 0, num);
                        lock (this.syncRoot)
                        {
                            this.highestBufferedPosition += num;
                        }
                        this.readAheadWriteCompleteEvent.Set();
                    }
                }
            }
            catch (IOException exception)
            {
                log.Error(exception, null);
            }
            finally
            {
                this.readAheadCompletelyDone = true;
                this.readAheadWriteCompleteEvent.Set();
            }
        }

        private void SyncBufferStreamToVirtualPos()
        {
            this.Seek(this.virtualPos, SeekOrigin.Begin);
        }

        #endregion Methods
    }
}