﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System.Collections.Generic;

    public class LogDictionary : Dictionary<string, object>
    {
    }
}