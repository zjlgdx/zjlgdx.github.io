﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;
    using System.Linq;

    public static class FileTreeDeleter
    {
        #region Methods

        public static void RemoveAllPluralsightContent()
        {
            RecursiveDelete(Paths.ContentDir);
            RecursiveDelete(Paths.MetadataDir);
        }

        private static void RecursiveDelete(string directory)
        {
            DirectoryInfo dirInfo = new DirectoryInfo(directory);
            if (dirInfo.Exists)
            {
                RemoveAllFiles(dirInfo);
                RemoveAllChildDirs(dirInfo);
            }
        }

        private static void RemoveAllChildDirs(DirectoryInfo dirInfo)
        {
            foreach (DirectoryInfo info in dirInfo.EnumerateDirectories("*", SearchOption.AllDirectories).ToArray<DirectoryInfo>())
            {
                Directory.Delete(info.FullName);
            }
        }

        private static void RemoveAllFiles(DirectoryInfo dirInfo)
        {
            foreach (FileInfo info in dirInfo.EnumerateFiles("*", SearchOption.AllDirectories).ToArray<FileInfo>())
            {
                FileHelpers.DeleteQuietly(info.FullName);
            }
        }

        #endregion Methods
    }
}