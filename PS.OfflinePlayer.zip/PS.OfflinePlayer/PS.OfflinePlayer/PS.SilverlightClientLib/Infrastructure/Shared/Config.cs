﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;

    public static class Config
    {
        #region Fields

        private const string ApiHttpBaseUriLocal = "http://pluralsight.local/web2/metadata/live/";
        private const string ApiHttpsBaseUriLocal = "https://pluralsight.local/web2/metadata/live/";
        private const string MetadataPathFragment = "/metadata/live/";
        private const string WebsiteHttpBaseUriLocal = "http://pluralsight.local/web2";

        private static Uri HostSourceUri;

        #endregion Fields

        #region Properties

        public static string ApiHttpBaseUri
        {
            get
            {
                return ExtractApiUrlOrFallback(Uri.UriSchemeHttp, "http://pluralsight.local/web2/metadata/live/");
            }
        }

        public static string ApiHttpsBaseUri
        {
            get
            {
                return ExtractApiUrlOrFallback(Uri.UriSchemeHttps, "https://pluralsight.local/web2/metadata/live/");
            }
        }

        public static string BaseDir
        {
            get
            {
                return @"G:\Pluralsight Orignal Vedio Encoded\Pluralsight";
                return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyVideos), "Pluralsight");
            }
        }

        public static string WebsiteHttpBaseUri
        {
            get
            {
                return ExtractWebsiteUrlOrFallback(Uri.UriSchemeHttp, "http://pluralsight.local/web2");
            }
        }

        #endregion Properties

        #region Methods

        public static void Initialize(string hostSourceUri)
        {
            HostSourceUri = new Uri(hostSourceUri);
        }

        private static string ExtractApiUrlOrFallback(string protocolScheme, string localFallback)
        {
            if (null == HostSourceUri)
            {
                throw new InvalidOperationException("Need to call Initialize() before using Config Urls");
            }
            Uri hostSourceUri = HostSourceUri;
            if (IsFileScheme(hostSourceUri))
            {
                return localFallback;
            }
            string host = hostSourceUri.Host;
            string[] strArray = SplitPath(hostSourceUri);
            if (strArray.Length > 1)
            {
                string str2 = strArray[1];
                return string.Format("{0}://{1}/{2}{3}", new object[] { protocolScheme, host, str2, "/metadata/live/" });
            }
            return string.Format("{0}://{1}{2}", protocolScheme, host, "/metadata/live/");
        }

        private static string ExtractWebsiteUrlOrFallback(string protocolScheme, string localFallback)
        {
            if (null == HostSourceUri)
            {
                throw new InvalidOperationException("Need to call Initialize() before using Config Urls");
            }
            Uri hostSourceUri = HostSourceUri;
            if (IsFileScheme(hostSourceUri))
            {
                return localFallback;
            }
            string host = hostSourceUri.Host;
            string[] strArray = SplitPath(hostSourceUri);
            if (strArray.Length > 1)
            {
                string str2 = strArray[1];
                return string.Format("{0}://{1}/{2}", protocolScheme, host, str2);
            }
            return string.Format("{0}://{1}", protocolScheme, host);
        }

        private static bool IsFileScheme(Uri codeBaseRoot)
        {
            return (codeBaseRoot.Scheme == Uri.UriSchemeFile);
        }

        private static string[] SplitPath(Uri codeBaseRoot)
        {
            return codeBaseRoot.LocalPath.Split(new char[] { '/' });
        }

        #endregion Methods
    }
}