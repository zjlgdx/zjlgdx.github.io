﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;
    using System.Runtime.Serialization;
    using System.Security.Cryptography;

    using PS.SilverlightClientLib.Infrastructure.Cryptography;
    using PS.SilverlightClientLib.Infrastructure.Logging;

    internal static class DiskEntityLoader
    {
        #region Fields

        internal static readonly ILog log = LogManager.GetLogger(typeof(DiskEntityLoader));

        #endregion Fields

        #region Methods

        internal static void EnsureCryptoStreamIsCompletelyConsumed(CryptoStream cryptoStream)
        {
            byte[] buffer = new byte[0x400];
            while (cryptoStream.Read(buffer, 0, buffer.Length) > 0)
            {
            }
        }

        internal static bool TryLoadEncryptedEntityFromDisk(string path, Action<CryptoStream> loader)
        {
            if (File.Exists(path))
            {
                try
                {
                    using (FileStream stream = File.OpenRead(path))
                    {
                        using (ICryptoTransform transform = CryptographyHelper.MakeDecryptor())
                        {
                            using (CryptoStream stream2 = new CryptoStream(stream, transform, CryptoStreamMode.Read))
                            {
                                loader(stream2);
                                if (stream2.CanRead)
                                {
                                    EnsureCryptoStreamIsCompletelyConsumed(stream2);
                                }
                            }
                        }
                    }
                    return true;
                }
                catch (FileNotFoundException exception)
                {
                    LogDictionary properties = new LogDictionary();
                    properties.Add("path", path);
                    log.Debug(exception, properties);
                }
                catch (IOException exception2)
                {
                    LogDictionary dictionary2 = new LogDictionary();
                    dictionary2.Add("path", path);
                    log.Error(exception2, dictionary2);
                }
                catch (SerializationException exception3)
                {
                    LogDictionary dictionary3 = new LogDictionary();
                    dictionary3.Add("path", path);
                    log.Error(exception3, dictionary3);
                }
                catch (CryptographicException exception4)
                {
                    LogDictionary dictionary4 = new LogDictionary();
                    dictionary4.Add("path", path);
                    log.Error(exception4, dictionary4);
                }
            }
            return false;
        }

        internal static bool TrySaveEntityToDiskEncrypted<T>(string path, T dto)
        {
            FileStream stream = File.Create(path);
            try
            {
                using (ICryptoTransform transform = CryptographyHelper.MakeEncryptor())
                {
                    using (CryptoStream stream2 = new CryptoStream(stream, transform, CryptoStreamMode.Write))
                    {
                        JsonSerializer.Serialize<T>(stream2, dto);
                    }
                }
                return true;
            }
            catch (SerializationException exception)
            {
                log.Error("Unable to persist AppState: " + exception, null, null);
            }
            catch (IOException exception2)
            {
                log.Error("Unable to persist AppState: " + exception2, null, null);
            }
            catch (CryptographicException exception3)
            {
                log.Error("Unable to persist AppState: " + exception3, null, null);
            }
            finally
            {
                if (stream != null)
                {
                    stream.Dispose();
                }
            }
            return false;
        }

        #endregion Methods
    }
}