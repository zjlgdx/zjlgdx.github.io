﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;

    public class ForbiddenResponseDto
    {
        #region Fields

        public string Reason;

        #endregion Fields
    }
}