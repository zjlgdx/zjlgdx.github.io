﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;
    using System.Security.Cryptography;

    public static class FileHelpers
    {
        #region Methods

        public static string CanonicalizePath(string path)
        {
            return Path.GetFullPath(path).ToUpperInvariant();
        }

        public static string CreateRandomLocalClipPath()
        {
            string str2;
            RNGCryptoServiceProvider provider = new RNGCryptoServiceProvider();
            byte[] data = new byte[8];
            do
            {
                provider.GetBytes(data);
                str2 = MakeFileSafe(Convert.ToBase64String(data));
            }
            while (File.Exists(Paths.LocalClipPath(str2)));
            return str2;
        }

        public static void DeleteQuietly(string videoFileToDelete)
        {
            try
            {
                File.Delete(videoFileToDelete);
            }
            catch (Exception)
            {
            }
        }

        private static string MakeFileSafe(string base64Encoded)
        {
            return base64Encoded.Replace('/', 'x').Replace('+', 'x').Replace('=', 'x');
        }

        #endregion Methods
    }
}