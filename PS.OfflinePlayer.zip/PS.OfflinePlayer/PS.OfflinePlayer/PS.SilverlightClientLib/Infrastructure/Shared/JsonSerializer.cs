﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;
    using System.Runtime.Serialization.Json;

    public static class JsonSerializer
    {
        #region Methods

        public static T Deserialize<T>(Stream stream)
        {
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(T));
            return (T) serializer.ReadObject(stream);
        }

        public static void Serialize<T>(Stream stream, T root)
        {
            new DataContractJsonSerializer(typeof(T)).WriteObject(stream, root);
        }

        #endregion Methods
    }
}