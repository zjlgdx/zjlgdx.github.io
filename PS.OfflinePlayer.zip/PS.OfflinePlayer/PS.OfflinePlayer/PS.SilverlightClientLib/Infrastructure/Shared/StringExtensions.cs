﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Text.RegularExpressions;
    using System.Windows.Browser;

    public static class StringExtensions
    {
        #region Fields

        private static readonly Regex NonWhitespace = new Regex(@"\S");

        #endregion Fields

        #region Methods

        public static string FormatWith(this string formatString, params object[] args)
        {
            return string.Format(formatString, args);
        }

        public static bool HasContent(this string s)
        {
            if (s == null)
            {
                throw new ArgumentNullException("s");
            }
            return (s.Length > 0);
        }

        public static bool NotJustWhitespace(this string s)
        {
            if (!s.HasContent())
            {
                return false;
            }
            return NonWhitespace.Match(s).Success;
        }

        public static string UrlEncode(this string str)
        {
            return HttpUtility.UrlEncode(str);
        }

        #endregion Methods
    }
}