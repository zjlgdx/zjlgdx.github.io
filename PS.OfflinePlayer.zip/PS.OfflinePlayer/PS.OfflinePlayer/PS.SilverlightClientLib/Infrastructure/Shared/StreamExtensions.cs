﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;
    using System.Runtime.CompilerServices;

    public static class StreamExtensions
    {
        #region Methods

        public static void Rewind(this Stream stream)
        {
            stream.Seek(0L, SeekOrigin.Begin);
        }

        #endregion Methods
    }
}