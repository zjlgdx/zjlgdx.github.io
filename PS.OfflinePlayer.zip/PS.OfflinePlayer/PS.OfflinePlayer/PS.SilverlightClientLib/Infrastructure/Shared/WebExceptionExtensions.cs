﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Net;
    using System.Runtime.CompilerServices;

    public static class WebExceptionExtensions
    {
        #region Methods

        public static System.Net.HttpStatusCode HttpStatusCode(this WebException x)
        {
            return ((HttpWebResponse) x.Response).StatusCode;
        }

        public static void TryFireCancelledWebException(this Action<Exception> fireAction)
        {
            if (fireAction != null)
            {
                try
                {
                    throw new WebException("Explicitly cancelled", WebExceptionStatus.RequestCanceled);
                }
                catch (WebException exception)
                {
                    fireAction(exception);
                }
            }
        }

        #endregion Methods
    }
}