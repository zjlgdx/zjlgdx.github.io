﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;

    using PS.SilverlightClientLib.Models.UserProfileModel;

    public static class Uris
    {
        #region Properties

        public static string CourseCatalogUri
        {
            get
            {
                return (Config.ApiHttpBaseUri + "courses");
            }
        }

        public static string OfflineActivityUri
        {
            get
            {
                return string.Format("{0}offlineactivity?Token={1}", UserSpecificUri(Config.ApiHttpBaseUri, UserName), LoginTokenValue);
            }
        }

        public static string YourAccountUri
        {
            get
            {
                return (Config.WebsiteHttpBaseUri + "/profile");
            }
        }

        private static string LoginTokenValue
        {
            get
            {
                return UserProfile.Instance.LoginTokenValue;
            }
        }

        private static string UserName
        {
            get
            {
                return UserProfile.Instance.UserName;
            }
        }

        #endregion Properties

        #region Methods

        public static string LoginUri(string userName)
        {
            return (UserSpecificUri(Config.ApiHttpsBaseUri, userName) + "login");
        }

        public static string ModuleSizeUri(string moduleId)
        {
            return "{0}modulesize/{1}/{2}".FormatWith(new object[] { Config.ApiHttpBaseUri, moduleId, "1024x768Wmv" });
        }

        public static string OfflineClipVideoUri(string moduleId, int clipIndex)
        {
            return "{0}offlineclipvideo/{1}/{2}/{3}?Token={4}".FormatWith(new object[] { UserSpecificUri(Config.ApiHttpBaseUri, UserName), moduleId, clipIndex, "1024x768Wmv", LoginTokenValue });
        }

        private static string UserSpecificUri(string baseUri, string userName)
        {
            return "{0}users/{1}/".FormatWith(new object[] { baseUri, userName });
        }

        #endregion Methods
    }
}