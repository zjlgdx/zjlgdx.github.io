﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Runtime.CompilerServices;

    public static class NullableExtensions
    {
        #region Methods

        public static T ValueOrDefault<T>(this T? nullable)
            where T : struct
        {
            if (!nullable.HasValue)
            {
                return default(T);
            }
            return nullable.Value;
        }

        #endregion Methods
    }
}