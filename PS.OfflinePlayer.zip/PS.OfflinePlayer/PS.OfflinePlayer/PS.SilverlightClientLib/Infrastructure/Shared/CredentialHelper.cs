﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;
    using System.Runtime.Serialization;
    using System.Security.Cryptography;

    using PS.SilverlightClientLib.Infrastructure.Cryptography;

    public static class CredentialHelper
    {
        #region Methods

        public static void DeleteCredentials()
        {
            FileHelpers.DeleteQuietly(Paths.CredFile);
        }

        public static void PersistCredentials(string userName, string password)
        {
            Creds root = new Creds {
                Username = userName,
                Password = password
            };
            using (FileStream stream = File.OpenWrite(Paths.CredFile))
            {
                using (CryptoStream stream2 = new CryptoStream(stream, CryptographyHelper.MakeEncryptor(), CryptoStreamMode.Write))
                {
                    JsonSerializer.Serialize<Creds>(stream2, root);
                }
            }
        }

        public static Creds ReadCredentials()
        {
            Creds creds;
            try
            {
                string credFile = Paths.CredFile;
                if (!File.Exists(credFile))
                {
                    creds = null;
                }
                else
                {
                    using (FileStream stream = File.OpenRead(credFile))
                    {
                        using (CryptoStream stream2 = new CryptoStream(stream, CryptographyHelper.MakeDecryptor(), CryptoStreamMode.Read))
                        {
                            creds = JsonSerializer.Deserialize<Creds>(stream2);
                        }
                    }
                }
            }
            catch (SerializationException)
            {
                creds = null;
            }
            catch (CryptographicException)
            {
                creds = null;
            }
            return creds;
        }

        #endregion Methods
    }
}