﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;
    using System.Runtime.Serialization;

    using PS.SilverlightClientLib.Infrastructure.Logging;

    public static class TokenHelper
    {
        #region Fields

        private static readonly ILog log = LogManager.GetLogger(typeof(TokenHelper));

        #endregion Fields

        #region Methods

        public static bool FailedBecauseOfInvalidToken(Stream result)
        {
            try
            {
                return (JsonSerializer.Deserialize<ForbiddenResponseDto>(result).Reason == ForbiddenReason.InvalidToken.ToString());
            }
            catch (ArgumentException exception)
            {
                log.Error(exception, null);
                return true;
            }
            catch (SerializationException exception2)
            {
                log.Error(exception2, null);
                return true;
            }
        }

        public static void FailWithMissingCredentials(Action<Exception> completionAction)
        {
            try
            {
                log.Error("Expected credentials but was unable to retrieve them during reauthentication", null, null);
                throw new MissingCredentialsException();
            }
            catch (MissingCredentialsException exception)
            {
                completionAction(exception);
            }
        }

        public static void FailWithNotAuthorized(Action<Exception> completionAction)
        {
            try
            {
                log.Error("Unauthorized account", null, null);
                throw new NotAuthorizedException();
            }
            catch (NotAuthorizedException exception)
            {
                completionAction(exception);
            }
        }

        #endregion Methods
    }
}