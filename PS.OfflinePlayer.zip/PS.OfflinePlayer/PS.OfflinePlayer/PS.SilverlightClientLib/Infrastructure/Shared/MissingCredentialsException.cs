﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;

    public class MissingCredentialsException : Exception
    {
        #region Constructors

        public MissingCredentialsException()
            : base("Unable to acquire credentials during an operation that requires them")
        {
        }

        #endregion Constructors
    }
}