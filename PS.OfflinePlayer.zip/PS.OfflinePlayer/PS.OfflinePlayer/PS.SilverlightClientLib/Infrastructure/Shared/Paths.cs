﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.IO;

    public static class Paths
    {
        #region Properties

        public static string AppStateFile
        {
            get
            {
                return MetadataPath("as");
            }
        }

        public static string ClipViewLogFile
        {
            get
            {
                return MetadataPath("cv");
            }
        }

        public static string ContentDir
        {
            get
            {
                return Path.Combine(Config.BaseDir, "c");
            }
        }

        public static string CourseCatalogPath
        {
            get
            {
                return MetadataPath("cc");
            }
        }

        public static string CredFile
        {
            get
            {
                return Path.Combine(MetadataDir, "c");
            }
        }

        public static string KeyFile
        {
            get
            {
                return Path.Combine(MetadataDir, "k");
            }
        }

        public static string LogFilePath
        {
            get
            {
                return Path.Combine(Config.BaseDir, "log.txt");
            }
        }

        public static string MetadataDir
        {
            get
            {
                return Path.Combine(Config.BaseDir, "m");
            }
        }

        public static string OfflineModuleManifestFile
        {
            get
            {
                return MetadataPath("omm");
            }
        }

        public static string UserProfileFile
        {
            get
            {
                return MetadataPath("up");
            }
        }

        #endregion Properties

        #region Methods

        public static bool EnsureMyVideoDirectoryExists()
        {
            string folderPath = @"G:\Pluralsight Orignal Vedio Encoded";// Environment.GetFolderPath(Environment.SpecialFolder.MyVideos);
            if (string.IsNullOrEmpty(folderPath))
            {
                return false;
            }
            return Directory.Exists(folderPath);
        }

        public static void EnsureNecessaryDirectoriesArePresent()
        {
            EnsureDirectoryExists(Config.BaseDir);
            EnsureDirectoryExists(MetadataDir);
            EnsureDirectoryExists(ContentDir);
        }

        public static string LocalClipPath(string localFileName)
        {
            return Path.Combine(ContentDir, localFileName);
        }

        private static void EnsureDirectoryExists(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        private static string MetadataPath(string relativePath)
        {
            return Path.Combine(MetadataDir, relativePath);
        }

        #endregion Methods
    }
}