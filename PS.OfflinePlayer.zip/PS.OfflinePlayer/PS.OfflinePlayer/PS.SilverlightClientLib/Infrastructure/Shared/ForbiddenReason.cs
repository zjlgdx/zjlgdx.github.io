﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;

    #region Enumerations

    public enum ForbiddenReason
    {
        InvalidToken,
        NotAuthorized
    }

    #endregion Enumerations
}