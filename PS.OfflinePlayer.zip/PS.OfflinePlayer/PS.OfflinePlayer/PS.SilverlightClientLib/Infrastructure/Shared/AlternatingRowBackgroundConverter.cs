﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Globalization;
    using System.Runtime.CompilerServices;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Media;

    public class AlternatingRowBackgroundConverter : IValueConverter
    {
        #region Properties

        public Brush AlternateBrush
        {
            get; set;
        }

        public Brush NormalBrush
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Panel panel = (Panel) value;
            panel.Loaded += new RoutedEventHandler(this.Element_Loaded);
            return this.NormalBrush;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        private void Element_Loaded(object sender, RoutedEventArgs e)
        {
            Panel childElement = sender as Panel;
            ItemsControl control = childElement.FindParent<ItemsControl>();
            if (control != null)
            {
                DependencyObject container = control.ItemContainerGenerator.ContainerFromItem(childElement.DataContext);
                if ((container != null) && ((control.ItemContainerGenerator.IndexFromContainer(container) % 2) != 0))
                {
                    childElement.Background = this.AlternateBrush;
                }
            }
        }

        #endregion Methods
    }
}