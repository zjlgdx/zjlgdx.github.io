﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;

    internal static class InfrastructureConstants
    {
        #region Fields

        public const string ApplicationJsonContentType = "application/json";
        public const string Etag = "ETag";
        public const string FormEncodedContentTypeWithCharset = "application/x-www-form-urlencoded; charset=utf-8";
        public const string HttpPost = "POST";
        public const string IfNoneMatch = "If-None-Match";
        public const int LocalEncryptionKeySizeInBytes = 0x10;
        public const string VideoFormat = "1024x768Wmv";

        #endregion Fields
    }
}