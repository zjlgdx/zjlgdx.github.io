﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System.Linq;
    using System.Reflection;

    public static class ReflectionHelper
    {
        #region Methods

        public static void InitStringProperties(object that)
        {
            string[] parameters = new string[] { "" };
            foreach (PropertyInfo info in from propertyInfo in that.GetType().GetProperties()
                where (typeof(string) == propertyInfo.PropertyType) && propertyInfo.CanWrite
                select propertyInfo)
            {
                info.GetSetMethod().Invoke(that, parameters);
            }
        }

        #endregion Methods
    }
}