﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;

    public static class IDictionaryExtensions
    {
        #region Methods

        public static V TryGetValue<K, V>(this IDictionary<K, V> dictionary, K key)
        {
            V local;
            if (!dictionary.TryGetValue(key, out local))
            {
                return default(V);
            }
            return local;
        }

        #endregion Methods
    }
}