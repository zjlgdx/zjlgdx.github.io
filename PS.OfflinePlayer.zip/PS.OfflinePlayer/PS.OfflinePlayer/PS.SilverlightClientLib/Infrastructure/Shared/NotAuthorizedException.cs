﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;

    public class NotAuthorizedException : Exception
    {
        #region Constructors

        public NotAuthorizedException()
            : base("Account is unauthorized")
        {
        }

        #endregion Constructors
    }
}