﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Net.NetworkInformation;

    public static class Network
    {
        #region Properties

        public static bool IsAvailable
        {
            get
            {
                return NetworkInterface.GetIsNetworkAvailable();
            }
        }

        #endregion Properties
    }
}