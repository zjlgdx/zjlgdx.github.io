﻿namespace PS.SilverlightClientLib.Infrastructure.Shared
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.CompilerServices;

    public static class IEnumerableExtensions
    {
        #region Methods

        public static bool IsEmpty<TSource>(this IEnumerable<TSource> source)
            where TSource : class
        {
            return (null == source.FirstOrDefault<TSource>());
        }

        public static IEnumerable<T> SkipNulls<T>(this IEnumerable<T> items)
            where T : class
        {
            return (from item in items
                where item != null
                select item);
        }

        public static TimeSpan Sum(this IEnumerable<TimeSpan> source)
        {
            return Enumerable.Aggregate<TimeSpan, TimeSpan>(source, TimeSpan.Zero, (Func<TimeSpan, TimeSpan, TimeSpan>) ((current, item) => (current + item)));
        }

        public static TimeSpan Sum<TSource>(this IEnumerable<TSource> source, Func<TSource, TimeSpan> selector)
        {
            return Enumerable.Aggregate<TSource, TimeSpan>(source, TimeSpan.Zero, (Func<TimeSpan, TSource, TimeSpan>) ((current, item) => (current + selector(item))));
        }

        public static HashSet<T> ToHashSet<T>(this IEnumerable<T> items)
        {
            return new HashSet<T>(items);
        }

        #endregion Methods
    }
}