﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    public class OfflineClipVideoResponseDto
    {
        #region Fields

        public string VideoUrl;

        #endregion Fields
    }
}