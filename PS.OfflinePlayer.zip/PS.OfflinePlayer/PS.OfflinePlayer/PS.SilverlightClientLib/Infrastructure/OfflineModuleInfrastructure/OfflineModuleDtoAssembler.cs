﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    using System.Linq;

    using Shared;
    using Models.OfflineModuleModel;

    public static class OfflineModuleDtoAssembler
    {
        #region Methods

        public static OfflineModuleDto AssembleOfflineModuleDto(OfflineModule model)
        {
            return new OfflineModuleDto { CourseId = model.CourseId, ModuleId = model.ModuleId, ExpirationDateUtc = model.ExpirationDateUtc, Clips = AssembleClipDtos(model) };
        }

        private static OfflineClipDto[] AssembleClipDtos(OfflineModule model)
        {
            return (from x in model.OfflineClips select new OfflineClipDto { ClipSizeInBytes = x.FileSizeInBytes.ValueOrDefault<long>(), LocalFileName = x.LocalFileName }).ToArray<OfflineClipDto>();
        }

        #endregion Methods
    }
}