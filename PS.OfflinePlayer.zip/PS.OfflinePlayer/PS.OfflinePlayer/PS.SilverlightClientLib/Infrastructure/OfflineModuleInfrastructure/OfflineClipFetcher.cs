﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    using System;
    using System.ComponentModel;
    using System.Net;
    using System.Runtime.Serialization;

    using Cryptography;
    using Http;
    using Logging;
    using Shared;
    using UserProfileInfrastructure;
    using Models.OfflineModuleModel;
    using Models.Shared;

    public class OfflineClipFetcher
    {
        #region Fields

        private static readonly ILog log = LogManager.GetLogger(typeof(OfflineClipFetcher));

        private readonly OfflineModule module;
        private readonly SyncContextHelper syncContextHelper = SyncContextHelper.MakeSyncContextHelper();

        private volatile bool aborted;
        private OfflineClip clipToFetch;
        private string fileName;
        private PsDownloadFileWebClient fileWebClient;
        private PsDownloadMemoryStreamWebClient memoryStreamWebClient;
        private bool retryingWithFreshLoginToken;

        #endregion Fields

        #region Constructors

        public OfflineClipFetcher(OfflineModule module)
        {
            this.module = module;
        }

        #endregion Constructors

        #region Events

        public event EventHandler<PsDownloadProgressChangedEventArgs> ProgressChanged;

        public event EventHandler<AsyncCompletedEventArgs> RequestCompleted;

        #endregion Events

        #region Methods

        public void Abort()
        {
            this.aborted = true;
            if (this.memoryStreamWebClient != null)
            {
                this.memoryStreamWebClient.Abort();
            }
            if (this.fileWebClient != null)
            {
                this.fileWebClient.Abort();
            }
        }

        public void FetchOfflineClipAsync()
        {
            this.clipToFetch = this.module.FirstClipToFetch;
            if (this.clipToFetch != null)
            {
                string offlineClipVideoUri = Uris.OfflineClipVideoUri(this.module.ModuleId, this.clipToFetch.ClipIndex);
                this.DownloadClipVideoAuthorizor(offlineClipVideoUri);
            }
        }

        private void ClipProgressChanged(object sender, PsDownloadProgressChangedEventArgs e)
        {
            this.syncContextHelper.Post<PsDownloadProgressChangedEventArgs>(e, new Action<PsDownloadProgressChangedEventArgs>(this.FireProgressChanged));
        }

        private void ClipReceived(object sender, PsAsyncCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                this.syncContextHelper.Post<PsAsyncCompletedEventArgs>(e, new Action<PsAsyncCompletedEventArgs>(this.FireRequestCompletedWithError));
            }
            else
            {
                this.syncContextHelper.Post(new Action(this.UpdateStateAndContinue));
            }
        }

        private void DeserializeAuthorizeAndDownloadClip(PsDownloadMemoryStreamCompletedEventArgs e)
        {
            try
            {
                OfflineClipVideoResponseDto dto = JsonSerializer.Deserialize<OfflineClipVideoResponseDto>(e.Result);
                this.fileName = FileHelpers.CreateRandomLocalClipPath();
                string fullPath = Paths.LocalClipPath(this.fileName);
                this.DownloadClipToFileAsync(fullPath, dto.VideoUrl);
            }
            catch (SerializationException exception)
            {
                bool cancelled = false;
                object userState = null;
                PsAsyncCompletedEventArgs state = new PsAsyncCompletedEventArgs(exception, cancelled, userState);
                this.syncContextHelper.Post<PsAsyncCompletedEventArgs>(state, new Action<PsAsyncCompletedEventArgs>(this.FireRequestCompletedWithError));
            }
        }

        private void DownloadClipToFileAsync(string fullPath, string videoUrl)
        {
            Action action = null;
            if (this.aborted)
            {
                if (action == null)
                {
                    action = () => new Action<Exception>(this.FireCompletionEventOnError).TryFireCancelledWebException();
                }
                this.syncContextHelper.Post(action);
            }
            else
            {
                this.fileWebClient = PsDownloadFileWebClient.MakeDownloadFileWebClient();
                this.fileWebClient.RequestCompleted += new EventHandler<PsAsyncCompletedEventArgs>(this.ClipReceived);
                this.fileWebClient.ProgressChanged += new EventHandler<PsDownloadProgressChangedEventArgs>(this.ClipProgressChanged);
                this.fileWebClient.Encryptor = CryptographyHelper.MakeEncryptor();
                this.fileWebClient.DownloadFileAsync(videoUrl, fullPath, null);
            }
        }

        private void DownloadClipVideoAuthorizor(string offlineClipVideoUri)
        {
            this.memoryStreamWebClient = PsDownloadMemoryStreamWebClient.MakeDownloadMemoryStreamWebClient();
            this.memoryStreamWebClient.RequestCompleted += new EventHandler<PsDownloadMemoryStreamCompletedEventArgs>(this.OnReceiveCdnUri);
            this.memoryStreamWebClient.DownloadMemoryStreamAsync(offlineClipVideoUri, null);
        }

        private void FireCompletionEventOnError(Exception exception)
        {
            Exception error = exception;
            bool cancelled = false;
            object userState = null;
            AsyncCompletedEventArgs state = new AsyncCompletedEventArgs(error, cancelled, userState);
            this.syncContextHelper.Post<AsyncCompletedEventArgs>(state, x => this.RequestCompleted.TryFireEventFromModelThread<AsyncCompletedEventArgs>(this, x));
        }

        private void FireProgressChanged(PsDownloadProgressChangedEventArgs args)
        {
            this.clipToFetch.BytesFetched = args.BytesReceived;
            this.ProgressChanged.TryFireEventFromModelThread<PsDownloadProgressChangedEventArgs>(this, args);
        }

        private void FireRequestCompletedWithError(PsAsyncCompletedEventArgs e)
        {
            Exception error = e.Error;
            bool cancelled = false;
            object userState = null;
            AsyncCompletedEventArgs args = new AsyncCompletedEventArgs(error, cancelled, userState);
            this.RequestCompleted.TryFireEventFromModelThread<AsyncCompletedEventArgs>(this, args);
        }

        private void OnReceiveCdnUri(object sender, PsDownloadMemoryStreamCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                if (HttpStatusCode.Forbidden == e.Status)
                {
                    if (TokenHelper.FailedBecauseOfInvalidToken(e.Result))
                    {
                        if (!this.retryingWithFreshLoginToken)
                        {
                            this.retryingWithFreshLoginToken = true;
                            UserProfileLoader loader = new UserProfileLoader();
                            Creds creds = CredentialHelper.ReadCredentials();
                            if (null == creds)
                            {
                                TokenHelper.FailWithMissingCredentials(new Action<Exception>(this.FireCompletionEventOnError));
                            }
                            else
                            {
                                loader.LoadCompleted += new EventHandler<LoadCompletedEventArgs>(this.userProfileLoader_LoadCompleted);
                                loader.LoadUserProfileAsync(creds.Username, creds.Password, null);
                            }
                        }
                    }
                    else
                    {
                        TokenHelper.FailWithNotAuthorized(new Action<Exception>(this.FireCompletionEventOnError));
                    }
                }
                else
                {
                    this.syncContextHelper.Post<Exception>(e.Error, new Action<Exception>(this.FireCompletionEventOnError));
                }
            }
            else
            {
                this.DeserializeAuthorizeAndDownloadClip(e);
            }
        }

        private void UpdateStateAndContinue()
        {
            this.clipToFetch.LocalFileName = this.fileName;
            this.FireCompletionEventOnError(null);
        }

        private void userProfileLoader_LoadCompleted(object sender, LoadCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                this.syncContextHelper.Post<Exception>(e.Error, new Action<Exception>(this.FireCompletionEventOnError));
            }
            else
            {
                this.FetchOfflineClipAsync();
            }
        }

        #endregion Methods
    }
}