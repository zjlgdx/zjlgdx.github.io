﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    using System;

    public class OfflineModuleDto
    {
        #region Fields

        public OfflineClipDto[] Clips;
        public string CourseId;
        public DateTime ExpirationDateUtc;
        public string ModuleId;

        #endregion Fields
    }
}