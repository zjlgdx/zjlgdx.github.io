﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    using System;
    using System.ComponentModel;

    using Http;

    using Logging;

    using Models.OfflineModuleModel;
    using Models.Shared;

    using Shared;

    public class ModuleFetcher
    {
        #region Fields

        private static readonly ILog log = LogManager.GetLogger(typeof(OfflineClipFetcher));

        private readonly OfflineModule module;
        private readonly object state;
        private readonly SyncContextHelper syncContextHelper = SyncContextHelper.MakeSyncContextHelper();

        private volatile bool aborted;
        private OfflineClipFetcher clipFetcher;

        #endregion Fields

        #region Constructors

        public ModuleFetcher(OfflineModule module, object state)
        {
            this.module = module;
            this.state = state;
        }

        #endregion Constructors

        #region Events

        public event EventHandler<PsDownloadProgressChangedEventArgs> ProgressChanged;

        public event EventHandler<LoadCompletedEventArgs> RequestCompleted;

        #endregion Events

        #region Properties

        public string ModuleId
        {
            get
            {
                if (this.module == null)
                {
                    return "";
                }
                return this.module.ModuleId;
            }
        }

        private bool ModuleSizeIsKnown
        {
            get
            {
                return (0L != this.module.TotalClipSizeInBytes);
            }
        }

        #endregion Properties

        #region Methods

        public void Abort()
        {
            this.aborted = true;
            if (this.clipFetcher != null)
            {
                this.clipFetcher.Abort();
            }
        }

        public void FetchModuleAsync()
        {
            if (this.ModuleSizeIsKnown)
            {
                this.FetchNextClipAsync();
            }
            else
            {
                this.LoadModuleSizeAsync();
            }
        }

        public void FetchNextClipAsync()
        {
            this.clipFetcher = null;
            if (!this.MaybeFireAbortedCompletionEvent())
            {
                this.clipFetcher = new OfflineClipFetcher(this.module);
                this.clipFetcher.RequestCompleted += new EventHandler<AsyncCompletedEventArgs>(this.ReceivedClip);
                this.clipFetcher.ProgressChanged += new EventHandler<PsDownloadProgressChangedEventArgs>(this.ClipFetchProgressChangedReceived);
                this.clipFetcher.FetchOfflineClipAsync();
            }
        }

        private void ClipFetchProgressChangedReceived(object sender, PsDownloadProgressChangedEventArgs e)
        {
            long totalClipSizeInBytes = this.module.TotalClipSizeInBytes;
            long bytesReceived = this.module.TotalFetchedClipSizeInBytes + e.BytesReceived;
            long totalBytesExpected = totalClipSizeInBytes;
            object state = this.state;
            PsDownloadProgressChangedEventArgs args = new PsDownloadProgressChangedEventArgs(bytesReceived, totalBytesExpected, state);
            this.syncContextHelper.Post<PsDownloadProgressChangedEventArgs>(args, new Action<PsDownloadProgressChangedEventArgs>(this.UpdateModuleProgress));
        }

        private void FireRequestCompletedEventOnModelThread(AsyncCompletedEventArgs e)
        {
            LoadCompletedEventArgs state = new LoadCompletedEventArgs {
                State = this.state,
                Error = e.Error,
                Cancelled = this.aborted ? this.aborted : e.Cancelled
            };
            if ((e.Error != null) && !state.Cancelled)
            {
                log.Error(e.Error, null);
            }
            this.syncContextHelper.Post<LoadCompletedEventArgs>(state, x => this.RequestCompleted.TryFireEventFromModelThread<LoadCompletedEventArgs>(this, x));
        }

        private void LoadModuleSizeAsync()
        {
            if (!this.MaybeFireAbortedCompletionEvent())
            {
                ModuleSizeLoader loader = new ModuleSizeLoader(this.module.ModuleId, true);
                loader.RequestCompleted += new EventHandler<LoadCompletedEventArgs>(this.moduleSizeLoader_RequestCompleted);
                loader.LoadModuleSizeAsync();
            }
        }

        private bool MaybeFireAbortedCompletionEvent()
        {
            Action action = null;
            if (this.aborted)
            {
                if (action == null)
                {
                    action = delegate {
                    Action<Exception> ex = delegate (Exception x) {
                            this.FireRequestCompletedEventOnModelThread(new AsyncCompletedEventArgs(x, true, this.state));
                        };
                        ex.TryFireCancelledWebException();
                    };
                }
                this.syncContextHelper.Post(action);
            }
            return this.aborted;
        }

        private void moduleSizeLoader_RequestCompleted(object sender, LoadCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                log.Error(e.Error, null);
                LoadCompletedEventArgs args = new LoadCompletedEventArgs {
                    Error = e.Error,
                    State = this.state,
                    Cancelled = this.aborted
                };
                this.RequestCompleted.TryFireEventFromModelThread<LoadCompletedEventArgs>(this, args);
            }
            else
            {
                this.FetchNextClipAsync();
            }
        }

        private void ReceivedClip(object sender, AsyncCompletedEventArgs e)
        {
            if ((e.Error != null) || (this.module.FetchState == FetchState.FetchComplete))
            {
                this.FireRequestCompletedEventOnModelThread(e);
            }
            else
            {
                this.FetchNextClipAsync();
            }
        }

        private void UpdateModuleProgress(PsDownloadProgressChangedEventArgs e)
        {
            this.ProgressChanged.TryFireEventFromModelThread<PsDownloadProgressChangedEventArgs>(this, e);
        }

        #endregion Methods
    }
}