﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    using Shared;
    using Models.OfflineModuleModel;

    internal static class OfflineClipScavenger
    {
        #region Methods

        public static void DeleteOrphanedClips()
        {
            //HashSet<string> first = Enumerable.Select<string, string>(Directory.EnumerateFiles(Paths.ContentDir, "*"), new Func<string, string>(FileHelpers.CanonicalizePath)).ToHashSet<string>();
            //HashSet<string> second = Enumerable.Select<string, string>(Enumerable.Select<string, string>(from oc in from om in OfflineModuleManifest.Instance.OfflineModules select om.OfflineClips
            //    select oc.LocalFileName into localFileName
            //    where localFileName.HasContent()
            //    select localFileName, new Func<string, string>(Paths.LocalClipPath)), new Func<string, string>(FileHelpers.CanonicalizePath)).ToHashSet<string>();
            //foreach (string str in first.Except<string>(second))
            //{
            //    FileHelpers.DeleteQuietly(str);
            //}

            HashSet<string> hashSet = Enumerable.Select<string, string>(Directory.EnumerateFiles(Paths.ContentDir, "*"), new Func<string, string>(FileHelpers.CanonicalizePath)).ToHashSet<string>();
            HashSet<string> hashSet2 = Enumerable.Select<string, string>(Enumerable.Select<string, string>(Enumerable.Where<string>(Enumerable.Select<OfflineClip, string>(Enumerable.SelectMany<OfflineModule, OfflineClip>(OfflineModuleManifest.Instance.OfflineModules, (OfflineModule om) => om.OfflineClips), (OfflineClip oc) => oc.LocalFileName), (string localFileName) => localFileName.HasContent()), new Func<string, string>(Paths.LocalClipPath)), new Func<string, string>(FileHelpers.CanonicalizePath)).ToHashSet<string>();
            using (IEnumerator<string> enumerator = Enumerable.Except<string>(hashSet, hashSet2).GetEnumerator())
            {
                while (enumerator.MoveNext())
                {
                    string current = enumerator.Current;
                    FileHelpers.DeleteQuietly(current);
                }
            }
        }

        #endregion Methods
    }
}