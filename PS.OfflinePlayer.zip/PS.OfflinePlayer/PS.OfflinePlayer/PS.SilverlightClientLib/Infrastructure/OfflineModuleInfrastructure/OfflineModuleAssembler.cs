﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Models.OfflineModuleModel;

    public static class OfflineModuleAssembler
    {
        #region Methods

        public static OfflineModule AssembleOfflineModule(OfflineModuleDto dto)
        {
            string courseId = dto.CourseId;
            string moduleId = dto.ModuleId;
            DateTime expirationDateUtc = dto.ExpirationDateUtc;
            return new OfflineModule(courseId, moduleId, expirationDateUtc, AssembleOfflineClips(dto.Clips));
        }

        private static IEnumerable<OfflineClip> AssembleOfflineClips(IEnumerable<OfflineClipDto> clipDtos)
        {
            return Enumerable.Select<OfflineClipDto, OfflineClip>(clipDtos, (Func<OfflineClipDto, int, OfflineClip>) ((clipDto, clipIndex) => new OfflineClip(clipIndex) { FileSizeInBytes = new long?(clipDto.ClipSizeInBytes), LocalFileName = clipDto.LocalFileName })).ToArray<OfflineClip>();
        }

        #endregion Methods
    }
}