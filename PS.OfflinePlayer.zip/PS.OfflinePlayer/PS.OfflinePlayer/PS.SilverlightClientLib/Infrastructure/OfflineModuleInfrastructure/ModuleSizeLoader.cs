﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    using System;
    using System.ComponentModel;

    using App;

    using CatalogInfrastructure;

    using Http;

    using Logging;

    using Models.OfflineModuleModel;
    using Models.Shared;

    using Shared;

    internal class ModuleSizeLoader
    {
        #region Fields

        private static readonly ILog log = LogManager.GetLogger(typeof(ModuleSizeLoader));

        private readonly SyncContextHelper ctxHelper;
        private readonly bool isCritical;
        private readonly string moduleId;
        private readonly WebCatalogLoader webCatalogLoader = new WebCatalogLoader();

        private long[] clipSizes;

        #endregion Fields

        #region Constructors

        public ModuleSizeLoader(string moduleId, bool isCritical)
        {
            this.moduleId = moduleId;
            this.isCritical = isCritical;
            this.ctxHelper = SyncContextHelper.MakeSyncContextHelper();
        }

        #endregion Constructors

        #region Events

        public event EventHandler<LoadCompletedEventArgs> RequestCompleted;

        #endregion Events

        #region Methods

        public void LoadModuleSizeAsync()
        {
            PsDownloadMemoryStreamWebClient client = PsDownloadMemoryStreamWebClient.MakeDownloadMemoryStreamWebClient();
            client.RequestCompleted += new EventHandler<PsDownloadMemoryStreamCompletedEventArgs>(this.WebClientRequestCompleted);
            client.DownloadMemoryStreamAsync(Uris.ModuleSizeUri(this.moduleId), null);
        }

        private void LogError(AsyncCompletedEventArgs e)
        {
            if (!(e.Error is NetworkUnavailableException))
            {
                if (this.isCritical)
                {
                    log.Error("Failed to download module size", e.Error, null);
                }
                else
                {
                    log.Info("Failed to download module size", e.Error, null);
                }
            }
        }

        private void UpdateClipSizes()
        {
            OfflineModuleManifest.Instance.FindModule(this.moduleId).SetClipSizes(this.clipSizes);
            this.RequestCompleted.TryFireEventFromModelThread<LoadCompletedEventArgs>(this, new LoadCompletedEventArgs());
        }

        private void webCatalogLoader_LoadCompleted(object sender, LoadCompletedEventArgs args)
        {
            if (args.Error == null)
            {
                this.ctxHelper.Post(new Action(this.UpdateClipSizes));
            }
            else
            {
                this.ctxHelper.Post<Exception>(args.Error, delegate(Exception x)
                {
                    var eventArgs = new LoadCompletedEventArgs
                    {
                        Error = x
                    };
                    this.RequestCompleted.TryFireEventFromModelThread<LoadCompletedEventArgs>(this, eventArgs);
                });

            }
        }

        private void WebClientRequestCompleted(object sender, PsDownloadMemoryStreamCompletedEventArgs e)
        {
            Action<PsDownloadMemoryStreamCompletedEventArgs> action = null;
            if (e.Error != null)
            {
                this.LogError(e);
                if (action == null)
                {
                    action = delegate (PsDownloadMemoryStreamCompletedEventArgs x) {
                        LoadCompletedEventArgs args = new LoadCompletedEventArgs {
                            Error = e.Error
                        };
                        this.RequestCompleted.TryFireEventFromModelThread<LoadCompletedEventArgs>(this, args);
                    };
                }
                this.ctxHelper.Post<PsDownloadMemoryStreamCompletedEventArgs>(e, action);
            }
            else
            {
                ModuleSizeResponseDto dto = JsonSerializer.Deserialize<ModuleSizeResponseDto>(e.Result);
                this.clipSizes = dto.ClipSizes;
                if (AppState.Instance.CatalogEtag != dto.CatalogEtag)
                {
                    this.webCatalogLoader.LoadCompleted += new EventHandler<LoadCompletedEventArgs>(this.webCatalogLoader_LoadCompleted);
                    this.webCatalogLoader.LoadCatalogAsync(null);
                }
                else
                {
                    this.ctxHelper.Post(new Action(this.UpdateClipSizes));
                }
            }
        }

        #endregion Methods
    }
}