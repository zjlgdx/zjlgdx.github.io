﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    public class OfflineClipDto
    {
        #region Fields

        public long ClipSizeInBytes;
        public string LocalFileName;

        #endregion Fields
    }
}