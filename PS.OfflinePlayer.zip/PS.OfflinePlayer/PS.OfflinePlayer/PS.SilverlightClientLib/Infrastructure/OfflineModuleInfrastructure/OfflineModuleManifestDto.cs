﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    using System;

    public class OfflineModuleManifestDto
    {
        #region Fields

        public OfflineModuleDto[] OfflineModules;

        #endregion Fields
    }
}