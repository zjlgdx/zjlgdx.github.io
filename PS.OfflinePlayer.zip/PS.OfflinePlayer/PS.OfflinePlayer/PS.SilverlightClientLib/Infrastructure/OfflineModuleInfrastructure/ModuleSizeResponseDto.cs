﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    public class ModuleSizeResponseDto
    {
        #region Fields

        public string CatalogEtag;
        public long[] ClipSizes;

        #endregion Fields
    }
}