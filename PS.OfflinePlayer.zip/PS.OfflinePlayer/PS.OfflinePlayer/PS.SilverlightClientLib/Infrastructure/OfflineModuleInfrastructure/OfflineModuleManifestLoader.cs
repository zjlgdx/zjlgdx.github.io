﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Security.Cryptography;

    using Cryptography;
    using Shared;
    using Models.OfflineModuleModel;

    internal static class OfflineModuleManifestLoader
    {
        #region Methods

        public static void LoadOfflineModuleManifestFromDisk()
        {
            if (File.Exists(Paths.OfflineModuleManifestFile))
            {
                DiskEntityLoader.TryLoadEncryptedEntityFromDisk(Paths.OfflineModuleManifestFile, new Action<CryptoStream>(OfflineModuleManifestLoader.LoadManifestFromStream));
            }
        }

        public static OfflineModule OrphanIncompleteOrMissingClips(OfflineModule offlineModule)
        {
            foreach (OfflineClip clip in offlineModule.OfflineClips)
            {
                string path = Paths.LocalClipPath(clip.LocalFileName);
                if (clip.LocalFileName.HasContent() && (!File.Exists(path) || !LocalFileIsOfExpectedSize(clip, path)))
                {
                    clip.Orphan();
                }
            }
            return offlineModule;
        }

        public static void SaveOfflineModuleManifestToDisk()
        {
            OfflineModuleManifestDto dto = new OfflineModuleManifestDto {
                OfflineModules = Enumerable.Select<OfflineModule, OfflineModuleDto>(from x in OfflineModuleManifest.Instance.OfflineModules
                    //where !x.IsExpired
                    select x, new Func<OfflineModule, OfflineModuleDto>(OfflineModuleDtoAssembler.AssembleOfflineModuleDto)).ToArray<OfflineModuleDto>()
            };
            DiskEntityLoader.TrySaveEntityToDiskEncrypted<OfflineModuleManifestDto>(Paths.OfflineModuleManifestFile, dto);
        }

        private static void LoadManifestFromStream(CryptoStream cryptoStream)
        {
            List<OfflineModule> modules = (from x in Enumerable.Select<OfflineModule, OfflineModule>(Enumerable.Select<OfflineModuleDto, OfflineModule>(JsonSerializer.Deserialize<OfflineModuleManifestDto>(cryptoStream).OfflineModules, new Func<OfflineModuleDto, OfflineModule>(OfflineModuleAssembler.AssembleOfflineModule)), new Func<OfflineModule, OfflineModule>(OfflineModuleManifestLoader.OrphanIncompleteOrMissingClips))
                //where !x.IsExpired
                select x).ToList<OfflineModule>();
            OfflineModuleManifest.Instance.Initialize(modules);
        }

        private static bool LocalFileIsOfExpectedSize(OfflineClip offlineClip, string localClipPath)
        {
            long length = new FileInfo(localClipPath).Length;
            long num2 = CryptographyHelper.RoundUpFileSizeFor128BitPadding(offlineClip.FileSizeInBytes.ValueOrDefault<long>());
            return (length == num2);
        }

        #endregion Methods
    }
}