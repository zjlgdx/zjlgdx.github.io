﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineClipLogging
{
    using System;

    public static class OfflineClipLogActivityRecordDtoSerializer
    {
        #region Methods

        public static OfflineClipLogActivityRecordDto DeserializeOfflineClipLogActivityRecordDto(string input)
        {
            string[] strArray = input.Trim().Split(new char[] { '|' });
            if (strArray.Length != 5)
            {
                return null;
            }
            long ticks = long.Parse(strArray[4]);
            return new OfflineClipLogActivityRecordDto { ActivityId = Guid.Parse(strArray[0]), CourseId = strArray[1], ModuleId = strArray[2], ClipIndex = int.Parse(strArray[3]), ViewStartUtc = new DateTime(ticks) };
        }

        public static string SerializeOfflineClipLogActivityRecordDto(OfflineClipLogActivityRecordDto dto)
        {
            return string.Format("{0}|{1}|{2}|{3}|{4}", new object[] { dto.ActivityId.ToString("D"), dto.CourseId, dto.ModuleId, dto.ClipIndex, dto.ViewStartUtc.Ticks });
        }

        #endregion Methods
    }
}