﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineClipLogging
{
    using System;
    using System.ComponentModel;
    using System.IO;
    using System.Net;
    using System.Threading;

    using PS.SilverlightClientLib.Infrastructure.Http;
    using PS.SilverlightClientLib.Infrastructure.Shared;
    using PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure;
    using PS.SilverlightClientLib.Models.Shared;
    using PS.SilverlightClientLib.Models.UserProfileModel;

    public class OfflineClipActivityUploader
    {
        #region Fields

        private readonly MemoryStream clipEntityJson;
        private readonly object state;
        private readonly SyncContextHelper syncContextHelper = SyncContextHelper.MakeSyncContextHelper();

        private bool retryingWithFreshLoginToken;

        #endregion Fields

        #region Constructors

        public OfflineClipActivityUploader(MemoryStream clipEntityJson, object state)
        {
            this.clipEntityJson = clipEntityJson;
            this.state = state;
            if (this.syncContextHelper.NullContext)
            {
                throw new InvalidOperationException("Unable to capture a SynchronizationContext, attempts to return to model thread will fail");
            }
        }

        #endregion Constructors

        #region Events

        public event EventHandler<AsyncCompletedEventArgs> RequestCompleted;

        #endregion Events

        #region Methods

        public void PostClipActivitiesAsync()
        {
            this.DoPostClipActivitiesAsync();
        }

        private void DoPostClipActivitiesAsync()
        {
            if (!UserProfile.Instance.LoginTokenValue.HasContent())
            {
                if (!this.retryingWithFreshLoginToken)
                {
                    this.retryingWithFreshLoginToken = true;
                    this.LoadUserProfileAsync();
                }
                else
                {
                    TokenHelper.FailWithMissingCredentials(new Action<Exception>(this.PostToModelThreadAndThenFireCompletionEvent));
                }
            }
            else
            {
                string offlineActivityUri = Uris.OfflineActivityUri;
                PsUploadValuesWebClient client = PsUploadValuesWebClient.MakeUploadValuesWebClient();
                client.RequestCompleted += new EventHandler<PsDownloadMemoryStreamCompletedEventArgs>(this.webClient_RequestCompleted);
                client.UploadValuesAsync(offlineActivityUri, this.clipEntityJson, null);
            }
        }

        private void FireCompletionEvent(Exception exception)
        {
            Exception error = exception;
            bool cancelled = false;
            object state = this.state;
            AsyncCompletedEventArgs args = new AsyncCompletedEventArgs(error, cancelled, state);
            this.RequestCompleted.TryFireEventFromModelThread<AsyncCompletedEventArgs>(this, args);
        }

        private void LoadUserProfileAsync()
        {
            UserProfileLoader loader = new UserProfileLoader();
            Creds creds = CredentialHelper.ReadCredentials();
            if (null == creds)
            {
                TokenHelper.FailWithMissingCredentials(new Action<Exception>(this.PostToModelThreadAndThenFireCompletionEvent));
            }
            else
            {
                loader.LoadCompleted += new EventHandler<LoadCompletedEventArgs>(this.userProfileLoader_LoadCompleted);
                loader.LoadUserProfileAsync(creds.Username, creds.Password, null);
            }
        }

        private void PostToModelThreadAndThenFireCompletionEvent(Exception exception)
        {
            this.syncContextHelper.Post<Exception>(exception, new Action<Exception>(this.FireCompletionEvent));
        }

        private void userProfileLoader_LoadCompleted(object sender, LoadCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                this.PostToModelThreadAndThenFireCompletionEvent(e.Error);
            }
            else
            {
                this.DoPostClipActivitiesAsync();
            }
        }

        private void webClient_RequestCompleted(object sender, PsDownloadMemoryStreamCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                if (((HttpStatusCode.Forbidden == e.Status) && TokenHelper.FailedBecauseOfInvalidToken(e.Result)) && !this.retryingWithFreshLoginToken)
                {
                    this.retryingWithFreshLoginToken = true;
                    this.LoadUserProfileAsync();
                }
                else
                {
                    this.PostToModelThreadAndThenFireCompletionEvent(e.Error);
                }
            }
            else
            {
                this.PostToModelThreadAndThenFireCompletionEvent(null);
            }
        }

        #endregion Methods
    }
}