﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineClipLogging
{
    using System;
    using System.Runtime.CompilerServices;

    public class OfflineActivityRequestDto
    {
        #region Properties

        public string Format
        {
            get; set;
        }

        public string[] OfflineClipViews
        {
            get; set;
        }

        #endregion Properties
    }
}