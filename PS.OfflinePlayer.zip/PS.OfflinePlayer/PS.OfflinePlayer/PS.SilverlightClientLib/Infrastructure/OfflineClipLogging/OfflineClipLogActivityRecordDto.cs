﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineClipLogging
{
    using System;
    using System.Runtime.CompilerServices;

    public class OfflineClipLogActivityRecordDto : IEquatable<OfflineClipLogActivityRecordDto>
    {
        #region Properties

        public Guid ActivityId
        {
            get; set;
        }

        public int ClipIndex
        {
            get; set;
        }

        public string CourseId
        {
            get; set;
        }

        public string ModuleId
        {
            get; set;
        }

        public DateTime ViewStartUtc
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        public static bool operator !=(OfflineClipLogActivityRecordDto left, OfflineClipLogActivityRecordDto right)
        {
            return !object.Equals(left, right);
        }

        public static bool operator ==(OfflineClipLogActivityRecordDto left, OfflineClipLogActivityRecordDto right)
        {
            return object.Equals(left, right);
        }

        public bool Equals(OfflineClipLogActivityRecordDto other)
        {
            if (object.ReferenceEquals(null, other))
            {
                return false;
            }
            return (object.ReferenceEquals(this, other) || (((other.ActivityId.Equals(this.ActivityId) && object.Equals(other.CourseId, this.CourseId)) && (object.Equals(other.ModuleId, this.ModuleId) && (other.ClipIndex == this.ClipIndex))) && other.ViewStartUtc.Equals(this.ViewStartUtc)));
        }

        public override bool Equals(object obj)
        {
            if (object.ReferenceEquals(null, obj))
            {
                return false;
            }
            if (object.ReferenceEquals(this, obj))
            {
                return true;
            }
            if (obj.GetType() != typeof(OfflineClipLogActivityRecordDto))
            {
                return false;
            }
            return this.Equals((OfflineClipLogActivityRecordDto) obj);
        }

        public override int GetHashCode()
        {
            int num = (this.ActivityId.GetHashCode() * 0x18d) ^ ((this.CourseId != null) ? this.CourseId.GetHashCode() : 0);
            num = (num * 0x18d) ^ ((this.ModuleId != null) ? this.ModuleId.GetHashCode() : 0);
            num = (num * 0x18d) ^ this.ClipIndex;
            return ((num * 0x18d) ^ this.ViewStartUtc.GetHashCode());
        }

        public override string ToString()
        {
            return string.Format("ActivityId: {0}, CourseId: {1}, ModuleId: {2}, ClipIndex: {3}, ViewStartUtc: {4}", new object[] { this.ActivityId, this.CourseId, this.ModuleId, this.ClipIndex, this.ViewStartUtc });
        }

        #endregion Methods
    }
}