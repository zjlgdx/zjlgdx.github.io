﻿namespace PS.SilverlightClientLib.Infrastructure.OfflineClipLogging
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Runtime.Serialization;

    using PS.SilverlightClientLib.Infrastructure.Logging;
    using PS.SilverlightClientLib.Infrastructure.Shared;

    public static class OfflineActivityRequestDtoBuilder
    {
        #region Fields

        private static readonly ILog log = LogManager.GetLogger(typeof(OfflineActivityRequestDtoBuilder));

        #endregion Fields

        #region Methods

        public static MemoryStream BuildOfflineActivityRequestDtoMemoryStream(IEnumerable<OfflineClipLogActivityRecordDto> clipViews)
        {
            if (clipViews == null)
            {
                throw new ArgumentNullException("clipViews");
            }
            if (clipViews.IsEmpty<OfflineClipLogActivityRecordDto>())
            {
                throw new ArgumentException("Must have clips to transmit", "clipViews");
            }
            OfflineActivityRequestDto root = AssembleOfflineActivityRequestDto(clipViews);
            if ((root == null) || (root.OfflineClipViews == null))
            {
                log.Error("Serialization of OfflineClipViews resulted in empty collection", null, null);
                return null;
            }
            try
            {
                MemoryStream stream = new MemoryStream();
                JsonSerializer.Serialize<OfflineActivityRequestDto>(stream, root);
                stream.Rewind();
                return stream;
            }
            catch (SerializationException exception)
            {
                log.Error("Failed to serialize OfflineClipView: " + exception, null, null);
                return null;
            }
        }

        private static string[] AssembleClipViewItems(IEnumerable<OfflineClipLogActivityRecordDto> clipViews)
        {
            DateTime postTime = DateTime.UtcNow;
            return (from x in clipViews select AssembleClipViewLineItem(x, postTime)).ToArray<string>();
        }

        private static string AssembleClipViewLineItem(OfflineClipLogActivityRecordDto offlineClipLogActivityRecordDto, DateTime postTime)
        {
            TimeSpan span = (TimeSpan) (postTime - offlineClipLogActivityRecordDto.ViewStartUtc);
            long totalSeconds = (long) span.TotalSeconds;
            return string.Format("{0}/{1}/{2}/{3}", new object[] { offlineClipLogActivityRecordDto.CourseId, offlineClipLogActivityRecordDto.ModuleId, offlineClipLogActivityRecordDto.ClipIndex, totalSeconds });
        }

        private static OfflineActivityRequestDto AssembleOfflineActivityRequestDto(IEnumerable<OfflineClipLogActivityRecordDto> clipViews)
        {
            string[] strArray = AssembleClipViewItems(clipViews);
            return new OfflineActivityRequestDto { Format = "1024x768Wmv", OfflineClipViews = strArray };
        }

        #endregion Methods
    }
}