﻿namespace PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure
{
    using System;
    using System.Security.Cryptography;

    using PS.SilverlightClientLib.Infrastructure.Shared;
    using PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure.Dto;
    using PS.SilverlightClientLib.Models.UserProfileModel;

    internal class UserProfileDiskLoader
    {
        #region Fields

        private readonly string userName;

        #endregion Fields

        #region Constructors

        public UserProfileDiskLoader(string userName)
        {
            if (userName == null)
            {
                throw new ArgumentNullException("userName");
            }
            this.userName = userName;
        }

        #endregion Constructors

        #region Methods

        public bool LoadUserProfile()
        {
            return DiskEntityLoader.TryLoadEncryptedEntityFromDisk(Paths.UserProfileFile, new Action<CryptoStream>(this.LoadUserProfileFromStream));
        }

        public void PersistUserProfile(UserProfile userProfile)
        {
            if (userProfile == null)
            {
                throw new ArgumentNullException("userProfile");
            }
            UserProfileDto dto = UserProfileDtoAssembler.AssembleUserProfileDto(userProfile);
            DiskEntityLoader.TrySaveEntityToDiskEncrypted<UserProfileDto>(Paths.UserProfileFile, dto);
        }

        private void LoadUserProfileFromStream(CryptoStream cryptoStream)
        {
            UserProfileDto dto = JsonSerializer.Deserialize<UserProfileDto>(cryptoStream);
            if (dto != null)
            {
                UserProfile.SetUserProfile(UserProfileAssembler.AssembleUserProfile(this.userName, dto));
            }
        }

        #endregion Methods
    }
}