﻿namespace PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Threading;

    using PS.SilverlightClientLib.Infrastructure.Http;
    using PS.SilverlightClientLib.Infrastructure.Shared;
    using PS.SilverlightClientLib.Models.Shared;
    using PS.SilverlightClientLib.Models.UserProfileModel;

    internal class UserProfileLoader : IUserProfileLoader
    {
        #region Fields

        private readonly SyncContextHelper ctxHelper = SyncContextHelper.MakeSyncContextHelper();

        private string theUserName;

        #endregion Fields

        #region Constructors

        internal UserProfileLoader()
        {
        }

        #endregion Constructors

        #region Events

        public event EventHandler<LoadCompletedEventArgs> LoadCompleted;

        #endregion Events

        #region Methods

        public void LoadUserProfileAsync(string userName, string password, object state = null)
        {
            this.ThrowIfUserNameIsMalformed(userName);
            this.theUserName = userName;
            PsUploadValuesWebClient client = this.AssembleRequest();
            Dictionary<string, string> dictionary2 = new Dictionary<string, string>();
            dictionary2.Add("Password", password);
            Dictionary<string, string> values = dictionary2;
            client.UploadValuesAsync(Uris.LoginUri(userName), values, state);
        }

        public bool LoadUserProfileFromDisk(string userName)
        {
            UserProfileDiskLoader loader = new UserProfileDiskLoader(userName);
            return loader.LoadUserProfile();
        }

        private PsUploadValuesWebClient AssembleRequest()
        {
            PsUploadValuesWebClient client = PsUploadValuesWebClient.MakeUploadValuesWebClient();
            client.RequestCompleted += new EventHandler<PsDownloadMemoryStreamCompletedEventArgs>(this.WebClientRequestCompleted);
            return client;
        }

        private UserProfile BuildUserProfile(Stream stream)
        {
            UserProfileBuilder builder = new UserProfileBuilder(this.theUserName, stream);
            return builder.BuildUserProfile();
        }

        private void FireErrorEvent(Exception exception)
        {
            if (this.LoadCompleted != null)
            {
                LoadCompletedEventArgs state = new LoadCompletedEventArgs {
                    Error = exception
                };
                this.ctxHelper.Post<LoadCompletedEventArgs>(state, x => this.LoadCompleted(this, x));
            }
        }

        private void FireSuccessEvent()
        {
            if (this.LoadCompleted != null)
            {
                LoadCompletedEventArgs state = new LoadCompletedEventArgs();
                this.ctxHelper.Post<LoadCompletedEventArgs>(state, x => this.LoadCompleted(this, x));
            }
        }

        private void PersistUserProfile(UserProfile userProfile)
        {
            new UserProfileDiskLoader(this.theUserName).PersistUserProfile(userProfile);
        }

        private void ThrowIfUserNameIsMalformed(string userName)
        {
            if (!UserNameValidator.IsValidUserName(userName))
            {
                throw new ArgumentException("Malformed user name: " + userName);
            }
        }

        private void UpdateModel(UserProfile userProfile)
        {
            this.ctxHelper.Post<UserProfile>(userProfile, new Action<UserProfile>(UserProfile.SetUserProfile));
        }

        private void WebClientRequestCompleted(object sender, PsDownloadMemoryStreamCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                this.FireErrorEvent(e.Error);
            }
            else
            {
                UserProfile userProfile = this.BuildUserProfile(e.Result);
                this.PersistUserProfile(userProfile);
                this.UpdateModel(userProfile);
                this.FireSuccessEvent();
            }
        }

        #endregion Methods
    }
}