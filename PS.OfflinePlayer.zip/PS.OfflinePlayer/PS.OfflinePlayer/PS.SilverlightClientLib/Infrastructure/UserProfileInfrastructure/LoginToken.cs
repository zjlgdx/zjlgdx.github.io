﻿namespace PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure
{
    using System;

    public class LoginToken
    {
        #region Fields

        public readonly DateTime ExpiresForDebuggingOnly;
        public readonly string TokenValue;

        #endregion Fields

        #region Constructors

        public LoginToken(string tokenValue, DateTime expiresForDebuggingOnly)
        {
            this.TokenValue = tokenValue;
            this.ExpiresForDebuggingOnly = expiresForDebuggingOnly;
        }

        #endregion Constructors
    }
}