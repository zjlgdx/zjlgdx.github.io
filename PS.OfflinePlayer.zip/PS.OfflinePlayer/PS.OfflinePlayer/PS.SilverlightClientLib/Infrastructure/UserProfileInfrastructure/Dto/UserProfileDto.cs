﻿namespace PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure.Dto
{
    using System;

    public class UserProfileDto
    {
        #region Fields

        public bool AllowOfflineViewing;
        public string FirstName;
        public OfflineViewingParametersDto OfflineViewingParameters;
        public string SubscriptionLevel;

        #endregion Fields
    }
}