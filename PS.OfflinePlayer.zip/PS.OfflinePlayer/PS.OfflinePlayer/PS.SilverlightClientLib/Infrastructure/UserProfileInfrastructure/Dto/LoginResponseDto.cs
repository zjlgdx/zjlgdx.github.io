﻿namespace PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure.Dto
{
    using System;

    public class LoginResponseDto
    {
        #region Fields

        public string Expires;
        public string Token;
        public UserProfileDto UserProfile;

        #endregion Fields
    }
}