﻿namespace PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure.Dto
{
    using System;

    using PS.SilverlightClientLib.Models.UserProfileModel;

    internal static class UserProfileDtoAssembler
    {
        #region Methods

        internal static UserProfileDto AssembleUserProfileDto(UserProfile userProfile)
        {
            return new UserProfileDto { AllowOfflineViewing = userProfile.AllowOfflineViewing, FirstName = userProfile.FirstName, OfflineViewingParameters = AssembleOfflineViewingParametersDto(userProfile.OfflineViewingParameters), SubscriptionLevel = userProfile.SubscriptionLevel };
        }

        private static OfflineViewingParametersDto AssembleOfflineViewingParametersDto(OfflineViewingParameters offlineViewingParameters)
        {
            if (offlineViewingParameters == null)
            {
                return null;
            }
            return new OfflineViewingParametersDto { MaxDaysBeforeExpire = offlineViewingParameters.MaxDaysBeforeExpire, MaxModulesToCache = offlineViewingParameters.MaxModulesToCache };
        }

        #endregion Methods
    }
}