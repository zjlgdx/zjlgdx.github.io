﻿namespace PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure.Dto
{
    using System;

    public class OfflineViewingParametersDto
    {
        #region Fields

        public int MaxDaysBeforeExpire;
        public int MaxModulesToCache;

        #endregion Fields
    }
}