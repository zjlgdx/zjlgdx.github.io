﻿namespace PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure.Dto
{
    using System;

    using PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure;
    using PS.SilverlightClientLib.Models.UserProfileModel;

    internal class UserProfileAssembler
    {
        #region Methods

        internal static UserProfile AssembleUserProfile(string userName, UserProfileDto dto)
        {
            string str = userName;
            string firstName = dto.FirstName;
            string subscriptionLevel = dto.SubscriptionLevel;
            return new UserProfile(str, firstName, subscriptionLevel, UserProfileBuilder.AssembleOfflineViewingParameters(dto.OfflineViewingParameters));
        }

        #endregion Methods
    }
}