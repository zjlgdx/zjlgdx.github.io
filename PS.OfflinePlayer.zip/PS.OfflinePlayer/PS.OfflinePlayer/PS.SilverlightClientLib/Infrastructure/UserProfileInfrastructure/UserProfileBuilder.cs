﻿namespace PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure
{
    using System;
    using System.IO;

    using PS.SilverlightClientLib.Infrastructure.Shared;
    using PS.SilverlightClientLib.Infrastructure.UserProfileInfrastructure.Dto;
    using PS.SilverlightClientLib.Models.UserProfileModel;

    internal class UserProfileBuilder
    {
        #region Fields

        private readonly Stream jsonStream;
        private readonly string userName;

        #endregion Fields

        #region Constructors

        public UserProfileBuilder(string userName, Stream jsonStream)
        {
            this.userName = userName;
            this.jsonStream = jsonStream;
        }

        #endregion Constructors

        #region Methods

        public UserProfile BuildUserProfile()
        {
            LoginResponseDto dto = JsonSerializer.Deserialize<LoginResponseDto>(this.jsonStream);
            return this.AssembleUserProfile(dto);
        }

        internal static OfflineViewingParameters AssembleOfflineViewingParameters(OfflineViewingParametersDto dto)
        {
            if (dto == null)
            {
                return null;
            }
            int maxDaysBeforeExpire = dto.MaxDaysBeforeExpire;
            return new OfflineViewingParameters(maxDaysBeforeExpire, dto.MaxModulesToCache);
        }

        private LoginToken AssembleLoginToken(LoginResponseDto dto)
        {
            DateTime time;
            DateTime.TryParse(dto.Expires, out time);
            if (new DateTime() != time)
            {
                time = time.ToUniversalTime();
            }
            return new LoginToken(dto.Token, time);
        }

        private UserProfile AssembleUserProfile(LoginResponseDto dto)
        {
            UserProfileDto userProfile = dto.UserProfile;
            string userName = this.userName;
            string firstName = userProfile.FirstName;
            string subscriptionLevel = userProfile.SubscriptionLevel;
            OfflineViewingParameters offlineViewingParameters = AssembleOfflineViewingParameters(userProfile.OfflineViewingParameters);
            return new UserProfile(userName, firstName, subscriptionLevel, offlineViewingParameters, this.AssembleLoginToken(dto));
        }

        #endregion Methods
    }
}