﻿namespace PS.SilverlightClientLib.Infrastructure.App
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows;

    using Models.Shared;

    public static class ScreenSizeTrackerAssembler
    {
        #region Methods

        public static Dictionary<string, ScreenSize> AssemblePreferredScreenSizes(ScreenSizeTrackerDto screenSizeTrackerDto)
        {
            if (screenSizeTrackerDto == null)
            {
                return new Dictionary<string, ScreenSize>();
            }
            return Enumerable.ToDictionary<PreferredScreenSizeDto, string, ScreenSize>(screenSizeTrackerDto.PreferredScreenSizes, dto => dto.Name, delegate (PreferredScreenSizeDto dto)
            {
                double width = dto.Width;
                double height = dto.Height;
                return new ScreenSize(dto.IsFullScreen, new Size(width, height));
            });
        }

        public static ScreenSizeTracker AssembleScreenSizeTracker(ScreenSizeTrackerDto dto)
        {
            return new ScreenSizeTracker(AssemblePreferredScreenSizes(dto));
        }

        #endregion Methods
    }
}