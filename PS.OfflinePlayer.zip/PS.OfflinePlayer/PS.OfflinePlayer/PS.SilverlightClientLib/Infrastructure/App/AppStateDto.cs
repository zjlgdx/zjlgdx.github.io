﻿namespace PS.SilverlightClientLib.Infrastructure.App
{
    using System.Windows;

    using Shared;

    public class AppStateDto
    {
        #region Fields

        public string CatalogEtag;
        public double ChoosePageVerticalOffset;
        public Point MainWindowOrigin;
        public ScreenSizeTrackerDto ScreenSizeTracker;

        #endregion Fields

        #region Constructors

        public AppStateDto()
        {
            ReflectionHelper.InitStringProperties(this);
        }

        #endregion Constructors
    }
}