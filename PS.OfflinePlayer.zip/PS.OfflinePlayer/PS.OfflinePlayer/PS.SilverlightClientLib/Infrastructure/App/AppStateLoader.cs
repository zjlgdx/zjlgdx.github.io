﻿namespace PS.SilverlightClientLib.Infrastructure.App
{
    using System;
    using System.IO;
    using System.Security.Cryptography;

    using Shared;

    internal class AppStateLoader
    {
        #region Methods

        public void LoadAppState()
        {
            if (!DiskEntityLoader.TryLoadEncryptedEntityFromDisk(Paths.AppStateFile, new Action<CryptoStream>(this.LoadAppStateFromStream)))
            {
                AppState.Instance = this.CreateDefaultAppState();
            }
        }

        public void SaveAppState()
        {
            try
            {
                AppStateDto dto = this.AssembleAppStateDto(AppState.Instance);
                DiskEntityLoader.TrySaveEntityToDiskEncrypted<AppStateDto>(Paths.AppStateFile, dto);
            }
            catch (DirectoryNotFoundException)
            {
            }
        }

        private AppState AssembleAppState(AppStateDto dto)
        {
            return new AppState
            {
            CatalogEtag = dto.CatalogEtag,
            ScreenSizeTracker = ScreenSizeTrackerAssembler.AssembleScreenSizeTracker(dto.ScreenSizeTracker),
            MainWindowOrigin = dto.MainWindowOrigin,
            ChoosePageVerticalOffset = dto.ChoosePageVerticalOffset
            };
        }

        private AppStateDto AssembleAppStateDto(AppState appState)
        {
            return new AppStateDto
            {
            CatalogEtag = appState.CatalogEtag,
            ScreenSizeTracker = ScreenSizeTrackerDtoAssembler.AssembleScreenSizeTrackerDto(appState.ScreenSizeTracker),
            MainWindowOrigin = appState.MainWindowOrigin,
            ChoosePageVerticalOffset = appState.ChoosePageVerticalOffset
            };
        }

        private AppState CreateDefaultAppState()
        {
            return new AppState();
        }

        private void LoadAppStateFromStream(CryptoStream cryptoStream)
        {
            AppStateDto dto = JsonSerializer.Deserialize<AppStateDto>(cryptoStream);
            AppState.Instance = this.AssembleAppState(dto);
        }

        #endregion Methods
    }
}