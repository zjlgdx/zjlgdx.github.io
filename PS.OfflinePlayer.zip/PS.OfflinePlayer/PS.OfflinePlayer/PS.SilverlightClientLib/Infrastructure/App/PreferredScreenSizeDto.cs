﻿namespace PS.SilverlightClientLib.Infrastructure.App
{
    public class PreferredScreenSizeDto
    {
        #region Fields

        public double Height;
        public bool IsFullScreen;
        public string Name;
        public double Width;

        #endregion Fields
    }
}