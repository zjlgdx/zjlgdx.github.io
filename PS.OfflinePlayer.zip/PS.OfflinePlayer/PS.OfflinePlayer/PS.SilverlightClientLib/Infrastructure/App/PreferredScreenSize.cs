﻿namespace PS.SilverlightClientLib.Infrastructure.App
{
    using System.Windows;

    internal class PreferredScreenSize
    {
        #region Fields

        public readonly string Name;
        public readonly Size size;

        #endregion Fields

        #region Constructors

        public PreferredScreenSize(string name, Size size)
        {
            this.Name = name;
            this.size = size;
        }

        #endregion Constructors
    }
}