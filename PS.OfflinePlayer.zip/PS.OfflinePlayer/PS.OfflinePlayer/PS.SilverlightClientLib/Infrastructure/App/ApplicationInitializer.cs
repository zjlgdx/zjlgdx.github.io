﻿namespace PS.SilverlightClientLib.Infrastructure.App
{
    using System.Net;
    using System.Net.Browser;

    using CatalogInfrastructure;

    using Cryptography;

    using Infrastructure;

    using Logging;

    using Models.CatalogModel;
    using Models.Shared;
    using Models.UserProfileModel;

    using OfflineModuleInfrastructure;

    using Shared;

    public class ApplicationInitializer
    {
        #region Methods

        public static void InitLogManager()
        {
            LogManager.Initialize(Paths.LogFilePath);
        }

        public void Initialize()
        {
            this.InitializeModelThread();
            this.InitializeBaseUris();
            this.InitializeHttpStack();
            InitLogManager();
            this.EnsureNecessaryDirectoriesArePresent();
            this.InitKeyManagement();
            this.LoadAppState();
            this.LoadCatalog();
            this.LoadOfflineModuleManifest();
            this.DeleteOrphanedClips();
            this.InitOfflineClipViewLogger();
            this.LoadUserProfileFromDisk();
        }

        public void Shutdown()
        {
            OfflineModuleManifestLoader.SaveOfflineModuleManifestToDisk();
            SaveAppState();
        }

        private static void LoadCatalogFromDisk()
        {
            new DiskCatalogLoader(null).LoadCatalog();
        }

        private static void SaveAppState()
        {
            new AppStateLoader().SaveAppState();
        }

        private void DeleteOrphanedClips()
        {
            OfflineClipScavenger.DeleteOrphanedClips();
        }

        private void EnsureNecessaryDirectoriesArePresent()
        {
            Paths.EnsureNecessaryDirectoriesArePresent();
        }

        private void InitializeBaseUris()
        {
            // modify by yyb
            //Config.Initialize(Application.Current.Host.Source.OriginalString);
            Config.Initialize("http://pluralsight.com/training/players/pluralsight.offlineplayer.xap");
        }

        private void InitializeHttpStack()
        {
            string[] strArray = new string[] { "http", "https" };
            foreach (string str in strArray)
            {
                WebRequest.RegisterPrefix(str + "://", WebRequestCreator.ClientHttp);
            }
        }

        private void InitializeModelThread()
        {
            ThreadHelper.MarkThisThreadAsTheModelThread();
        }

        private void InitKeyManagement()
        {
            if (KeyfileHelper.ReadFileEncryptionKey() == null)
            {
                KeyfileHelper.GenerateAndPersistFileEncryptionKey();
            }
        }

        private void InitOfflineClipViewLogger()
        {
            OfflineClipViewLogger.Instance.Initialize();
        }

        private void LoadAppState()
        {
            new AppStateLoader().LoadAppState();
        }

        private void LoadCatalog()
        {
            Catalog.Instance = new Catalog();
            LoadCatalogFromDisk();
            this.LoadCatalogFromWebAsync();
        }

        private void LoadCatalogFromWebAsync()
        {
            new WebCatalogLoader().LoadCatalogAsync(null);
        }

        private void LoadOfflineModuleManifest()
        {
            OfflineModuleManifestLoader.LoadOfflineModuleManifestFromDisk();
        }

        private void LoadUserProfileFromDisk()
        {
            Creds creds = CredentialHelper.ReadCredentials();
            if (null != creds)
            {
                UserProfile.MakeLoader().LoadUserProfileFromDisk(creds.Username);
            }
        }

        #endregion Methods
    }
}