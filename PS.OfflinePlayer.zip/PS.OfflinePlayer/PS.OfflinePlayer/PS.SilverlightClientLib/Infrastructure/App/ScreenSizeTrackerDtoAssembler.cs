﻿namespace PS.SilverlightClientLib.Infrastructure.App
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Models.Shared;

    public static class ScreenSizeTrackerDtoAssembler
    {
        #region Methods

        public static PreferredScreenSizeDto AssemblePreferredScreenSizeDto(KeyValuePair<string, ScreenSize> keyValuePair)
        {
            ScreenSize size = keyValuePair.Value;
            return new PreferredScreenSizeDto
            {
                Name = keyValuePair.Key,
                IsFullScreen = size.IsFullScreen,
                Width = size.Size.Width,
                Height = size.Size.Height
            };
        }

        public static ScreenSizeTrackerDto AssembleScreenSizeTrackerDto(ScreenSizeTracker screenSizeTracker)
        {
            return new ScreenSizeTrackerDto
            {
                PreferredScreenSizes = AssemblePreferredScreenSizeDtos(screenSizeTracker.PreferredScreenSizes)
            };
        }

        private static PreferredScreenSizeDto[] AssemblePreferredScreenSizeDtos(Dictionary<string, ScreenSize> preferredScreenSizes)
        {
            return Enumerable.Select<KeyValuePair<string, ScreenSize>, PreferredScreenSizeDto>(preferredScreenSizes, new Func<KeyValuePair<string, ScreenSize>, PreferredScreenSizeDto>(ScreenSizeTrackerDtoAssembler.AssemblePreferredScreenSizeDto)).ToArray<PreferredScreenSizeDto>();
        }

        #endregion Methods
    }
}