﻿namespace PS.SilverlightClientLib.Infrastructure.App
{
    public class ScreenSizeTrackerDto
    {
        #region Fields

        public PreferredScreenSizeDto[] PreferredScreenSizes;

        #endregion Fields
    }
}