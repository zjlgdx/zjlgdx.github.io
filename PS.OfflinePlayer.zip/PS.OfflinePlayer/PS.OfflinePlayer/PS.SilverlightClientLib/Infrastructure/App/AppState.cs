﻿namespace PS.SilverlightClientLib.Infrastructure.App
{
    using System.Windows;

    using Models.Shared;

    public class AppState
    {
        #region Constructors

        public AppState()
        {
            this.CatalogEtag = "";
            this.ScreenSizeTracker = new ScreenSizeTracker(null);
        }

        #endregion Constructors

        #region Properties

        public static AppState Instance
        {
            get;
            set;
        }

        public double ChoosePageVerticalOffset
        {
            get; set;
        }

        public bool IsExiting
        {
            get; set;
        }

        public Point MainWindowOrigin
        {
            get; set;
        }

        public ScreenSizeTracker ScreenSizeTracker
        {
            get; internal set;
        }

        internal string CatalogEtag
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        internal void ClearCatalogEtag()
        {
            this.CatalogEtag = "";
        }

        internal void SetCatalogEtag(string eTag)
        {
            this.CatalogEtag = eTag;
        }

        #endregion Methods
    }
}