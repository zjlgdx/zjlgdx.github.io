﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.Net;

    using Shared;

    internal class PsDownloadMemoryStreamWebClient : PsWebClientDownloadMemoryStreamBase
    {
        #region Fields

        internal static Func<PsDownloadMemoryStreamWebClient> MakeDownloadMemoryStreamWebClient = () => new PsDownloadMemoryStreamWebClient();

        private HttpWebRequest httpRequest;

        #endregion Fields

        #region Events

        public event EventHandler<PsDownloadMemoryStreamCompletedEventArgs> RequestCompleted;

        #endregion Events

        #region Properties

        protected override HttpWebRequest CurrentRequest
        {
            get
            {
                return this.httpRequest;
            }
        }

        #endregion Properties

        #region Methods

        public void DownloadMemoryStreamAsync(string uri, object state)
        {
            if (!Network.IsAvailable)
            {
                base.FireMemoryStreamNetworkUnavailableCompletion(this.RequestCompleted, state);
            }
            else
            {
                this.httpRequest = base.PrepareHttpRequest(uri);
                this.httpRequest.BeginGetResponse(new AsyncCallback(this.DownloadMemoryStreamResponseCompleted), new HttpAsyncState(this.httpRequest, state));
            }
        }

        protected override void RetryResponseIntoMemoryStreamAsync(HttpAsyncState httpState)
        {
            this.DownloadMemoryStreamAsync(httpState.WebRequest.RequestUri.OriginalString, httpState.State);
        }

        private void DownloadMemoryStreamResponseCompleted(IAsyncResult asyncResult)
        {
            base.ReadResponseIntoMemoryStream(asyncResult, this.RequestCompleted);
        }

        #endregion Methods
    }
}