﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.IO;
    using System.Net;

    using Shared;

    internal class DefaultRetryStrategy : IRetryStrategy
    {
        #region Properties

        public int MaximumRetries
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        public bool ShouldRetry(Exception x)
        {
            if (x is IOException)
            {
                return Network.IsAvailable;
            }
            WebException exception2 = x as WebException;
            if (exception2 == null)
            {
                return false;
            }
            HttpWebResponse response = (HttpWebResponse) exception2.Response;
            return (response.StatusCode >= HttpStatusCode.InternalServerError);
        }

        #endregion Methods
    }
}