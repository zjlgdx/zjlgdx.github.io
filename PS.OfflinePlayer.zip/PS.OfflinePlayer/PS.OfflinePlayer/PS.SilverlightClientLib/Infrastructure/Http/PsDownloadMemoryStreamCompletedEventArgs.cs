﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.IO;

    public class PsDownloadMemoryStreamCompletedEventArgs : PsAsyncCompletedEventArgs
    {
        #region Constructors

        public PsDownloadMemoryStreamCompletedEventArgs(Exception error, bool cancelled, object userState)
            : base(error, cancelled, userState)
        {
        }

        #endregion Constructors

        #region Properties

        public MemoryStream Result
        {
            get; internal set;
        }

        #endregion Properties
    }
}