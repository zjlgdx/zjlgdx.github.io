﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.Net;

    internal class HttpUploadValuesAsyncState : HttpAsyncState
    {
        #region Fields

        internal readonly byte[] FormData;

        #endregion Fields

        #region Constructors

        public HttpUploadValuesAsyncState(HttpWebRequest webRequest, object state, byte[] formData)
            : base(webRequest, state)
        {
            this.FormData = formData;
        }

        #endregion Constructors
    }
}