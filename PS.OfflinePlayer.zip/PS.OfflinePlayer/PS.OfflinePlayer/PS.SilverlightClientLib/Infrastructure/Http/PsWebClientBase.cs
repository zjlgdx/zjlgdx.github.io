﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;

    using Logging;
    using Shared;

    internal abstract class PsWebClientBase
    {
        #region Fields

        protected static readonly ILog log = LogManager.GetLogger(typeof(PsWebClientBase));

        protected int numRetries;

        private volatile bool aborted;

        #endregion Fields

        #region Constructors

        protected PsWebClientBase()
        {
            this.RequestHeaders = new Dictionary<string, string>();
            DefaultRetryStrategy strategy = new DefaultRetryStrategy {
                MaximumRetries = 3
            };
            this.RetryStrategy = strategy;
        }

        #endregion Constructors

        #region Properties

        public IDictionary<string, string> RequestHeaders
        {
            get; private set;
        }

        public IRetryStrategy RetryStrategy
        {
            get; set;
        }

        protected virtual HttpWebRequest CurrentRequest
        {
            get
            {
                return null;
            }
        }

        protected bool HasBeenAborted
        {
            get
            {
                return this.aborted;
            }
        }

        #endregion Properties

        #region Methods

        public void Abort()
        {
            this.aborted = true;
            HttpWebRequest currentRequest = this.CurrentRequest;
            if (currentRequest != null)
            {
                currentRequest.Abort();
            }
            log.Info("Request explicitly aborted", null, null);
        }

        protected static Dictionary<string, string> AssembleResponseHeaders(HttpWebResponse response)
        {
            if (response == null)
            {
                return new Dictionary<string, string>();
            }
            return Enumerable.ToDictionary<string, string, string>(response.Headers.AllKeys, (Func<string, string>) (key => key), (Func<string, string>) (key => response.Headers[key]));
        }

        protected static HttpStatusCode AssembleStatusCode(HttpWebResponse response)
        {
            if (response != null)
            {
                return response.StatusCode;
            }
            return (HttpStatusCode) 0;
        }

        protected bool CanRetryIfExceptionAndCountPermit(Exception exception)
        {
            if (this.HasBeenAborted)
            {
                return false;
            }
            return (this.RetryStrategy.ShouldRetry(exception) && (this.numRetries++ < this.RetryStrategy.MaximumRetries));
        }

        protected virtual void FireProgressEvent(long totalBytesToRead, long bytesReadSoFar)
        {
        }

        protected MemoryStream GetExceptionResponseMemoryStream(WebException webException)
        {
            HttpWebResponse response = (HttpWebResponse) webException.Response;
            MemoryStream stream = this.PumpWebExceptionResponse(response);
            string str = this.ExtractErrorResponseWithoutDisposingStream(stream);
            stream.Rewind();
            if (response != null)
            {
                log.Error(string.Format("Response failed with {0} and response {1}", response.StatusCode, str), null, null);
                return stream;
            }
            string message = string.Format("Response failed with WebException status: {0}", webException.Status);
            if (webException.Status == WebExceptionStatus.RequestCanceled)
            {
                log.Info(message, null, null);
                return stream;
            }
            log.Error(message, null, null);
            return stream;
        }

        protected HttpWebRequest PrepareHttpRequest(string uri)
        {
            HttpWebRequest request = (HttpWebRequest) WebRequest.Create(uri);
            foreach (KeyValuePair<string, string> pair in this.RequestHeaders)
            {
                request.Headers[pair.Key] = pair.Value;
            }
            return request;
        }

        protected void PumpStreamWithProgress(Stream outputStream, Stream responseStream, long contentLength)
        {
            int num;
            byte[] buffer = new byte[0x1000];
            long totalBytesToRead = contentLength;
            long bytesReadSoFar = 0L;
            long num4 = totalBytesToRead / 100L;
            long num5 = 0L;
            while ((num = responseStream.Read(buffer, 0, buffer.Length)) > 0)
            {
                bytesReadSoFar += num;
                outputStream.Write(buffer, 0, num);
                if (((num5 == 0L) || (bytesReadSoFar > (num5 + num4))) || (bytesReadSoFar == totalBytesToRead))
                {
                    this.FireProgressEvent(totalBytesToRead, bytesReadSoFar);
                    num5 = bytesReadSoFar;
                }
            }
        }

        protected MemoryStream PumpWebExceptionResponse(HttpWebResponse response)
        {
            MemoryStream destination = new MemoryStream();
            if (response != null)
            {
                Stream responseStream = response.GetResponseStream();
                if (responseStream == null)
                {
                    return destination;
                }
                responseStream.CopyTo(destination);
                destination.Rewind();
            }
            return destination;
        }

        private string ExtractErrorResponseWithoutDisposingStream(Stream stream)
        {
            try
            {
                StreamReader reader = new StreamReader(stream);
                return reader.ReadToEnd();
            }
            catch (Exception)
            {
                return "ExtractErrorResponse failed to read response stream";
            }
        }

        #endregion Methods
    }
}