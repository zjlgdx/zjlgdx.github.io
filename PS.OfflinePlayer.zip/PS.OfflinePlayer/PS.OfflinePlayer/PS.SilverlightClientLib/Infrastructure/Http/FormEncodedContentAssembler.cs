﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Shared;

    internal class FormEncodedContentAssembler
    {
        #region Fields

        private readonly IDictionary<string, string> formValues;

        #endregion Fields

        #region Constructors

        public FormEncodedContentAssembler(IDictionary<string, string> formValues)
        {
            this.formValues = formValues;
        }

        #endregion Constructors

        #region Methods

        public byte[] AssembleFormEncodedContent()
        {
            IEnumerable<string> values = from x in this.formValues select string.Format("{0}={1}", x.Key.UrlEncode(), x.Value.UrlEncode());
            string s = string.Join("&", values);
            return Encoding.UTF8.GetBytes(s);
        }

        #endregion Methods
    }
}