﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.Net;

    internal class HttpAsyncState
    {
        #region Fields

        public readonly object State;
        public readonly HttpWebRequest WebRequest;

        #endregion Fields

        #region Constructors

        public HttpAsyncState(HttpWebRequest webRequest, object state)
        {
            this.WebRequest = webRequest;
            this.State = state;
        }

        #endregion Constructors
    }
}