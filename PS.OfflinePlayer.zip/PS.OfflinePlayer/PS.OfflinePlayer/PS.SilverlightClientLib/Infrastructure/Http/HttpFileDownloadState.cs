﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.Net;

    internal class HttpFileDownloadState : HttpAsyncState
    {
        #region Fields

        public readonly string FilePath;

        #endregion Fields

        #region Constructors

        public HttpFileDownloadState(HttpWebRequest webRequest, object state, string filePath)
            : base(webRequest, state)
        {
            this.FilePath = filePath;
        }

        #endregion Constructors
    }
}