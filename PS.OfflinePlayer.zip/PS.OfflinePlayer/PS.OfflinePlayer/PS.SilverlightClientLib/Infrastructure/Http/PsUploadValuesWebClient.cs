﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Net;

    using Shared;

    internal class PsUploadValuesWebClient : PsWebClientDownloadMemoryStreamBase
    {
        #region Fields

        internal static Func<PsUploadValuesWebClient> MakeUploadValuesWebClient = () => new PsUploadValuesWebClient();

        #endregion Fields

        #region Events

        public event EventHandler<PsDownloadMemoryStreamCompletedEventArgs> RequestCompleted;

        #endregion Events

        #region Methods

        public void UploadValuesAsync(string uri, IDictionary<string, string> values, object state)
        {
            byte[] formBytes = new FormEncodedContentAssembler(values).AssembleFormEncodedContent();
            this.UploadValuesAsync(uri, formBytes, state, "application/x-www-form-urlencoded; charset=utf-8");
        }

        public void UploadValuesAsync(string uri, MemoryStream jsonMemoryStream, object state)
        {
            byte[] formBytes = jsonMemoryStream.ToArray();
            this.UploadValuesAsync(uri, formBytes, state, "application/json");
        }

        public void UploadValuesGetRequestStreamCompleted(IAsyncResult asyncResult)
        {
            HttpUploadValuesAsyncState asyncState = (HttpUploadValuesAsyncState) asyncResult.AsyncState;
            try
            {
                using (Stream stream = asyncState.WebRequest.EndGetRequestStream(asyncResult))
                {
                    stream.Write(asyncState.FormData, 0, asyncState.FormData.Length);
                }
                asyncState.WebRequest.BeginGetResponse(new AsyncCallback(this.UploadValuesResponseCompleted), asyncState);
            }
            catch (IOException exception)
            {
                if (!this.RetryAsync(exception, asyncState))
                {
                    MemoryStream memoryStream = null;
                    HttpWebResponse response = null;
                    object state = asyncState.State;
                    Exception exception3 = exception;
                    base.FireDownloadMemoryStreamAsyncCompletion(this.RequestCompleted, memoryStream, response, state, exception3);
                }
            }
            catch (WebException exception2)
            {
                if (!this.RetryAsync(exception2, asyncState))
                {
                    MemoryStream stream3 = null;
                    HttpWebResponse response2 = (HttpWebResponse) exception2.Response;
                    object obj3 = asyncState.State;
                    Exception exception4 = exception2;
                    base.FireDownloadMemoryStreamAsyncCompletion(this.RequestCompleted, stream3, response2, obj3, exception4);
                }
            }
        }

        protected override void RetryResponseIntoMemoryStreamAsync(HttpAsyncState state)
        {
            HttpUploadValuesAsyncState state2 = (HttpUploadValuesAsyncState) state;
            this.UploadValuesAsync(state2.WebRequest.RequestUri.OriginalString, state2.FormData, state2.State, "application/x-www-form-urlencoded; charset=utf-8");
        }

        private bool RetryAsync(Exception exception, HttpUploadValuesAsyncState httpState)
        {
            if (base.CanRetryIfExceptionAndCountPermit(exception))
            {
                this.UploadValuesAsync(httpState.WebRequest.RequestUri.OriginalString, httpState.FormData, httpState.State, "application/x-www-form-urlencoded; charset=utf-8");
                return true;
            }
            return false;
        }

        private void UploadValuesAsync(string uri, byte[] formBytes, object state, string contentType = "application/x-www-form-urlencoded; charset=utf-8")
        {
            if (!Network.IsAvailable)
            {
                base.FireMemoryStreamNetworkUnavailableCompletion(this.RequestCompleted, state);
            }
            else
            {
                HttpWebRequest webRequest = base.PrepareHttpRequest(uri);
                webRequest.Method = "POST";
                webRequest.ContentType = contentType;
                webRequest.BeginGetRequestStream(new AsyncCallback(this.UploadValuesGetRequestStreamCompleted), new HttpUploadValuesAsyncState(webRequest, state, formBytes));
            }
        }

        private void UploadValuesResponseCompleted(IAsyncResult asyncResult)
        {
            base.ReadResponseIntoMemoryStream(asyncResult, this.RequestCompleted);
        }

        #endregion Methods
    }
}