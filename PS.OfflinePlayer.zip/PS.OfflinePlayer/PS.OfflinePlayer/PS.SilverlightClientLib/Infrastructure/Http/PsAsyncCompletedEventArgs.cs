﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Net;

    public class PsAsyncCompletedEventArgs : AsyncCompletedEventArgs
    {
        #region Constructors

        public PsAsyncCompletedEventArgs(Exception error, bool cancelled, object userState)
            : base(error, cancelled, userState)
        {
        }

        #endregion Constructors

        #region Properties

        public MemoryStream ExceptionResponseStream
        {
            get; internal set;
        }

        public IDictionary<string, string> ResponseHeaders
        {
            get; internal set;
        }

        public HttpStatusCode Status
        {
            get; internal set;
        }

        #endregion Properties
    }
}