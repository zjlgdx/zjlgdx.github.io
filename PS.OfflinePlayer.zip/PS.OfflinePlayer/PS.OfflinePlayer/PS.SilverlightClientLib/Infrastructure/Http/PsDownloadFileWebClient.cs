﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.IO;
    using System.Net;
    using System.Security.Cryptography;

    using Shared;

    internal class PsDownloadFileWebClient : PsWebClientBase
    {
        #region Fields

        internal static Func<PsDownloadFileWebClient> MakeDownloadFileWebClient = () => new PsDownloadFileWebClient();

        private HttpWebRequest httpRequest;
        private bool startedPumping;

        #endregion Fields
        
        #region Events

        public event EventHandler<PsDownloadProgressChangedEventArgs> ProgressChanged;

        public event EventHandler<PsAsyncCompletedEventArgs> RequestCompleted;

        #endregion Events

        #region Properties

        public ICryptoTransform Encryptor
        {
            get; set;
        }

        protected override HttpWebRequest CurrentRequest
        {
            get
            {
                return this.httpRequest;
            }
        }

        #endregion Properties

        #region Methods

        public void DownloadFileAsync(string uri, string path, object state)
        {
            if (!Network.IsAvailable)
            {
                this.FireNetworkUnavailableError(state);
            }
            else
            {
                this.httpRequest = base.PrepareHttpRequest(uri);
                object obj2 = state;
                HttpWebRequest httpRequest = this.httpRequest;
                string filePath = path;
                this.httpRequest.BeginGetResponse(new AsyncCallback(this.OnDownloadFileAsyncCompletion), new HttpFileDownloadState(httpRequest, obj2, filePath));
            }
        }

        protected override void FireProgressEvent(long totalBytesToRead, long bytesReadSoFar)
        {
            if (this.ProgressChanged != null)
            {
                long bytesReceived = bytesReadSoFar;
                long totalBytesExpected = totalBytesToRead;
                this.ProgressChanged(this, new PsDownloadProgressChangedEventArgs(bytesReceived, totalBytesExpected, null));
            }
        }

        private void CleanupPartialDownload(string filePath)
        {
            if (this.startedPumping)
            {
                FileHelpers.DeleteQuietly(filePath);
            }
        }

        private void FireDownloadFileCompletion(HttpAsyncState httpState, HttpWebResponse response, Exception error = null, MemoryStream exceptionResponseStream = null)
        {
            if (this.RequestCompleted != null)
            {
                PsAsyncCompletedEventArgs e = new PsAsyncCompletedEventArgs(error, false, httpState.State) {
                    ResponseHeaders = PsWebClientBase.AssembleResponseHeaders(response),
                    Status = PsWebClientBase.AssembleStatusCode(response),
                    ExceptionResponseStream = exceptionResponseStream
                };
                this.RequestCompleted(this, e);
            }
        }

        private void FireNetworkUnavailableError(object state)
        {
            try
            {
                throw new NetworkUnavailableException();
            }
            catch (NetworkUnavailableException exception)
            {
                this.FireDownloadFileCompletion(new HttpAsyncState(null, state), null, exception, null);
            }
        }

        private void OnDownloadFileAsyncCompletion(IAsyncResult asyncResult)
        {
            HttpFileDownloadState asyncState = (HttpFileDownloadState) asyncResult.AsyncState;
            try
            {
                using (HttpWebResponse response = (HttpWebResponse) asyncState.WebRequest.EndGetResponse(asyncResult))
                {
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        this.PumpResponseIntoFile(asyncState, response);
                    }
                    this.FireDownloadFileCompletion(asyncState, response, null, null);
                }
            }
            catch (IOException exception)
            {
                if (!this.RetryAsync(exception, asyncState))
                {
                    this.CleanupPartialDownload(asyncState.FilePath);
                    this.FireDownloadFileCompletion(asyncState, null, exception, null);
                }
            }
            catch (WebException exception2)
            {
                if (!this.RetryAsync(exception2, asyncState))
                {
                    this.CleanupPartialDownload(asyncState.FilePath);
                    this.FireDownloadFileCompletion(asyncState, (HttpWebResponse) exception2.Response, exception2, base.GetExceptionResponseMemoryStream(exception2));
                }
            }
            catch (CryptographicException exception3)
            {
                if (!this.RetryAsync(exception3, asyncState))
                {
                    this.CleanupPartialDownload(asyncState.FilePath);
                    this.FireDownloadFileCompletion(asyncState, null, exception3, null);
                }
            }
            if (this.Encryptor != null)
            {
                this.Encryptor.Dispose();
                this.Encryptor = null;
            }
        }

        private void PumpResponseIntoFile(HttpFileDownloadState httpState, HttpWebResponse response)
        {
            if (response.ContentLength == 0L)
            {
                PsWebClientBase.log.Warn(string.Format("Got 0 content length with status of: {0}, SupportHeaders = {1} for file {2}", response.StatusCode, response.SupportsHeaders, httpState.FilePath), null, null);
            }
            else
            {
                this.startedPumping = true;
                using (Stream stream = response.GetResponseStream())
                {
                    using (FileStream stream2 = File.Create(httpState.FilePath))
                    {
                        if (this.Encryptor != null)
                        {
                            using (CryptoStream stream3 = new CryptoStream(stream2, this.Encryptor, CryptoStreamMode.Write))
                            {
                                base.PumpStreamWithProgress(stream3, stream, response.ContentLength);
                                return;
                            }
                        }
                        base.PumpStreamWithProgress(stream2, stream, response.ContentLength);
                    }
                }
            }
        }

        private bool RetryAsync(Exception exception, HttpFileDownloadState httpState)
        {
            if (base.CanRetryIfExceptionAndCountPermit(exception))
            {
                this.DownloadFileAsync(httpState.WebRequest.RequestUri.OriginalString, httpState.FilePath, httpState.State);
                return true;
            }
            return false;
        }

        #endregion Methods
    }
}