﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;
    using System.IO;
    using System.Net;

    using Shared;

    internal abstract class PsWebClientDownloadMemoryStreamBase : PsWebClientBase
    {
        #region Constructors

        protected PsWebClientDownloadMemoryStreamBase()
        {
        }

        #endregion Constructors

        #region Methods

        protected void FireDownloadMemoryStreamAsyncCompletion(EventHandler<PsDownloadMemoryStreamCompletedEventArgs> anEvent, MemoryStream memoryStream, HttpWebResponse response, object state, Exception exception = null)
        {
            if (anEvent != null)
            {
                PsDownloadMemoryStreamCompletedEventArgs e = new PsDownloadMemoryStreamCompletedEventArgs(exception, false, state) {
                    Result = memoryStream,
                    ResponseHeaders = PsWebClientBase.AssembleResponseHeaders(response),
                    Status = PsWebClientBase.AssembleStatusCode(response)
                };
                anEvent(this, e);
            }
        }

        protected void FireMemoryStreamNetworkUnavailableCompletion(EventHandler<PsDownloadMemoryStreamCompletedEventArgs> anEvent, object state)
        {
            try
            {
                throw new NetworkUnavailableException();
            }
            catch (NetworkUnavailableException exception)
            {
                MemoryStream memoryStream = null;
                HttpWebResponse response = null;
                object obj2 = state;
                Exception exception2 = exception;
                this.FireDownloadMemoryStreamAsyncCompletion(anEvent, memoryStream, response, obj2, exception2);
            }
        }

        protected void ReadResponseIntoMemoryStream(IAsyncResult asyncResult, EventHandler<PsDownloadMemoryStreamCompletedEventArgs> anEvent)
        {
            HttpAsyncState asyncState = (HttpAsyncState) asyncResult.AsyncState;
            try
            {
                using (HttpWebResponse response = (HttpWebResponse) asyncState.WebRequest.EndGetResponse(asyncResult))
                {
                    using (Stream stream = response.GetResponseStream())
                    {
                        byte[] buffer = new byte[response.ContentLength];
                        MemoryStream outputStream = new MemoryStream(buffer);
                        base.PumpStreamWithProgress(outputStream, stream, response.ContentLength);
                        outputStream.Rewind();
                        this.FireDownloadMemoryStreamAsyncCompletion(anEvent, outputStream, response, asyncState.State, null);
                    }
                }
            }
            catch (IOException exception)
            {
                if (!this.RetryMemoryStreamAsync(exception, asyncState))
                {
                    MemoryStream memoryStream = null;
                    HttpWebResponse response2 = null;
                    object state = asyncState.State;
                    Exception exception3 = exception;
                    this.FireDownloadMemoryStreamAsyncCompletion(anEvent, memoryStream, response2, state, exception3);
                }
            }
            catch (WebException exception2)
            {
                if (!this.RetryMemoryStreamAsync(exception2, asyncState))
                {
                    MemoryStream exceptionResponseMemoryStream = base.GetExceptionResponseMemoryStream(exception2);
                    HttpWebResponse response3 = (HttpWebResponse) exception2.Response;
                    object obj3 = asyncState.State;
                    Exception exception4 = exception2;
                    this.FireDownloadMemoryStreamAsyncCompletion(anEvent, exceptionResponseMemoryStream, response3, obj3, exception4);
                }
            }
        }

        protected abstract void RetryResponseIntoMemoryStreamAsync(HttpAsyncState state);

        private bool RetryMemoryStreamAsync(Exception exception, HttpAsyncState httpState)
        {
            if (base.CanRetryIfExceptionAndCountPermit(exception))
            {
                this.RetryResponseIntoMemoryStreamAsync(httpState);
                return true;
            }
            return false;
        }

        #endregion Methods
    }
}