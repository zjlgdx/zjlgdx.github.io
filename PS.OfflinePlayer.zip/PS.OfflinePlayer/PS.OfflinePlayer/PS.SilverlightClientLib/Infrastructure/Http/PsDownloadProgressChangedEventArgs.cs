﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;

    public class PsDownloadProgressChangedEventArgs : EventArgs
    {
        #region Fields

        public readonly long BytesReceived;
        public readonly object State;
        public readonly long TotalBytesExpected;

        #endregion Fields

        #region Constructors

        public PsDownloadProgressChangedEventArgs(long bytesReceived, long totalBytesExpected, object state = null)
        {
            this.State = state;
            this.BytesReceived = bytesReceived;
            this.TotalBytesExpected = totalBytesExpected;
        }

        #endregion Constructors
    }
}