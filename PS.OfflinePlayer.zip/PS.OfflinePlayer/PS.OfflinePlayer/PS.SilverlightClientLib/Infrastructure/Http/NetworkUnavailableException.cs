﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;

    public class NetworkUnavailableException : Exception
    {
        #region Constructors

        public NetworkUnavailableException()
            : base("The network is unavailable, please try again later")
        {
        }

        #endregion Constructors
    }
}