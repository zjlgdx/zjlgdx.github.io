﻿namespace PS.SilverlightClientLib.Infrastructure.Http
{
    using System;

    public interface IRetryStrategy
    {
        #region Properties

        int MaximumRetries
        {
            get;
        }

        #endregion Properties

        #region Methods

        bool ShouldRetry(Exception x);

        #endregion Methods
    }
}