﻿namespace PS.SilverlightClientLib.Infrastructure.Cryptography
{
    using System;
    using System.IO;
    using System.Security.Cryptography;

    using Shared;

    public static class KeyfileHelper
    {
        #region Fields

        private const int KeyStartOffset = 0x400;
        private const int SizeOfKeyFile = 0x1000;

        #endregion Fields

        #region Methods

        public static void GenerateAndPersistFileEncryptionKey()
        {
            using (FileStream stream = File.OpenWrite(Paths.KeyFile))
            {
                byte[] buffer = GenerateRandomKey(0x1000);
                stream.Write(buffer, 0, buffer.Length);
            }
        }

        public static byte[] GenerateRandomKey(int sizeInBytes)
        {
            if (sizeInBytes <= 0)
            {
                throw new ArgumentException("must be a positive integer", "sizeInBytes");
            }
            RNGCryptoServiceProvider provider = new RNGCryptoServiceProvider();
            byte[] data = new byte[sizeInBytes];
            provider.GetBytes(data);
            return data;
        }

        public static byte[] ReadFileEncryptionKey()
        {
            string keyFile = Paths.KeyFile;
            if (!File.Exists(keyFile))
            {
                return null;
            }
            using (FileStream stream = File.OpenRead(keyFile))
            {
                byte[] buffer = new byte[0x10];
                if (0x400L != stream.Seek(0x400L, SeekOrigin.Begin))
                {
                    return null;
                }
                return ((stream.Read(buffer, 0, buffer.Length) != buffer.Length) ? null : buffer);
            }
        }

        public static byte[] ReadOrGenerateNewKey()
        {
            byte[] buffer = ReadFileEncryptionKey();
            if (buffer == null)
            {
                GenerateAndPersistFileEncryptionKey();
                buffer = ReadFileEncryptionKey();
            }
            return buffer;
        }

        #endregion Methods
    }
}