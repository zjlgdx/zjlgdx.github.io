﻿namespace PS.SilverlightClientLib.Infrastructure.Cryptography
{
    using System.IO;
    using System.Security.Cryptography;

    using Shared;

    public static class CryptographyHelper
    {
        #region Fields

        private const int BlockSizeInBytes = 0x10;

        #endregion Fields

        #region Methods

        public static ICryptoTransform MakeDecryptor()
        {
            return MakeDecryptor(KeyfileHelper.ReadOrGenerateNewKey());
        }

        public static ICryptoTransform MakeDecryptor(byte[] key)
        {
            byte[] rgbIV = MakeZeroIv();
            using (AesManaged managed = new AesManaged())
            {
                return managed.CreateDecryptor(key, rgbIV);
            }
        }

        public static ICryptoTransform MakeEncryptor()
        {
            return MakeEncryptor(KeyfileHelper.ReadOrGenerateNewKey());
        }

        public static ICryptoTransform MakeEncryptor(byte[] key)
        {
            byte[] rgbIV = MakeZeroIv();
            using (AesManaged managed = new AesManaged())
            {
                return managed.CreateEncryptor(key, rgbIV);
            }
        }

        public static byte[] MakeZeroIv()
        {
            return new byte[0x10];
        }

        public static Stream OpenBufferedDecryptionStream(string filePath, long videoFileSize)
        {
            return new BufferingSeekableDecryptionStream(File.OpenRead(filePath), videoFileSize);
        }

        public static long RoundUpFileSizeFor128BitPadding(long originalSize)
        {
            return ((originalSize + 0x10L) - (originalSize % 0x10L));
        }

        #endregion Methods
    }
}