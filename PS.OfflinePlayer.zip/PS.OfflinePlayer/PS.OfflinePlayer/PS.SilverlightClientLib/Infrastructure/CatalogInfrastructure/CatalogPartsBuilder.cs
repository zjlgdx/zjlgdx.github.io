﻿namespace PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    using Dto;
    using Shared;
    using Models.CatalogModel;

    internal class CatalogPartsBuilder
    {
        #region Fields

        private readonly Stream stream;

        private CatalogDto catalogDto;
        private int nextCategoryId;

        #endregion Fields

        #region Constructors

        public CatalogPartsBuilder(Stream stream)
        {
            this.stream = stream;
        }

        #endregion Constructors

        #region Methods

        internal CatalogParts BuildCatalogParts()
        {
            this.catalogDto = JsonSerializer.Deserialize<CatalogDto>(this.stream);
            return this.AssembleCatalogParts();
        }

        private static Clip AssembleClip(ClipDto clipDto, int index)
        {
            int clipIndex = index;
            string title = clipDto.Title;
            TimeSpan duration = TimeSpan.FromSeconds((double) clipDto.Duration);
            return new Clip(clipIndex, title, duration, clipDto.AllowAnonymous);
        }

        private static string AssembleModuleId(ModuleDto moduleDto, AuthorDto authorDto)
        {
            return (authorDto.Handle + "/" + moduleDto.Name);
        }

        private Dictionary<string, Author> AssembleAuthors()
        {
            return Enumerable.ToDictionary<Author, string>(from author in this.catalogDto.Authors
            select new Author(author.Handle, author.DisplayName),
            (Func<Author, string>) (x => x.Id));
        }

        private CatalogParts AssembleCatalogParts()
        {
            return new CatalogParts
            {
                Authors = this.AssembleAuthors(),
                Modules = this.AssembleModules(),
                Courses = this.AssembleCourses(),
                Categories = this.AssembleCategories()
            };
        }

        private Dictionary<string, Category> AssembleCategories()
        {
            return Enumerable.ToDictionary<Category, string>(Enumerable.Select<string, Category>(this.catalogDto.Categories, new Func<string, Category>(this.AssembleCategory)), (Func<Category, string>) (x => x.Id));
        }

        private Category AssembleCategory(string categoryTitle)
        {
            int categoryId = this.nextCategoryId++;
            return new Category(categoryId.ToString(), categoryTitle, this.AssembleCourseIdsForCategory(categoryId));
        }

        private IEnumerable<Clip> AssembleClips(ModuleDto moduleDto)
        {
            return Enumerable.Select<ClipDto, Clip>(moduleDto.Clips, new Func<ClipDto, int, Clip>(CatalogPartsBuilder.AssembleClip)).ToArray<Clip>();
        }

        private Course AssembleCourse(CourseDto courseDto)
        {
            int category = courseDto.Category;
            string name = courseDto.Name;
            string title = courseDto.Title;
            string categoryId = category.ToString();
            string categoryTitle = this.catalogDto.Categories[category];
            string description = courseDto.Description;
            string level = courseDto.Level;
            TimeSpan duration = TimeSpan.FromSeconds((double) courseDto.Duration);
            bool isNew = courseDto.New;
            return new Course(name, title, categoryId, categoryTitle, description, level, duration, isNew, this.AssembleModuleIds(courseDto.Modules));
        }

        private IEnumerable<string> AssembleCourseIdsForCategory(int categoryId)
        {
            return (from x in this.catalogDto.Courses
                where x.Category == categoryId
                select x.Name).ToArray<string>();
        }

        private Dictionary<string, Course> AssembleCourses()
        {
            return Enumerable.ToDictionary<Course, string>(Enumerable.Select<CourseDto, Course>(this.catalogDto.Courses, new Func<CourseDto, Course>(this.AssembleCourse)), (Func<Course, string>) (course => course.Id));
        }

        private Module AssembleModule(ModuleDto moduleDto, AuthorDto authorDto)
        {
            string id = AssembleModuleId(moduleDto, authorDto);
            string displayName = authorDto.DisplayName;
            string title = moduleDto.Title;
            TimeSpan duration = TimeSpan.FromSeconds((double) moduleDto.Duration);
            return new Module(id, displayName, title, duration, this.AssembleClips(moduleDto));
        }

        private string AssembleModuleId(string moduleIndexAsString)
        {
            int index = int.Parse(moduleIndexAsString);
            ModuleDto moduleDto = this.catalogDto.Modules[index];
            AuthorDto authorDto = this.catalogDto.Authors[moduleDto.Author];
            return AssembleModuleId(moduleDto, authorDto);
        }

        private IEnumerable<string> AssembleModuleIds(string moduleIndeces)
        {
            return Enumerable.Select<string, string>(moduleIndeces.Split(new char[] { ',' }), new Func<string, string>(this.AssembleModuleId)).ToArray<string>();
        }

        private Dictionary<string, Module> AssembleModules()
        {
            return Enumerable.ToDictionary<Module, string>(from module in this.catalogDto.Modules select this.AssembleModule(module, this.catalogDto.Authors[module.Author]), (Func<Module, string>) (x => x.Id));
        }

        #endregion Methods
    }
}