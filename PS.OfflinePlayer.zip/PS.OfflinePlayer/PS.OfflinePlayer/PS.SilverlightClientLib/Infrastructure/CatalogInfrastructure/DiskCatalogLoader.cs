﻿namespace PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure
{
    using System;
    using System.IO;
    using System.Security.Cryptography;

    using App;
    using Shared;
    using Models.CatalogModel;

    internal class DiskCatalogLoader
    {
        #region Fields

        private readonly SyncContextHelper ctxHelper;

        #endregion Fields

        #region Constructors

        public DiskCatalogLoader(SyncContextHelper ctxHelper = null)
        {
            this.ctxHelper = ctxHelper ?? SyncContextHelper.MakeEmptySyncContextHelper();
        }

        #endregion Constructors

        #region Properties

        public string ComputedEtag
        {
            get; private set;
        }

        #endregion Properties

        #region Methods

        public void ComputeCatalogETagFromDisk()
        {
            if (DiskEntityLoader.TryLoadEncryptedEntityFromDisk(Paths.CourseCatalogPath, new Action<CryptoStream>(this.ComputeSha1FromDisk)))
            {
                this.SetCatalogEtag(this.ComputedEtag);
            }
        }

        public void LoadCatalog()
        {
            if (!DiskEntityLoader.TryLoadEncryptedEntityFromDisk(Paths.CourseCatalogPath, new Action<CryptoStream>(this.LoadCatalogFromStream)))
            {
                this.ClearEtagSinceLocalCatalogIsNotAvailable();
            }
        }

        private CatalogParts BuildCatalog(Stream stream)
        {
            CatalogPartsBuilder builder = new CatalogPartsBuilder(stream);
            return builder.BuildCatalogParts();
        }

        private void ClearEtagSinceLocalCatalogIsNotAvailable()
        {
            AppState.Instance.ClearCatalogEtag();
        }

        private void ComputeSha1FromDisk(CryptoStream stream)
        {
            using (SHA1Managed managed = new SHA1Managed())
            {
                managed.ComputeHash(stream);
                string str = Convert.ToBase64String(managed.Hash);
                this.ComputedEtag = str;
            }
        }

        private void LoadCatalogFromStream(CryptoStream cryptoStream)
        {
            CatalogParts state = this.BuildCatalog(cryptoStream);
            this.ctxHelper.Post<CatalogParts>(state, new Action<CatalogParts>(((Catalog) Catalog.Instance).SetCatalogParts));
        }

        private void SetCatalogEtag(string computedEtag)
        {
            AppState.Instance.SetCatalogEtag(computedEtag);
        }

        #endregion Methods
    }
}