﻿namespace PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure.Dto
{
    using System;

    public class ClipDto
    {
        public bool AllowAnonymous;
        public int Duration;
        public string Title;
    }
}

