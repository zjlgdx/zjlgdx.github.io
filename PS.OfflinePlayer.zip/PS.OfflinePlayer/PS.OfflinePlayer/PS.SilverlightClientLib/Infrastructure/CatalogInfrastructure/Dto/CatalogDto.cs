﻿namespace PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure.Dto
{
    using System;

    public class CatalogDto
    {
        public AuthorDto[] Authors;
        public string[] Categories;
        public CourseDto[] Courses;
        public ModuleDto[] Modules;
    }
}

