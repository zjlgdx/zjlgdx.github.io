﻿namespace PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure.Dto
{
    using System;

    public class ModuleDto
    {
        public int Author;
        public ClipDto[] Clips;
        public int Duration;
        public string Name;
        public string Title;
    }
}

