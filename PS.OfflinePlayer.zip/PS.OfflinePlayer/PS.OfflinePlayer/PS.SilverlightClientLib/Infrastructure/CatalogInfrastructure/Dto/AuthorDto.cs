﻿namespace PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure.Dto
{
    using System;

    public class AuthorDto
    {
        public string DisplayName;
        public string Handle;
    }
}

