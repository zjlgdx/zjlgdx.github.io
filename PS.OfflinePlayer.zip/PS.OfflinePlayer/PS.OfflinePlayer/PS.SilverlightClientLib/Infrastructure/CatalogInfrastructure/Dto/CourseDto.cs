﻿namespace PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure.Dto
{
    using System;

    public class CourseDto
    {
        public int Category;
        public string Description;
        public int Duration;
        public string Level;
        public string Modules;
        public string Name;
        public bool New;
        public string Title;
    }
}

