﻿namespace PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure
{
    using System.Collections.Generic;

    using Models.CatalogModel;

    internal class CatalogParts
    {
        #region Fields

        public IDictionary<string, Author> Authors = new Dictionary<string, Author>();
        public IDictionary<string, Category> Categories = new Dictionary<string, Category>();
        public IDictionary<string, Course> Courses = new Dictionary<string, Course>();
        public IDictionary<string, Module> Modules = new Dictionary<string, Module>();

        #endregion Fields
    }
}