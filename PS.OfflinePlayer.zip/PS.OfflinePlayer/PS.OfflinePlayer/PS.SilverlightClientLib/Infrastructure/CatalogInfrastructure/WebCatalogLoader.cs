﻿namespace PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure
{
    using System;
    using System.Net;

    using App;
    using Cryptography;
    using Http;
    using Logging;
    using Shared;
    using Models.CatalogModel;
    using Models.Shared;

    internal class WebCatalogLoader : IWebCatalogLoader
    {
        #region Fields

        private static readonly ILog log = LogManager.GetLogger(typeof(WebCatalogLoader));

        private readonly SyncContextHelper ctxHelper = SyncContextHelper.MakeSyncContextHelper();

        #endregion Fields

        #region Constructors

        internal WebCatalogLoader()
        {
        }

        #endregion Constructors

        #region Events

        public event EventHandler<LoadCompletedEventArgs> LoadCompleted;

        public event EventHandler<PsDownloadProgressChangedEventArgs> ProgressChanged;

        #endregion Events

        #region Methods

        public void LoadCatalogAsync(object state = null)
        {
            this.AssembleConditionalGet(AppState.Instance.CatalogEtag).DownloadFileAsync(Uris.CourseCatalogUri, Paths.CourseCatalogPath, state);
        }

        private PsDownloadFileWebClient AssembleConditionalGet(string etag)
        {
            PsDownloadFileWebClient client = PsDownloadFileWebClient.MakeDownloadFileWebClient();
            if (etag.HasContent())
            {
                client.RequestHeaders["If-None-Match"] = etag;
            }
            client.ProgressChanged += new EventHandler<PsDownloadProgressChangedEventArgs>(this.WebClientProgressChanged);
            client.RequestCompleted += new EventHandler<PsAsyncCompletedEventArgs>(this.WebClientRequestCompleted);
            client.Encryptor = CryptographyHelper.MakeEncryptor();
            return client;
        }

        private void FireErrorEvent(Exception exception)
        {
            if (this.LoadCompleted != null)
            {
                LoadCompletedEventArgs state = new LoadCompletedEventArgs {
                    Error = exception
                };
                this.ctxHelper.Post<LoadCompletedEventArgs>(state, x => this.LoadCompleted(this, x));
            }
        }

        private void FireSuccessEvent()
        {
            if (this.LoadCompleted != null)
            {
                LoadCompletedEventArgs state = new LoadCompletedEventArgs();
                this.ctxHelper.Post<LoadCompletedEventArgs>(state, x => this.LoadCompleted(this, x));
            }
        }

        private void LoadCatalogFromDisk()
        {
            new DiskCatalogLoader(this.ctxHelper).LoadCatalog();
        }

        private void WebClientProgressChanged(object sender, PsDownloadProgressChangedEventArgs e)
        {
            if (this.ProgressChanged != null)
            {
                this.ctxHelper.Post<PsDownloadProgressChangedEventArgs>(e, x => this.ProgressChanged(this, e));
            }
        }

        private void WebClientRequestCompleted(object sender, PsAsyncCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (HttpStatusCode.OK == e.Status)
                {
                    string str;
                    e.ResponseHeaders.TryGetValue("ETag", out str);
                    if (string.IsNullOrEmpty(str))
                    {
                        log.Info("Catalog downloaded with status 200 but no ETag", null, null);
                        str = "";
                    }
                    AppState.Instance.CatalogEtag = str;
                    this.LoadCatalogFromDisk();
                    if (!str.HasContent())
                    {
                        new DiskCatalogLoader(this.ctxHelper).ComputeCatalogETagFromDisk();
                    }
                }
                this.FireSuccessEvent();
            }
            else
            {
                this.FireErrorEvent(e.Error);
            }
        }

        #endregion Methods
    }
}