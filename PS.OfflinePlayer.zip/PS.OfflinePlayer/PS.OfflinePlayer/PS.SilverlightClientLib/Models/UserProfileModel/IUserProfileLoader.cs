﻿namespace PS.SilverlightClientLib.Models.UserProfileModel
{
    using System;

    using Shared;

    public interface IUserProfileLoader
    {
        #region Events

        event EventHandler<LoadCompletedEventArgs> LoadCompleted;

        #endregion Events

        #region Methods

        void LoadUserProfileAsync(string userName, string password, object state = null);

        bool LoadUserProfileFromDisk(string userName);

        #endregion Methods
    }
}