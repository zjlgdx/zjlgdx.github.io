﻿namespace PS.SilverlightClientLib.Models.UserProfileModel
{
    using System;

    public class OfflineViewingParameters
    {
        #region Fields

        public readonly int MaxDaysBeforeExpire;
        public readonly int MaxModulesToCache;

        #endregion Fields

        #region Constructors

        internal OfflineViewingParameters(int maxDaysBeforeExpire, int maxModulesToCache)
        {
            this.MaxDaysBeforeExpire = maxDaysBeforeExpire;
            this.MaxModulesToCache = maxModulesToCache;
        }

        #endregion Constructors
    }
}