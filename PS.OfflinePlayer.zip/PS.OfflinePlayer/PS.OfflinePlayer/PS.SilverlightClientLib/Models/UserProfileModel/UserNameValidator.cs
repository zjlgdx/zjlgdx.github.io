﻿namespace PS.SilverlightClientLib.Models.UserProfileModel
{
    using System;
    using System.Text.RegularExpressions;

    public static class UserNameValidator
    {
        #region Fields

        private const string ValidUserNamePattern = "^[-A-Za-z0-9]{2,20}$";

        #endregion Fields

        #region Methods

        public static bool IsValidUserName(string userName)
        {
            return Regex.IsMatch(userName, "^[-A-Za-z0-9]{2,20}$");
        }

        #endregion Methods
    }
}