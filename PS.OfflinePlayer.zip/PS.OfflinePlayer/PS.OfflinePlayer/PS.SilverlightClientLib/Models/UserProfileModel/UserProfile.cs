﻿namespace PS.SilverlightClientLib.Models.UserProfileModel
{
    using System;

    using Infrastructure.UserProfileInfrastructure;

    public class UserProfile
    {
        #region Fields

        public readonly string FirstName;
        public readonly LoginToken LoginToken;
        public readonly OfflineViewingParameters OfflineViewingParameters;
        public readonly string SubscriptionLevel;
        public readonly string UserName;

        #endregion Fields

        #region Constructors

        internal UserProfile(string userName, string firstName, string subscriptionLevel, OfflineViewingParameters offlineViewingParameters)
        {
            this.UserName = userName;
            this.FirstName = firstName;
            this.SubscriptionLevel = subscriptionLevel;
            this.OfflineViewingParameters = offlineViewingParameters;
            this.LoginToken = new LoginToken("", new DateTime());
        }

        internal UserProfile(string userName, string firstName, string subscriptionLevel, OfflineViewingParameters offlineViewingParameters, LoginToken loginToken)
            : this(userName, firstName, subscriptionLevel, offlineViewingParameters)
        {
            this.LoginToken = loginToken;
        }

        #endregion Constructors

        #region Events

        public static event EventHandler Updated;

        #endregion Events

        #region Properties

        public static UserProfile Instance
        {
            get;
            internal set;
        }

        public static bool IsLoggedIn
        {
            get
            {
                return (Instance != null);
            }
        }

        public bool AllowOfflineViewing
        {
            get
            {
                return (this.OfflineViewingParameters != null);
            }
        }

        public string LoginTokenValue
        {
            get
            {
                return this.LoginToken.TokenValue;
            }
        }

        #endregion Properties

        #region Methods

        public static IUserProfileLoader MakeLoader()
        {
            return new UserProfileLoader();
        }

        public static void OnSignOut()
        {
            Instance = null;
        }

        internal static void SetUserProfile(UserProfile userProfile)
        {
            Instance = userProfile;
            if (Updated != null)
            {
                Updated(typeof(UserProfile), EventArgs.Empty);
            }
        }

        #endregion Methods
    }
}