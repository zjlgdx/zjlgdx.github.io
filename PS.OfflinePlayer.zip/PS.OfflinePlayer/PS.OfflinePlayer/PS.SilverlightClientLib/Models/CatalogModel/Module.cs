﻿namespace PS.SilverlightClientLib.Models.CatalogModel
{
    using System;
    using System.Collections.Generic;

    public class Module
    {
        #region Fields

        public readonly string AuthorDisplayName;
        public readonly IEnumerable<Clip> Clips;
        public readonly TimeSpan Duration;
        public readonly string Id;
        public readonly string Title;

        #endregion Fields

        #region Constructors

        public Module(string id, string authorDisplayName, string title, TimeSpan duration, IEnumerable<Clip> clips)
        {
            this.Id = id;
            this.AuthorDisplayName = authorDisplayName;
            this.Title = title;
            this.Duration = duration;
            this.Clips = clips;
        }

        #endregion Constructors
    }
}