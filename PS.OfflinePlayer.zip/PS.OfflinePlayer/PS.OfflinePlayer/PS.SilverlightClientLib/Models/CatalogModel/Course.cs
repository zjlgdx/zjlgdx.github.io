﻿namespace PS.SilverlightClientLib.Models.CatalogModel
{
    using System;
    using System.Collections.Generic;

    public class Course
    {
        #region Fields

        public readonly string CategoryId;
        public readonly string CategoryTitle;
        public readonly string Description;
        public readonly TimeSpan Duration;
        public readonly string Id;
        public readonly bool IsNew;
        public readonly string Level;
        public readonly IEnumerable<string> ModuleIds;
        public readonly string Title;

        #endregion Fields

        #region Constructors

        internal Course(string id, string title, string categoryId, string categoryTitle, string description, string level, TimeSpan duration, bool isNew, IEnumerable<string> moduleIds)
        {
            this.Id = id;
            this.Title = title;
            this.CategoryId = categoryId;
            this.CategoryTitle = categoryTitle;
            this.Description = description;
            this.Level = level;
            this.Duration = duration;
            this.IsNew = isNew;
            this.ModuleIds = moduleIds;
        }

        #endregion Constructors
    }
}