﻿namespace PS.SilverlightClientLib.Models.CatalogModel
{
    using System;
    using System.Collections.Generic;

    public interface ICatalog
    {
        #region Events

        event EventHandler Updated;

        #endregion Events

        #region Properties

        IEnumerable<string> CategoryIds
        {
            get;
        }

        #endregion Properties

        #region Methods

        Category FindCategory(string categoryId);

        Course FindCourse(string courseId);

        Module FindModule(string moduleId);

        IWebCatalogLoader MakeLoader();

        #endregion Methods
    }
}