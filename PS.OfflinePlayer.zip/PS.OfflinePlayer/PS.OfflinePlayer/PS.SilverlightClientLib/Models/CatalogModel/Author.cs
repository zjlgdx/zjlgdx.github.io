﻿namespace PS.SilverlightClientLib.Models.CatalogModel
{
    using System;

    public class Author
    {
        #region Fields

        public readonly string DisplayName;
        public readonly string Id;

        #endregion Fields

        #region Constructors

        public Author(string id, string displayName)
        {
            this.Id = id;
            this.DisplayName = displayName;
        }

        #endregion Constructors
    }
}