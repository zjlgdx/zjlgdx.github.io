﻿namespace PS.SilverlightClientLib.Models.CatalogModel
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Threading;

    using PS.SilverlightClientLib.Infrastructure;
    using PS.SilverlightClientLib.Infrastructure.CatalogInfrastructure;
    using PS.SilverlightClientLib.Infrastructure.Shared;
    using PS.SilverlightClientLib.Models.OfflineModuleModel;

    public class Catalog : ICatalog
    {
        #region Fields

        private CatalogParts parts = new CatalogParts();

        #endregion Fields

        #region Events

        public event EventHandler Updated;

        #endregion Events

        #region Properties

        public static ICatalog Instance
        {
            get;
            internal set;
        }

        public IEnumerable<string> CategoryIds
        {
            get
            {
                return this.parts.Categories.Keys;
            }
        }

        #endregion Properties

        #region Methods

        public Category FindCategory(string categoryId)
        {
            if (categoryId == null)
            {
                throw new ArgumentNullException("categoryId");
            }
            return this.parts.Categories.TryGetValue<string, Category>(categoryId);
        }

        public Course FindCourse(string courseId)
        {
            if (courseId == null)
            {
                throw new ArgumentNullException("courseId");
            }
            return this.parts.Courses.TryGetValue<string, Course>(courseId);
        }

        public Module FindModule(string moduleId)
        {
            if (moduleId == null)
            {
                throw new ArgumentNullException("moduleId");
            }
            return this.parts.Modules.TryGetValue<string, Module>(moduleId);
        }

        public IWebCatalogLoader MakeLoader()
        {
            return new WebCatalogLoader();
        }

        internal void SetCatalogParts(CatalogParts newParts)
        {
            PS.SilverlightClientLib.Infrastructure.ThreadHelper.ThrowIfNotModelThread();
            if (newParts == null)
            {
                throw new ArgumentNullException("newParts");
            }
            this.parts = newParts;
            if (this.Updated != null)
            {
                this.Updated(typeof(Catalog), EventArgs.Empty);
            }
            OfflineModuleManifest.Instance.PruneOfflineModulesBasedOnCurrentCatalog();
        }

        #endregion Methods
    }
}