﻿namespace PS.SilverlightClientLib.Models.CatalogModel
{
    using System;
    using System.Collections.Generic;

    public class Category
    {
        #region Fields

        public readonly IEnumerable<string> CourseIds;
        public readonly string Id;
        public readonly string Title;

        #endregion Fields

        #region Constructors

        internal Category(string id, string title, IEnumerable<string> courseIds)
        {
            this.Id = id;
            this.Title = title;
            this.CourseIds = courseIds;
        }

        #endregion Constructors
    }
}