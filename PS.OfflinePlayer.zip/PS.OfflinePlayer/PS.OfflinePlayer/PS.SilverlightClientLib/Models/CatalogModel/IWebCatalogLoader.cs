﻿namespace PS.SilverlightClientLib.Models.CatalogModel
{
    using System;

    using Infrastructure.Http;

    using Shared;

    public interface IWebCatalogLoader
    {
        #region Events

        event EventHandler<LoadCompletedEventArgs> LoadCompleted;

        event EventHandler<PsDownloadProgressChangedEventArgs> ProgressChanged;

        #endregion Events

        #region Methods

        void LoadCatalogAsync(object state = null);

        #endregion Methods
    }
}