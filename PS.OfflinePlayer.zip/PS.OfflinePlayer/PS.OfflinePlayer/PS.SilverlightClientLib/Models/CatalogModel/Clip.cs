﻿namespace PS.SilverlightClientLib.Models.CatalogModel
{
    using System;

    public class Clip
    {
        #region Fields

        public readonly bool AllowAnonymous;
        public readonly int ClipIndex;
        public readonly TimeSpan Duration;
        public readonly string Title;

        #endregion Fields

        #region Constructors

        public Clip(int clipIndex, string title, TimeSpan duration, bool allowAnonymous)
        {
            this.ClipIndex = clipIndex;
            this.Title = title;
            this.Duration = duration;
            this.AllowAnonymous = allowAnonymous;
        }

        #endregion Constructors
    }
}