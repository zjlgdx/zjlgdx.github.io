﻿namespace PS.SilverlightClientLib.Models.Shared
{
    using System;
    using System.Windows;

    public class ScreenSize
    {
        #region Fields

        public readonly bool IsFullScreen;
        public readonly System.Windows.Size Size;

        #endregion Fields

        #region Constructors

        internal ScreenSize(bool isFullScreen, System.Windows.Size size)
        {
            this.IsFullScreen = isFullScreen;
            this.Size = size;
        }

        #endregion Constructors

        #region Methods

        public static ScreenSize MakeFullScreenSize()
        {
            return new ScreenSize(true, new System.Windows.Size(0.0, 0.0));
        }

        public static ScreenSize MakeNormalScreenSize(System.Windows.Size size)
        {
            return new ScreenSize(false, size);
        }

        #endregion Methods
    }
}