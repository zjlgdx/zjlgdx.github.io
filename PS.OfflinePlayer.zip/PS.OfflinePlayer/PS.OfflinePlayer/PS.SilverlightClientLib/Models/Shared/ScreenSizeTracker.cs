﻿namespace PS.SilverlightClientLib.Models.Shared
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Windows;

    using PS.SilverlightClientLib.Infrastructure.Logging;
    using PS.SilverlightClientLib.Infrastructure.Shared;

    public class ScreenSizeTracker
    {
        #region Fields

        private const double ReasonableMaximumSize = 4000.0;
        private const double ReasonableMinimumSize = 50.0;

        private static readonly ILog log = LogManager.GetLogger(typeof(ScreenSizeTracker));

        #endregion Fields

        #region Constructors

        public ScreenSizeTracker(Dictionary<string, ScreenSize> preferredScreenSizes = null)
        {
            this.PreferredScreenSizes = preferredScreenSizes ?? new Dictionary<string, ScreenSize>();
        }

        #endregion Constructors

        #region Properties

        public Dictionary<string, ScreenSize> PreferredScreenSizes
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        public void UpdatePreferredScreenSize(string name, ScreenSize size)
        {
            if (name == null)
            {
                throw new ArgumentNullException("name");
            }
            if (this.IsReasonable(size))
            {
                this.PreferredScreenSizes[name] = size;
            }
        }

        private bool IsReasonable(ScreenSize screenSize)
        {
            if (screenSize.IsFullScreen)
            {
                return true;
            }
            Size size = screenSize.Size;
            if (this.IsReasonable(size.Width) && this.IsReasonable(size.Height))
            {
                return true;
            }
            log.Warn("ScreenSizeTracker received an unreasonable screen size ({0}). Ignoring it.".FormatWith(new object[] { size }), null, null);
            return false;
        }

        private bool IsReasonable(double value)
        {
            return ((50.0 <= value) && (value <= 4000.0));
        }

        #endregion Methods
    }
}