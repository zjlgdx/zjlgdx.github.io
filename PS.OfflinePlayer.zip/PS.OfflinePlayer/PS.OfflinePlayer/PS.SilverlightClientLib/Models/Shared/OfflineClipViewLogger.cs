﻿namespace PS.SilverlightClientLib.Models.Shared
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Net.NetworkInformation;
    using System.Threading;

    using PS.SilverlightClientLib.Infrastructure.Logging;
    using PS.SilverlightClientLib.Infrastructure.OfflineClipLogging;
    using PS.SilverlightClientLib.Infrastructure.Shared;
    using PS.SilverlightClientLib.Models.UserProfileModel;

    public class OfflineClipViewLogger : IOfflineClipViewLogger
    {
        #region Fields

        private static readonly ILog log = LogManager.GetLogger(typeof(OfflineClipViewLogger));
        private static readonly object syncRoot = new object();

        private readonly SyncContextHelper syncContextHelper = SyncContextHelper.MakeSyncContextHelper();

        private static IOfflineClipViewLogger theLogger;

        #endregion Fields

        #region Events

        public event EventHandler Updated;

        #endregion Events

        #region Properties

        public static IOfflineClipViewLogger Instance
        {
            get
            {
                return (theLogger ?? (theLogger = new OfflineClipViewLogger()));
            }
            internal set
            {
                theLogger = value;
            }
        }

        #endregion Properties

        #region Methods

        public void Initialize()
        {
            NetworkChange.NetworkAddressChanged += new NetworkAddressChangedEventHandler(this.NetworkChange_NetworkAddressChanged);
            UserProfile.Updated += new EventHandler(this.UserProfile_Updated);
        }

        public void LogClipView(string courseId, string moduleId, int clipIndex)
        {
            OfflineClipLogActivityRecordDto viewRecord = AssembleViewRecord(courseId, moduleId, clipIndex);
            this.PersistAndMaybeTransmit(viewRecord);
            this.syncContextHelper.Post(new Action(this.FireUpdatedEvent));
        }

        public int PendingClipViewsToTransfer()
        {
            return this.LoadAllRecordsFromFile().Count<OfflineClipLogActivityRecordDto>();
        }

        public void TryToTransmitClipViews()
        {
            if (Network.IsAvailable)
            {
                IEnumerable<OfflineClipLogActivityRecordDto> source = this.CollectUntransmittedRecords();
                if (!source.IsEmpty<OfflineClipLogActivityRecordDto>())
                {
                    MemoryStream clipEntityJson = OfflineActivityRequestDtoBuilder.BuildOfflineActivityRequestDtoMemoryStream(source);
                    if (clipEntityJson != null)
                    {
                        OfflineClipActivityUploader uploader = new OfflineClipActivityUploader(clipEntityJson, source);
                        uploader.RequestCompleted += new EventHandler<AsyncCompletedEventArgs>(this.logger_RequestCompleted);
                        uploader.PostClipActivitiesAsync();
                    }
                }
            }
        }

        private static OfflineClipLogActivityRecordDto AssembleViewRecord(string courseId, string moduleId, int clipIndex)
        {
            DateTime utcNow = DateTime.UtcNow;
            return new OfflineClipLogActivityRecordDto { ActivityId = Guid.NewGuid(), CourseId = courseId, ModuleId = moduleId, ClipIndex = clipIndex, ViewStartUtc = utcNow };
        }

        private void AppendLogLinesUnderLock(IEnumerable<string> lines)
        {
            File.AppendAllLines(Paths.ClipViewLogFile, lines);
        }

        private void AppendLogLineUnderLock(string line)
        {
            this.AppendLogLinesUnderLock(new string[] { line });
        }

        private IEnumerable<OfflineClipLogActivityRecordDto> CollectUntransmittedRecords()
        {
            return this.TryLoadAllRecordsFromFile();
        }

        private IEnumerable<OfflineClipLogActivityRecordDto> DifferenceRecordsUnderLock(IEnumerable<OfflineClipLogActivityRecordDto> transmittedRecords)
        {
            return this.TryLoadAllRecordsFromFile().ToHashSet<OfflineClipLogActivityRecordDto>().Except<OfflineClipLogActivityRecordDto>(transmittedRecords.ToHashSet<OfflineClipLogActivityRecordDto>()).ToArray<OfflineClipLogActivityRecordDto>();
        }

        private void DiffRecordsAndRewriteFileWithUntransmittedOnes(OfflineClipLogActivityRecordDto[] transmittedRecords)
        {
            lock (syncRoot)
            {
                IEnumerable<OfflineClipLogActivityRecordDto> source = this.DifferenceRecordsUnderLock(transmittedRecords);
                File.Delete(Paths.ClipViewLogFile);
                if (!source.IsEmpty<OfflineClipLogActivityRecordDto>())
                {
                    IEnumerable<string> lines = Enumerable.Select<OfflineClipLogActivityRecordDto, string>(source, new Func<OfflineClipLogActivityRecordDto, string>(OfflineClipLogActivityRecordDtoSerializer.SerializeOfflineClipLogActivityRecordDto));
                    this.AppendLogLinesUnderLock(lines);
                }
            }
        }

        private void FireUpdatedEvent()
        {
            this.Updated.TryFireEvent(this);
        }

        private IEnumerable<OfflineClipLogActivityRecordDto> LoadAllRecordsFromFile()
        {
            try
            {
                if (!File.Exists(Paths.ClipViewLogFile))
                {
                    return Enumerable.Empty<OfflineClipLogActivityRecordDto>();
                }
                return Enumerable.Select<string, OfflineClipLogActivityRecordDto>(from line in File.ReadLines(Paths.ClipViewLogFile)
                    where line.NotJustWhitespace()
                    select line, new Func<string, OfflineClipLogActivityRecordDto>(OfflineClipLogActivityRecordDtoSerializer.DeserializeOfflineClipLogActivityRecordDto)).SkipNulls<OfflineClipLogActivityRecordDto>().ToArray<OfflineClipLogActivityRecordDto>();
            }
            catch (FileNotFoundException)
            {
                return Enumerable.Empty<OfflineClipLogActivityRecordDto>();
            }
        }

        private void logger_RequestCompleted(object sender, AsyncCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                log.Error("Unable to transmit offline clip view records: " + e.Error, null, null);
            }
            else
            {
                OfflineClipLogActivityRecordDto[] userState = (OfflineClipLogActivityRecordDto[]) e.UserState;
                this.DiffRecordsAndRewriteFileWithUntransmittedOnes(userState);
                this.syncContextHelper.Post(new Action(this.FireUpdatedEvent));
            }
        }

        private void NetworkChange_NetworkAddressChanged(object sender, EventArgs e)
        {
            if (Network.IsAvailable)
            {
                this.syncContextHelper.Post(new Action(this.TryToTransmitClipViews));
            }
        }

        private void PersistAndMaybeTransmit(OfflineClipLogActivityRecordDto viewRecord)
        {
            this.PersistRecord(viewRecord);
            this.TryToTransmitClipViews();
        }

        private void PersistRecord(OfflineClipLogActivityRecordDto viewRecord)
        {
            string line = OfflineClipLogActivityRecordDtoSerializer.SerializeOfflineClipLogActivityRecordDto(viewRecord);
            lock (syncRoot)
            {
                this.AppendLogLineUnderLock(line);
            }
        }

        private IEnumerable<OfflineClipLogActivityRecordDto> TryLoadAllRecordsFromFile()
        {
            if (!File.Exists(Paths.ClipViewLogFile))
            {
                return Enumerable.Empty<OfflineClipLogActivityRecordDto>();
            }
            return this.LoadAllRecordsFromFile();
        }

        private void UserProfile_Updated(object sender, EventArgs e)
        {
            if (UserProfile.IsLoggedIn)
            {
                this.syncContextHelper.Post(new Action(this.TryToTransmitClipViews));
            }
        }

        #endregion Methods
    }
}