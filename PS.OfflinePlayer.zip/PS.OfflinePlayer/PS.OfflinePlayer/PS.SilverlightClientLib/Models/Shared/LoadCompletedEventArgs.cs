﻿namespace PS.SilverlightClientLib.Models.Shared
{
    using System;
    using System.Runtime.CompilerServices;

    public class LoadCompletedEventArgs : EventArgs
    {
        #region Properties

        public bool Cancelled
        {
            get; internal set;
        }

        public Exception Error
        {
            get; internal set;
        }

        public object State
        {
            get; internal set;
        }

        #endregion Properties
    }
}