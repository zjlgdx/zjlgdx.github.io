﻿namespace PS.SilverlightClientLib.Models.Shared
{
    using System;

    public interface IOfflineClipViewLogger
    {
        #region Events

        event EventHandler Updated;

        #endregion Events

        #region Methods

        void Initialize();

        void LogClipView(string courseId, string moduleId, int clipIndex);

        int PendingClipViewsToTransfer();

        void TryToTransmitClipViews();

        #endregion Methods
    }
}