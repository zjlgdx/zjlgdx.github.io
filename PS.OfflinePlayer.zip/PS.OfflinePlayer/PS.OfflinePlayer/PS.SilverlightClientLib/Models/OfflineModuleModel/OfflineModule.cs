﻿namespace PS.SilverlightClientLib.Models.OfflineModuleModel
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Threading;

    using PS.SilverlightClientLib.Infrastructure.Logging;
    using PS.SilverlightClientLib.Infrastructure.Notifications;
    using PS.SilverlightClientLib.Infrastructure.Shared;

    public class OfflineModule : ModelWithNotificationBase<OfflineModule>
    {
        #region Fields

        public readonly string CourseId;
        public readonly DateTime ExpirationDateUtc;
        public readonly string ModuleId;
        public readonly IEnumerable<OfflineClip> OfflineClips;

        private static readonly ILog log = LogManager.GetLogger(typeof(OfflineModule));

        #endregion Fields

        #region Constructors

        public OfflineModule(string courseId, string moduleId, DateTime expirationDateUtc, IEnumerable<OfflineClip> offlineClips)
        {
            this.CourseId = courseId;
            this.ModuleId = moduleId;
            this.ExpirationDateUtc = expirationDateUtc;
            this.OfflineClips = offlineClips;
            this.WireupClipEventListeners();
        }

        #endregion Constructors

        #region Events

        public event EventHandler Updated;

        #endregion Events

        #region Properties

        public int FetchProgress
        {
            get
            {
                if (this.TotalClipSizeInBytes <= 0L)
                {
                    return 0;
                }
                return (int) ((this.TotalFetchedClipSizeInBytes * 100L) / this.TotalClipSizeInBytes);
            }
        }

        public PS.SilverlightClientLib.Models.OfflineModuleModel.FetchState FetchState
        {
            get
            {
                switch (this.FetchProgress)
                {
                    case 0:
                        return PS.SilverlightClientLib.Models.OfflineModuleModel.FetchState.Requested;

                    case 100:
                        return PS.SilverlightClientLib.Models.OfflineModuleModel.FetchState.FetchComplete;
                }
                return PS.SilverlightClientLib.Models.OfflineModuleModel.FetchState.FetchInProgress;
            }
        }

        public bool IsExpired
        {
            get
            {
                return false;
                return (DateTime.UtcNow > this.ExpirationDateUtc);
            }
        }

        public long TotalClipSizeInBytes
        {
            get
            {
                return Enumerable.Sum<OfflineClip>(this.OfflineClips, (Func<OfflineClip, long>) (x => x.FileSizeInBytes.ValueOrDefault<long>()));
            }
        }

        public long TotalFetchedClipSizeInBytes
        {
            get
            {
                return Enumerable.Sum<OfflineClip>(this.OfflineClips, (Func<OfflineClip, long>) (x => x.BytesFetched));
            }
        }

        internal OfflineClip FirstClipToFetch
        {
            get
            {
                return Enumerable.FirstOrDefault<OfflineClip>(this.OfflineClips, (Func<OfflineClip, bool>) (oc => !oc.IsFetchCompleted));
            }
        }

        #endregion Properties

        #region Methods

        internal void SetClipSizes(long[] clipSizesInBytes)
        {
            if (this.OfflineClips.Count<OfflineClip>() != clipSizesInBytes.Count<long>())
            {
                log.Error("SetClipSizes called with clipSizesInBytes[{0}] when there were {1} clips. Unable to update clip sizes.".FormatWith(new object[] { clipSizesInBytes.Count<long>(), this.OfflineClips.Count<OfflineClip>() }), null, null);
            }
            else
            {
                this.UpdateClipSizes(clipSizesInBytes);
                this.Updated.TryFireEventFromModelThread(this);
            }
        }

        private void clip_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.NotifyEntireModelChanged();
        }

        private void UpdateClipSizes(IEnumerable<long> clipSizesInBytes)
        {
            IEnumerator<OfflineClip> enumerator = this.OfflineClips.GetEnumerator();
            IEnumerator<long> enumerator2 = clipSizesInBytes.GetEnumerator();
            while (enumerator.MoveNext() && enumerator2.MoveNext())
            {
                enumerator.Current.FileSizeInBytes = new long?(enumerator2.Current);
            }
            base.NotifyEntireModelChanged();
        }

        private void WireupClipEventListeners()
        {
            foreach (OfflineClip clip in this.OfflineClips)
            {
                clip.PropertyChanged += new PropertyChangedEventHandler(this.clip_PropertyChanged);
            }
        }

        #endregion Methods
    }
}