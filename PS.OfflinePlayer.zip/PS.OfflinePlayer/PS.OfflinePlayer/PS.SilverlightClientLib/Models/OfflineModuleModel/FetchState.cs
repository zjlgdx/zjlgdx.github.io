﻿namespace PS.SilverlightClientLib.Models.OfflineModuleModel
{
    using System;

    #region Enumerations

    public enum FetchState
    {
        Requested,
        FetchInProgress,
        FetchComplete
    }

    #endregion Enumerations
}