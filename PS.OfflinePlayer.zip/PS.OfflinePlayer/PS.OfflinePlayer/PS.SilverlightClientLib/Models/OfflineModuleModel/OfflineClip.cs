﻿namespace PS.SilverlightClientLib.Models.OfflineModuleModel
{
    using System;
    using System.Linq.Expressions;

    using Infrastructure.Notifications;
    using Infrastructure.Shared;

    public class OfflineClip : ModelWithNotificationBase<OfflineClip>
    {
        #region Fields

        public readonly int ClipIndex;

        private long bytesFetched;
        private long? fileSizeInBytes;
        private string localFileName;

        #endregion Fields

        #region Constructors

        public OfflineClip(int clipIndex)
        {
            this.ClipIndex = clipIndex;
            this.LocalFileName = "";
        }

        #endregion Constructors

        #region Properties

        public long BytesFetched
        {
            get
            {
                if (this.IsFetchCompleted)
                {
                    return this.FileSizeInBytes.Value;
                }
                return this.bytesFetched;
            }
            internal set
            {
                if (this.bytesFetched != value)
                {
                    this.bytesFetched = value;
                    base.NotifyPropertyChanged(x => x.BytesFetched);
                }
            }
        }

        public long? FileSizeInBytes
        {
            get
            {
                return this.fileSizeInBytes;
            }
            internal set
            {
                if (this.fileSizeInBytes != value)
                {
                    this.fileSizeInBytes = value;
                    base.NotifyPropertyChanged(x => x.FileSizeInBytes);
                }
            }
        }

        public bool IsFetchCompleted
        {
            get
            {
                return this.LocalFileName.HasContent();
            }
        }

        public string LocalFileName
        {
            get
            {
                return this.localFileName;
            }
            set
            {
                this.localFileName = value;
                base.NotifyPropertyChanged(new Expression<Func<OfflineClip, object>>[] { x => x.LocalFileName, x => x.IsFetchCompleted });
            }
        }

        #endregion Properties

        #region Methods

        public void Orphan()
        {
            this.LocalFileName = "";
        }

        #endregion Methods
    }
}