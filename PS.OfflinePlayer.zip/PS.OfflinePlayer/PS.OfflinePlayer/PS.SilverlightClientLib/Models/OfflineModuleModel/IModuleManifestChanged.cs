﻿namespace PS.SilverlightClientLib.Models.OfflineModuleModel
{
    using System;

    public interface IModuleManifestChanged
    {
        #region Methods

        void ModuleAdded(string moduleId);

        void ModuleRemoved();

        #endregion Methods
    }
}