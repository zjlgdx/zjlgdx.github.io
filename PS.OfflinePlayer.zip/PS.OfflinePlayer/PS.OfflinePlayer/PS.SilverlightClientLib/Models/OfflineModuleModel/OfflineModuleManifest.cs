﻿namespace PS.SilverlightClientLib.Models.OfflineModuleModel
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Threading;

    using PS.SilverlightClientLib.Infrastructure.Notifications;
    using PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure;
    using PS.SilverlightClientLib.Infrastructure.Shared;
    using PS.SilverlightClientLib.Models.CatalogModel;
    using PS.SilverlightClientLib.Models.UserProfileModel;

    public class OfflineModuleManifest : ModelWithNotificationBase<OfflineModuleManifest>, IModuleManifestChanged
    {
        #region Fields

        private static OfflineModuleManifest theOfflineManifest;

        private IModuleManifestChanged moduleChangedHandler;
        private ObservableCollection<OfflineModule> offlineModules = new ObservableCollection<OfflineModule>();

        #endregion Fields

        #region Constructors

        private OfflineModuleManifest()
        {
        }

        #endregion Constructors

        #region Events

        public event EventHandler Updated;

        #endregion Events

        #region Properties

        public static OfflineModuleManifest Instance
        {
            get
            {
                return (theOfflineManifest ?? (theOfflineManifest = new OfflineModuleManifest()));
            }
        }

        public int NumSlotsLeft
        {
            get
            {
                return (this.GetMaxModulesToCache() - this.OfflineModules.Count<OfflineModule>());
            }
        }

        public ObservableCollection<OfflineModule> OfflineModules
        {
            get
            {
                return this.offlineModules;
            }
        }

        private IModuleManifestChanged ChangedHandler
        {
            get
            {
                return (this.moduleChangedHandler ?? this);
            }
        }

        #endregion Properties

        #region Methods

        public void AddModule(string courseId, string moduleId)
        {
            int maxModulesToCache = this.GetMaxModulesToCache();
            if ((this.offlineModules.Count<OfflineModule>() < maxModulesToCache) && !this.AlreadyQueued(courseId, moduleId))
            {
                OfflineModule item = AssembleOfflineModule(courseId, moduleId);
                this.offlineModules.Add(item);
                this.ChangedHandler.ModuleAdded(moduleId);
                base.NotifyEntireModelChanged();
                this.Updated.TryFireEventFromModelThread(this);
            }
        }

        public OfflineModule FindModule(string moduleId)
        {
            return Enumerable.FirstOrDefault<OfflineModule>(this.offlineModules, (Func<OfflineModule, bool>) (x => (x.ModuleId == moduleId)));
        }

        public int GetMaxModulesToCache()
        {
            return 1000;
            if (UserProfile.IsLoggedIn)
            {
                OfflineViewingParameters offlineViewingParameters = UserProfile.Instance.OfflineViewingParameters;
                if (offlineViewingParameters != null)
                {
                    return offlineViewingParameters.MaxModulesToCache;
                }
            }
            return 0;
        }

        public void ModuleAdded(string moduleId)
        {
            bool isCritical = false;
            new ModuleSizeLoader(moduleId, isCritical).LoadModuleSizeAsync();
            this.UpdatePersistedState();
        }

        public void ModuleRemoved()
        {
            this.UpdatePersistedState();
        }

        public void OnSignOut()
        {
            this.OfflineModules.Clear();
            this.UpdatePersistedState();
            base.NotifyEntireModelChanged();
        }

        public void PruneOfflineModulesBasedOnCurrentCatalog()
        {
            int num = 0;
            List<OfflineModule> list = new List<OfflineModule>(this.OfflineModules);
            foreach (OfflineModule module in list)
            {
                if (Catalog.Instance.FindCourse(module.CourseId) == null)
                {
                    this.RemoveModuleFromList(module.ModuleId);
                    num++;
                }
            }
            if (num > 0)
            {
                base.NotifyEntireModelChanged();
                this.UpdatePersistedState();
            }
        }

        public void RemoveModule(string moduleId)
        {
            if (moduleId == null)
            {
                throw new ArgumentNullException("moduleId");
            }
            if (this.FindModule(moduleId) != null)
            {
                this.RemoveModuleFromList(moduleId);
                this.ChangedHandler.ModuleRemoved();
                base.NotifyEntireModelChanged();
                this.Updated.TryFireEventFromModelThread(this);
            }
        }

        internal void Initialize(IEnumerable<OfflineModule> modules)
        {
            this.offlineModules = new ObservableCollection<OfflineModule>(modules.ToArray<OfflineModule>());
        }

        internal void SetModuleManifestChangedHandler(IModuleManifestChanged moduleChanged)
        {
            this.moduleChangedHandler = moduleChanged;
        }

        private static IEnumerable<OfflineClip> AssembleOfflineClips(string moduleId)
        {
            Module module = Catalog.Instance.FindModule(moduleId);
            if (module == null)
            {
                throw new InvalidOperationException("Couldn't find module: " + moduleId);
            }
            return Enumerable.Select<Clip, OfflineClip>(module.Clips, (Func<Clip, int, OfflineClip>) ((clip, clipIndex) => new OfflineClip(clipIndex))).ToArray<OfflineClip>();
        }

        private static OfflineModule AssembleOfflineModule(string courseId, string moduleId)
        {
            string str = courseId;
            string str2 = moduleId;
            DateTime expirationDateUtc = DateTime.UtcNow + GetTimeToLive();
            return new OfflineModule(str, str2, expirationDateUtc, AssembleOfflineClips(moduleId));
        }

        private static TimeSpan GetTimeToLive()
        {
            return TimeSpan.FromDays((double) UserProfile.Instance.OfflineViewingParameters.MaxDaysBeforeExpire).Add(TimeSpan.FromDays(1.0));
        }

        private bool AlreadyQueued(string courseId, string moduleId)
        {
            return Enumerable.Any<OfflineModule>(this.OfflineModules, (Func<OfflineModule, bool>) (x => ((x.CourseId == courseId) && (x.ModuleId == moduleId))));
        }

        private void RemoveModuleFromList(string moduleId)
        {
            OfflineModule item = Enumerable.FirstOrDefault<OfflineModule>(this.offlineModules, (Func<OfflineModule, bool>) (x => (x.ModuleId == moduleId)));
            if (item != null)
            {
                this.offlineModules.Remove(item);
            }
        }

        private void UpdatePersistedState()
        {
            OfflineModuleManifestLoader.SaveOfflineModuleManifestToDisk();
            OfflineClipScavenger.DeleteOrphanedClips();
        }

        #endregion Methods
    }
}