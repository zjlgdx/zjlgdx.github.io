﻿namespace PS.OfflinePlayer
{
    using System;
    using System.Diagnostics;
    using System.Windows;

    using ViewModels;
    using SilverlightClientLib.Infrastructure.App;
    using SilverlightClientLib.Infrastructure.Logging;
    using SilverlightClientLib.Infrastructure.Shared;

    public partial class App : Application
    {
        #region Fields

        private static readonly ILog log = LogManager.GetLogger(typeof(App));

        private readonly ApplicationInitializer initializer = new ApplicationInitializer();

        #endregion Fields

        #region Constructors

        public App()
        {
            this.Startup += this.Application_Startup;
            this.Exit += this.Application_Exit;
            this.UnhandledException += this.Application_UnhandledException;

            InitializeComponent();
        }

        #endregion Constructors

        #region Methods

        private static void InitializeInstall()
        {
            Navigator.Instance.InitializeInstall();
        }

        private void Application_Exit(object sender, EventArgs e)
        {
            if (AppState.Instance != null)
            {
                this.SaveMainWindowOrigin();
                this.initializer.Shutdown();
            }
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            //this.RootVisual = new MainPage();

            if (base.IsRunningOutOfBrowser)
            {
                this.InitializeOOB();
            }
            else
            {
                InitializeInstall();
            }
        }

        private void Application_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
        {
            /*
            // If the app is running outside of the debugger then report the exception using
            // the browser's exception mechanism. On IE this will display it a yellow alert
            // icon in the status bar and Firefox will display a script error.
            if (!System.Diagnostics.Debugger.IsAttached)
            {

                // NOTE: This will allow the application to continue running after an exception has been thrown
                // but not handled.
                // For production applications this error handling should be replaced with something that will
                // report the error to the website and stop the application.
                e.Handled = true;
                Deployment.Current.Dispatcher.BeginInvoke(delegate { ReportErrorToDOM(e); });
            }
             * */

            if (!Debugger.IsAttached)
            {
                log.Fatal(e.ExceptionObject, null);
            }
        }

        private void DownloadUpdates()
        {
            Application.Current.CheckAndDownloadUpdateCompleted += delegate(object sender, CheckAndDownloadUpdateCompletedEventArgs e)
            {
                if (e.UpdateAvailable)
                {
                    MessageBox.Show("An update to this application has been downloaded from Pluralsight. Please restart the application to load the new version. Thanks!");
                }
            };
            Application.Current.CheckAndDownloadUpdateAsync();
        }

        private bool EnsureMyVideosFolderExists()
        {
            if (!Paths.EnsureMyVideoDirectoryExists())
            {
                MessageBox.Show(string.Format("This application uses 'My Videos' for caching offline content.  If that folder does not exist, the application cannot continue. Please see {0} for assistance", "http://support.pluralsight.com/knowledgebase/topics/3887-mobile-players-and-offline-viewing"));
                return false;
            }
            return true;
        }

        private void InitializeOOB()
        {
            if (!this.EnsureMyVideosFolderExists())
            {
                base.MainWindow.Close();
            }
            else
            {
                this.DownloadUpdates();
                this.initializer.Initialize();
                this.RestoreMainWindowOrigin();
                Navigator.Instance.InitializeOOB();
            }
        }

        private void ReportErrorToDOM(ApplicationUnhandledExceptionEventArgs e)
        {
            try
            {
                string errorMsg = e.ExceptionObject.Message + e.ExceptionObject.StackTrace;
                errorMsg = errorMsg.Replace('"', '\'').Replace("\r\n", @"\n");

                System.Windows.Browser.HtmlPage.Window.Eval("throw new Error(\"Unhandled Error in Silverlight Application " + errorMsg + "\");");
            }
            catch (Exception)
            {
            }
        }

        private void RestoreMainWindowOrigin()
        {
            Point mainWindowOrigin = AppState.Instance.MainWindowOrigin;
            base.MainWindow.Left = mainWindowOrigin.X;
            base.MainWindow.Top = mainWindowOrigin.Y;
        }

        private void SaveMainWindowOrigin()
        {
            double left = base.MainWindow.Left;
            double top = base.MainWindow.Top;
            AppState.Instance.MainWindowOrigin = new Point(left, top);
        }

        #endregion Methods
    }
}