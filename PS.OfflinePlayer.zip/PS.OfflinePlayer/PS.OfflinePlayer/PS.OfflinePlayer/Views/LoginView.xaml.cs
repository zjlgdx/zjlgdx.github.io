﻿namespace PS.OfflinePlayer.Views
{
    using System;
    using System.Net;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;

    using SilverlightClientLib.Infrastructure.Logging;
    using SilverlightClientLib.Infrastructure.Shared;
    using SilverlightClientLib.Models.Shared;
    using SilverlightClientLib.Models.UserProfileModel;

    using ViewModels;

    public partial class LoginView : UserControl
    {
        #region Fields

        private static readonly ILog log = LogManager.GetLogger(typeof(LoginView));

        private Creds storedCreds;

        #endregion Fields

        #region Constructors

        public LoginView()
        {
            this.InitializeComponent();
        }

        #endregion Constructors

        #region Properties

        private bool HasCredsAndProfile
        {
            get
            {
                return ((null != this.storedCreds) && (null != UserProfile.Instance));
            }
        }

        private bool MayAttemptAutoLogin
        {
            get
            {
                return ((null != this.storedCreds) && Network.IsAvailable);
            }
        }

        private bool ProfileAuthorized
        {
            get
            {
                return ((UserProfile.Instance != null) && UserProfile.Instance.AllowOfflineViewing);
            }
        }

        #endregion Properties

        #region Methods

        public void Initialize()
        {
            this.lnkYourAccount.NavigateUri = new Uri(Uris.YourAccountUri);
            this.storedCreds = CredentialHelper.ReadCredentials();
            if (this.MayAttemptAutoLogin)
            {
                this.CopyCredsIntoControls();
                this.LoginAsync();
            }
            else if (this.HasCredsAndProfile)
            {
                if (this.ProfileAuthorized)
                {
                    Navigator.Instance.ShowHomeView();
                }
                else
                {
                    this.PromptUnauthorizedUser();
                }
            }
            else
            {
                this.PromptForCredentials("");
            }
        }

        private void AutoSubmitIfEnterWasPressed(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                this.ValidateInputThenAttemptLogin();
            }
        }

        private void CopyCredsIntoControls()
        {
            this.txtUserName.Text = this.storedCreds.Username;
            this.password.Password = this.storedCreds.Password;
        }

        private void HandleLoginError(LoadCompletedEventArgs e)
        {
            LoginResultErrorInterpretation interpretation = this.InterpretLoginResultError(e);
            if (interpretation.WasForbidden)
            {
                this.PromptForCredentials(interpretation.FriendlyErrorMessage);
            }
            else
            {
                this.LogUnexpectedError(e.Error);
                this.OnSuccessfulLogin();
            }
        }

        private LoginResultErrorInterpretation InterpretLoginResultError(LoadCompletedEventArgs e)
        {
            WebException error = e.Error as WebException;
            if (error != null)
            {
                if (error.HttpStatusCode() == HttpStatusCode.Forbidden)
                {
                    bool flag = true;
                    return new LoginResultErrorInterpretation(flag, "Invalid user name or password");
                }
                bool flag2 = false;
                return new LoginResultErrorInterpretation(flag2, "Login failed. Status: {0}".FormatWith(new object[] { error.HttpStatusCode() }));
            }
            bool wasForbidden = false;
            return new LoginResultErrorInterpretation(wasForbidden, "Login failed. Please check your network connection.");
        }

        private void lnkShowMe_Click(object sender, RoutedEventArgs e)
        {
            this.imgFindingYourUserName.Visibility = Visibility.Visible;
        }

        private void LoginAsync()
        {
            IUserProfileLoader loader = UserProfile.MakeLoader();
            loader.LoadCompleted += new EventHandler<LoadCompletedEventArgs>(this.userProfileLoader_LoadCompleted);
            loader.LoadUserProfileAsync(this.txtUserName.Text, this.password.Password, null);
            this.PleaseWait();
        }

        private void LogUnexpectedError(Exception x)
        {
            log.Error("Unexpected error from login request", x, null);
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.ValidateInputThenAttemptLogin();
        }

        private void OnSuccessfulLogin()
        {
            this.PersistCredentials();
            Navigator.Instance.ShowHomeView();
        }

        private void PersistCredentials()
        {
            string text = this.txtUserName.Text;
            string password = this.password.Password;
            CredentialHelper.PersistCredentials(text, password);
        }

        private void PleaseWait()
        {
            this.pleaseWaitView.Visibility = Visibility.Visible;
            this.dataEntryView.Visibility = Visibility.Collapsed;
        }

        private void PromptForCredentials(string errorMessage = "")
        {
            if (errorMessage.HasContent())
            {
                MessageBox.Show(errorMessage, "Oops!", MessageBoxButton.OK);
            }
            this.dataEntryView.Visibility = Visibility.Visible;
            this.pleaseWaitView.Visibility = Visibility.Collapsed;
        }

        private void PromptUnauthorizedUser()
        {
            this.PromptForCredentials("You must have a current non-trial Plus subscription to use this application.");
        }

        private void userProfileLoader_LoadCompleted(object sender, LoadCompletedEventArgs e)
        {
            if (e.Error == null)
            {
                if (this.ProfileAuthorized)
                {
                    this.OnSuccessfulLogin();
                }
                else
                {
                    this.PromptUnauthorizedUser();
                }
            }
            else
            {
                this.HandleLoginError(e);
            }
        }

        private void ValidateInputThenAttemptLogin()
        {
            if (UserNameValidator.IsValidUserName(this.txtUserName.Text))
            {
                this.LoginAsync();
            }
            else
            {
                MessageBox.Show("Invalid user name", "Oops!", MessageBoxButton.OK);
            }
        }

        #endregion Methods

        #region Nested Types

        private class LoginResultErrorInterpretation
        {
            #region Fields

            public readonly string FriendlyErrorMessage;
            public readonly bool WasForbidden;

            #endregion Fields

            #region Constructors

            public LoginResultErrorInterpretation(bool wasForbidden, string friendlyErrorMessage)
            {
                this.WasForbidden = wasForbidden;
                this.FriendlyErrorMessage = friendlyErrorMessage;
            }

            #endregion Constructors
        }

        #endregion Nested Types
    }
}