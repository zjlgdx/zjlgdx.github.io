﻿namespace PS.OfflinePlayer.Views
{
    using System;
    using System.Windows;
    using System.Windows.Controls;

    public partial class ErrorView : ChildWindow
    {
        #region Constructors

        public ErrorView(Exception e)
        {
            this.InitializeComponent();
            if (e != null)
            {
                this.ErrorTextBox.Text = e.Message + Environment.NewLine + Environment.NewLine + e.StackTrace;
            }
        }

        public ErrorView(Uri uri)
        {
            this.InitializeComponent();
            if (uri != null)
            {
                this.ErrorTextBox.Text = "Page not found: \"" + uri + "\"";
            }
        }

        public ErrorView(string message, string details)
        {
            this.InitializeComponent();
            this.ErrorTextBox.Text = message + Environment.NewLine + Environment.NewLine + details;
        }

        #endregion Constructors

        #region Methods

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            base.DialogResult = true;
        }

        #endregion Methods
    }
}