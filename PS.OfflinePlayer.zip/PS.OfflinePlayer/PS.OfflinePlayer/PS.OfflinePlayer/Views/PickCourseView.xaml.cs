﻿namespace PS.OfflinePlayer.Views
{
    using System.Windows;
    using System.Windows.Controls;

    using ViewModels;

    public partial class PickCourseView : UserControl
    {
        #region Constructors

        public PickCourseView()
        {
            this.InitializeComponent();
            this.BuildDataContext();
        }

        #endregion Constructors

        #region Methods

        private void BuildDataContext()
        {
            base.DataContext = new PickCourseVmBuilder().BuildPickCourseVm();
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            Navigator.Instance.ShowHomeView();
        }

        #endregion Methods
    }
}