﻿namespace PS.OfflinePlayer.Views
{
    using System.Windows.Controls;

    public partial class spinner : UserControl
    {
        #region Constructors

        public spinner()
        {
            this.InitializeComponent();
        }

        #endregion Constructors
    }
}