﻿namespace PS.OfflinePlayer.Views
{
    using System;
    using System.IO;
    using System.Threading;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using System.Windows.Interop;
    using System.Windows.Media;
    using System.Windows.Threading;

    using SilverlightClientLib.Infrastructure.Cryptography;
    using SilverlightClientLib.Models.Shared;

    using ViewModels;
    using ViewModels.Player;

    public partial class PlayerView : UserControl
    {
        #region Fields

        private readonly DispatcherTimer playTimer = new DispatcherTimer();
        private readonly ModuleVm vm;

        private int currentClipIndex = -1;
        private Stream currentVideoStream;
        private TimeSpan duration;
        private bool isAutoPlayEnabled = true;
        private double lastVolume;
        private bool timeRemaining;

        #endregion Fields

        #region Constructors

        public PlayerView(ModuleVm vm)
        {
            this.vm = vm;
            this.InitializeComponent();
            base.Loaded += new RoutedEventHandler(this.Page_Loaded);
            Application.Current.Host.Content.FullScreenChanged += new EventHandler(this.Content_FullScreenChanged);
            this.mediaPlayer.MediaOpened += new RoutedEventHandler(this.mediaPlayer_MediaOpened);
            this.playButton.Checked += new RoutedEventHandler(this.playButton_Checked);
            this.playButton.Unchecked += new RoutedEventHandler(this.playButton_Unchecked);
            this.muteButton.Checked += new RoutedEventHandler(this.muteButton_Checked);
            this.muteButton.Unchecked += new RoutedEventHandler(this.muteButton_Unchecked);
            this.currentTimeTextBlock.MouseLeftButtonUp += new MouseButtonEventHandler(this.currentTimeTextBlock_MouseLeftButtonUp);
            this.nextButton.Click += new RoutedEventHandler(this.nextButton_Click);
            this.prevButton.Click += new RoutedEventHandler(this.prevButton_Click);
            this.tivoPreviousButton.Click += new RoutedEventHandler(this.tivoPreviousButton_Click);
            this.clipListBox.SelectionChanged += new SelectionChangedEventHandler(this.clipListBox_SelectionChanged);
            this.timelineSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(this.timelineSlider_ValueChanged);
            this.timelineSlider.LargeChange = 0.1;
            this.timelineSlider.SmallChange = 0.05;
            this.volumeSlider.LargeChange = 0.125;
            this.volumeSlider.SmallChange = 0.125;
            this.volumeSlider.Value = 1.0;
            this.volumeSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(this.volumeSlider_ValueChanged);
            this.mediaPlayer.CurrentStateChanged += new RoutedEventHandler(this.mediaPlayer_CurrentStateChanged);
            this.mediaPlayer.DownloadProgressChanged += new RoutedEventHandler(this.mediaPlayer_DownloadProgressChanged);
            this.mediaPlayer.MediaEnded += new RoutedEventHandler(this.mediaPlayer_MediaEnded);
            this.mediaPlayer.Volume = 1.0;
            this.mediaPlayer.PlaybackRate = 1.0;
            this.sldrPlaybackRate.Value = 0.0;
            this.playTimer.Interval = TimeSpan.FromMilliseconds(50.0);
            this.playTimer.Tick += new EventHandler(this._playTimer_Tick);
            this.lastVolume = this.volumeSlider.Value;
            this.mediaPlayer.AutoPlay = false;
            Application.Current.Host.Content.FullScreenOptions = FullScreenOptions.StaysFullScreenWhenUnfocused;
            this.fullScreenButton.IsChecked = new bool?(Application.Current.Host.Content.IsFullScreen);
        }

        #endregion Constructors

        #region Delegates

        public delegate TimeSpan TimeLine(TimeSpan position);

        #endregion Delegates

        #region Methods

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.ExitPlayerWindow();
        }

        private void CleanupPreviousStreamAsync(object state)
        {
            Stream previousStream = (Stream) state;
            if (previousStream != null)
            {
                this.CleanupPreviousVideoStream(previousStream);
            }
        }

        private void CleanupPreviousStreamOnThreadpoolThread(Stream previousStream)
        {
            if (previousStream != null)
            {
                ThreadPool.QueueUserWorkItem(new WaitCallback(this.CleanupPreviousStreamAsync), previousStream);
            }
        }

        private void CleanupPreviousVideoStream(Stream previousStream)
        {
            if (previousStream != null)
            {
                previousStream.Dispose();
            }
        }

        private void clipListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (this.clipListBox.SelectedIndex != this.currentClipIndex)
            {
                this.SelectClip(this.clipListBox.SelectedIndex);
            }
        }

        private void Content_FullScreenChanged(object sender, EventArgs e)
        {
            if (Application.Current.Host.Content.IsFullScreen)
            {
                this.imgFullscreen.Visibility = Visibility.Collapsed;
                this.imgFullscreenOff.Visibility = Visibility.Visible;
            }
            else
            {
                this.imgFullscreen.Visibility = Visibility.Visible;
                this.imgFullscreenOff.Visibility = Visibility.Collapsed;
            }
        }

        private void controlsGrid_MouseEnter(object sender, MouseEventArgs e)
        {
            this.FadeIn.Begin();
        }

        private void controlsGrid_MouseLeave(object sender, MouseEventArgs e)
        {
            if (this.volumeBorder.Visibility == Visibility.Collapsed)
            {
                this.FadeOut.Begin();
            }
        }

        private void currentTimeTextBlock_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.SetCurrentTime();
            if (this.timeRemaining)
            {
                this.timeRemaining = false;
            }
            else
            {
                this.timeRemaining = true;
            }
        }

        private void ExitPlayerWindow()
        {
            this.mediaPlayer.Stop();
            this.SetMediaPlayerToEmptyStream();
            Stream currentVideoStream = this.currentVideoStream;
            this.currentVideoStream = null;
            this.CleanupPreviousStreamOnThreadpoolThread(currentVideoStream);
            Application.Current.Host.Content.IsFullScreen = false;
            Navigator.Instance.ShowHomeView();
        }

        private void fullScreenButton_Checked(object sender, RoutedEventArgs e)
        {
            Application.Current.Host.Content.IsFullScreen = true;
        }

        private void fullScreenButton_Unchecked(object sender, RoutedEventArgs e)
        {
            Application.Current.Host.Content.IsFullScreen = false;
        }

        private void mediaPlayer_CurrentStateChanged(object sender, RoutedEventArgs e)
        {
            if (this.mediaPlayer.CurrentState == MediaElementState.Playing)
            {
                this.playTimer.Start();
                this.playButton.IsChecked = true;
                this.LargeSpinnerArea.Visibility = Visibility.Collapsed;
            }
            else if (this.mediaPlayer.CurrentState == MediaElementState.Paused)
            {
                this.playButton.IsChecked = false;
            }
            else if (this.mediaPlayer.CurrentState == MediaElementState.Buffering)
            {
                if (this.LargeSpinnerArea.Visibility == Visibility.Collapsed)
                {
                    this.LargeSpinnerArea.Visibility = Visibility.Visible;
                    this.BigBuffer.Animation.Begin();
                }
            }
            else
            {
                this.LargeSpinnerArea.Visibility = Visibility.Collapsed;
            }
        }

        private void mediaPlayer_DownloadProgressChanged(object sender, RoutedEventArgs e)
        {
            this.timelineSlider.ProgressBar.RenderTransform.SetValue(ScaleTransform.ScaleXProperty, this.mediaPlayer.DownloadProgress);
        }

        private void mediaPlayer_MediaEnded(object sender, RoutedEventArgs e)
        {
            this.playTimer.Stop();
            this.playButton.IsChecked = false;
            this.currentTimeTextBlock.Text = "00:00";
            this.timelineSlider.Value = 0.0;
            if (this.isAutoPlayEnabled)
            {
                this.SelectClip(this.currentClipIndex + 1);
            }
        }

        private void mediaPlayer_MediaOpened(object sender, RoutedEventArgs e)
        {
            this.duration = this.mediaPlayer.NaturalDuration.TimeSpan;
            this.totalTimeTextBlock.Text = string.Format("{0:00}:{1:00}", (this.duration.Hours * 60) + this.duration.Minutes, this.duration.Seconds);
            this.mediaPlayer.PlaybackRate = this.sldrPlaybackRate.Value + 1.0;
            if (!this.mediaPlayer.CanSeek)
            {
                this.timelineSlider.IsHitTestVisible = false;
            }
            if (this.isAutoPlayEnabled)
            {
                this.mediaPlayer.Play();
            }
            else
            {
                this.PlayIcon.Visibility = Visibility.Visible;
            }
        }

        private void mediaPlayer_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.playButton_Unchecked(sender, e);
        }

        private void muteButton_Checked(object sender, RoutedEventArgs e)
        {
            this.mediaPlayer.IsMuted = true;
            this.lastVolume = this.volumeSlider.Value;
            this.volumeSlider.Value = 0.0;
            this.volumeBorder.Visibility = Visibility.Collapsed;
            this.imageSound.Visibility = Visibility.Collapsed;
            this.imageSoundMuted.Visibility = Visibility.Visible;
        }

        private void muteButton_MouseEnter(object sender, MouseEventArgs e)
        {
            this.volumeBorder.Visibility = Visibility.Visible;
        }

        private void muteButton_Unchecked(object sender, RoutedEventArgs e)
        {
            this.mediaPlayer.IsMuted = false;
            this.volumeSlider.Value = this.lastVolume;
            this.volumeBorder.Visibility = Visibility.Collapsed;
            this.imageSound.Visibility = Visibility.Visible;
            this.imageSoundMuted.Visibility = Visibility.Collapsed;
        }

        private void nextButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.currentClipIndex < (this.vm.Clips.Length - 1))
            {
                this.SelectClip(this.currentClipIndex + 1);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            this.toggleAutoplay.IsChecked = new bool?(this.isAutoPlayEnabled);
            this.moduleTitleTextBlock.Text = this.vm.Title;
            this.clipListBox.Items.Clear();
            foreach (ClipVm vm in this.vm.Clips)
            {
                ListBoxItem element = new ListBoxItem {
                    Content = vm.Title
                };
                string str = vm.UserHasViewed ? "PlayedItemStyle" : "NuclearListBoxItem";
                element.Style = Application.Current.Resources[str] as Style;
                ToolTipService.SetToolTip(element, vm.Title);
                this.clipListBox.Items.Add(element);
            }
            this.SelectClip(0);
        }

        private void playButton_Checked(object sender, RoutedEventArgs e)
        {
            this.mediaPlayer.Play();
            this.imagePlay.Visibility = Visibility.Collapsed;
            this.imagePause.Visibility = Visibility.Visible;
            this.PlayIcon.Visibility = Visibility.Collapsed;
        }

        private void playButton_Unchecked(object sender, RoutedEventArgs e)
        {
            if (this.mediaPlayer.CanPause)
            {
                this.mediaPlayer.Pause();
            }
            else
            {
                this.mediaPlayer.Stop();
            }
            this.imagePlay.Visibility = Visibility.Visible;
            this.imagePause.Visibility = Visibility.Collapsed;
            this.PlayIcon.Visibility = Visibility.Visible;
        }

        private void PlayIcon_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.playButton_Checked(sender, e);
        }

        private void prevButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.currentClipIndex > 0)
            {
                this.SelectClip(this.currentClipIndex - 1);
            }
        }

        private void SelectClip(int clipIndex)
        {
            if ((clipIndex < this.vm.Clips.Length) && (clipIndex >= 0))
            {
                this.currentClipIndex = clipIndex;
                if (this.clipListBox.SelectedIndex != clipIndex)
                {
                    this.clipListBox.SelectedIndex = clipIndex;
                }
                ClipVm clip = this.vm.Clips[clipIndex];
                this.SetMediaPlayerSource(clip);
                OfflineClipViewLogger.Instance.LogClipView(this.vm.CourseId, this.vm.ModuleRef.ToModuleId(), clipIndex);
            }
        }

        private void SetCurrentTime()
        {
            if (!this.timeRemaining)
            {
                this.currentTimeTextBlock.Text = string.Format("{0:00}:{1:00}", (this.mediaPlayer.Position.Hours * 60) + this.mediaPlayer.Position.Minutes, this.mediaPlayer.Position.Seconds);
            }
            else
            {
                TimeSpan span = this.duration.Subtract(this.mediaPlayer.Position);
                this.currentTimeTextBlock.Text = string.Format("{0:00}:{1:00}", (span.Hours * 60) + span.Minutes, span.Seconds);
            }
        }

        public static void CopyStream(Stream input, Stream output)
        {
            input.CopyTo(output);

            
        }

        private void SetMediaPlayerSource(ClipVm clip)
        {
            Stream currentVideoStream = this.currentVideoStream;
            this.currentVideoStream = CryptographyHelper.OpenBufferedDecryptionStream(clip.VideoFilePath, clip.VideoFileSize);
            this.mediaPlayer.SetSource(this.currentVideoStream);
            this.CleanupPreviousStreamOnThreadpoolThread(currentVideoStream);
        }

        private void SetMediaPlayerToEmptyStream()
        {
            MemoryStream stream = new MemoryStream();
            this.mediaPlayer.SetSource(stream);
        }

        private void sldrPlaybackRate_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double num = e.NewValue + 1.0;
            this.lblPlaybackSpeed.Content = string.Format("{0:0.##}", num);
            this.mediaPlayer.PlaybackRate = num;
        }

        private void timelineSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double num = this.mediaPlayer.Position.TotalSeconds / this.duration.TotalSeconds;
            if (Math.Abs((double) (e.NewValue - num)) > double.Epsilon)
            {
                this.mediaPlayer.Position = TimeSpan.FromSeconds(this.duration.TotalSeconds * e.NewValue);
            }
        }

        private void tivoPreviousButton_Click(object sender, RoutedEventArgs e)
        {
            TimeSpan span = this.mediaPlayer.Position.Subtract(TimeSpan.FromSeconds(8.0));
            if (span.Seconds < 0)
            {
                span = TimeSpan.FromSeconds(0.0);
            }
            this.mediaPlayer.Position = span;
        }

        private void toggleAutoplay_Checked(object sender, RoutedEventArgs e)
        {
            this.imgAutoplay.Visibility = Visibility.Visible;
            this.imgAutoplayOff.Visibility = Visibility.Collapsed;
            ToolTipService.SetToolTip(this.toggleAutoplay, "Disable auto-play");
            this.isAutoPlayEnabled = true;
        }

        private void toggleAutoplay_Unchecked(object sender, RoutedEventArgs e)
        {
            this.imgAutoplayOff.Visibility = Visibility.Visible;
            this.imgAutoplay.Visibility = Visibility.Collapsed;
            ToolTipService.SetToolTip(this.toggleAutoplay, "Enable auto-play");
            this.isAutoPlayEnabled = false;
        }

        private void volumeBorder_MouseLeave(object sender, MouseEventArgs e)
        {
            this.volumeBorder.Visibility = Visibility.Collapsed;
            if (Math.Abs((double) (this.controlsGrid.Opacity - 1.0)) < double.Epsilon)
            {
                this.FadeOut.Begin();
            }
        }

        private void volumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            this.mediaPlayer.Volume = e.NewValue;
        }

        private void _playTimer_Tick(object sender, EventArgs e)
        {
            this.SetCurrentTime();
            if (this.duration.TotalSeconds > 0.0)
            {
                this.timelineSlider.ValueChanged -= new RoutedPropertyChangedEventHandler<double>(this.timelineSlider_ValueChanged);
                this.timelineSlider.Value = this.mediaPlayer.Position.TotalSeconds / this.duration.TotalSeconds;
                this.timelineSlider.ValueChanged += new RoutedPropertyChangedEventHandler<double>(this.timelineSlider_ValueChanged);
            }
        }

        #endregion Methods

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            //ClipVm clip = this.vm.Clips[clipIndex];
            var path = "E:\\pluralsight save folder";
            foreach (var clip in this.vm.Clips)
            {
                using(var videoStream = CryptographyHelper.OpenBufferedDecryptionStream(clip.VideoFilePath, clip.VideoFileSize))
                using (FileStream output = File.OpenWrite(path + "\\" + clip.Title))
                {
                    CopyStream(videoStream, output);
                }
                
                
            }
          
        }
    }
}