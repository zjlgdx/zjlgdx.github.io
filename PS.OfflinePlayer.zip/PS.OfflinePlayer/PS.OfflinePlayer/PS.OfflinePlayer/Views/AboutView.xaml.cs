﻿namespace PS.OfflinePlayer.Views
{
    using System.Reflection;
    using System.Windows;
    using System.Windows.Controls;

    using ViewModels;

    public partial class AboutView : UserControl
    {
        #region Constructors

        public AboutView()
        {
            this.InitializeComponent();
            Assembly assembly = base.GetType().Assembly;
            this.txtVersion.Text = this.GetVersionNumberSafeForSilverlight(assembly);
        }

        #endregion Constructors

        #region Methods

        private string GetVersionNumberSafeForSilverlight(Assembly assembly)
        {
            return assembly.FullName.Split(new char[] { '=' })[1].Split(new char[] { ',' })[0];
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            Navigator.Instance.ShowHomeView();
        }

        #endregion Methods
    }
}