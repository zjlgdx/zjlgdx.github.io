﻿namespace PS.OfflinePlayer.Views
{
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Controls.Primitives;
    using System.Windows.Input;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;
    using System.Windows.Threading;

    public class MediaSlider : Slider
    {
        #region Fields

        public Thumb horizontalThumb;
        public Rectangle progressRect;

        private const short DragWaitInterval = 100;
        private const short DragWaitThreshold = 200;

        private readonly DispatcherTimer dragtimer = new DispatcherTimer();

        private bool dragSeekJustFired;
        private double dragTimeElapsed;
        private FrameworkElement horizontalLeftTrack;
        private FrameworkElement horizontalRightTrack;
        private double newValue;
        private double oldValue;
        private double prevNewValue;

        #endregion Fields

        #region Constructors

        public MediaSlider()
        {
            base.ValueChanged += new RoutedPropertyChangedEventHandler<double>(this.CustomSlider_ValueChanged);
            this.dragtimer.Interval = new TimeSpan(0, 0, 0, 0, 100);
            this.dragtimer.Tick += new EventHandler(this.dragtimer_Tick);
        }

        #endregion Constructors

        #region Events

        public event RoutedPropertyChangedEventHandler<double> MyValueChanged;

        public event RoutedPropertyChangedEventHandler<double> MyValueChangedInDrag;

        #endregion Events

        #region Properties

        public Rectangle ProgressBar
        {
            get
            {
                return (base.GetTemplateChild("Progress") as Rectangle);
            }
        }

        public Storyboard ProgressStoryboard
        {
            get
            {
                return (base.GetTemplateChild("ProgressStoryboard") as Storyboard);
            }
        }

        #endregion Properties

        #region Methods

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            this.horizontalThumb = base.GetTemplateChild("HorizontalThumb") as Thumb;
            this.horizontalLeftTrack = base.GetTemplateChild("LeftTrack") as FrameworkElement;
            this.horizontalRightTrack = base.GetTemplateChild("RightTrack") as FrameworkElement;
            this.progressRect = base.GetTemplateChild("Progress") as Rectangle;
            if (this.horizontalLeftTrack != null)
            {
                this.horizontalLeftTrack.MouseLeftButtonDown += new MouseButtonEventHandler(this.OnMoveThumbToMouse);
            }
            if (this.horizontalRightTrack != null)
            {
                this.horizontalRightTrack.MouseLeftButtonDown += new MouseButtonEventHandler(this.OnMoveThumbToMouse);
            }
            this.horizontalThumb.DragCompleted += new DragCompletedEventHandler(this.DragCompleted);
            this.progressRect.Width = base.Width;
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            Size size = base.ArrangeOverride(finalSize);
            if (double.IsNaN(this.horizontalThumb.Width) && (this.horizontalThumb.ActualWidth != 0.0))
            {
                this.horizontalThumb.Width = this.horizontalThumb.ActualWidth;
            }
            if (double.IsNaN(this.horizontalThumb.Height) && (this.horizontalThumb.ActualHeight != 0.0))
            {
                this.horizontalThumb.Height = this.horizontalThumb.ActualHeight;
            }
            if (double.IsNaN(this.horizontalThumb.Width))
            {
                this.horizontalThumb.Width = this.horizontalThumb.Height;
            }
            if (double.IsNaN(this.horizontalThumb.Height))
            {
                this.horizontalThumb.Height = this.horizontalThumb.Width;
            }
            return size;
        }

        private void CustomSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            this.oldValue = e.OldValue;
            this.newValue = e.NewValue;
            if (this.horizontalThumb.IsDragging)
            {
                this.dragTimeElapsed = 0.0;
                this.dragtimer.Stop();
                this.dragtimer.Start();
                this.dragSeekJustFired = false;
            }
        }

        private void DragCompleted(object sender, DragCompletedEventArgs e)
        {
            this.dragtimer.Stop();
            this.dragTimeElapsed = 0.0;
            RoutedPropertyChangedEventHandler<double> myValueChanged = this.MyValueChanged;
            if ((myValueChanged != null) && !this.dragSeekJustFired)
            {
                myValueChanged(this, new RoutedPropertyChangedEventArgs<double>(this.oldValue, base.Value));
            }
        }

        private void dragtimer_Tick(object sender, EventArgs e)
        {
            this.dragTimeElapsed += 100.0;
            if (this.dragTimeElapsed >= 200.0)
            {
                RoutedPropertyChangedEventHandler<double> myValueChangedInDrag = this.MyValueChangedInDrag;
                if ((myValueChangedInDrag != null) && (this.newValue != this.prevNewValue))
                {
                    myValueChangedInDrag(this, new RoutedPropertyChangedEventArgs<double>(this.oldValue, this.newValue));
                    this.dragSeekJustFired = true;
                    this.prevNewValue = this.newValue;
                }
                this.dragTimeElapsed = 0.0;
            }
        }

        private void OnMoveThumbToMouse(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            Point position = e.GetPosition(this);
            if (base.Orientation == Orientation.Horizontal)
            {
                base.Value = ((position.X - (this.horizontalThumb.ActualWidth / 2.0)) / (base.ActualWidth - this.horizontalThumb.ActualWidth)) * base.Maximum;
            }
            RoutedPropertyChangedEventHandler<double> myValueChanged = this.MyValueChanged;
            if (myValueChanged != null)
            {
                myValueChanged(this, new RoutedPropertyChangedEventArgs<double>(this.oldValue, base.Value));
            }
        }

        #endregion Methods
    }
}