﻿namespace PS.OfflinePlayer.Views
{
    using System;
    using System.Windows;
    using System.Windows.Controls;

    public partial class InstallView : UserControl
    {
        #region Constructors

        public InstallView()
        {
            this.InitializeComponent();
            Application.Current.InstallStateChanged += new EventHandler(this.OnInstallStateChanged);
            this.SetupInstallButton();
        }

        #endregion Constructors

        #region Methods

        private void Install_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Install();
        }

        private void OnInstallStateChanged(object sender, EventArgs e)
        {
            this.SetupInstallButton();
        }

        private void SetupInstallButton()
        {
            switch (Application.Current.InstallState)
            {
                case InstallState.Installing:
                    this.btnInstall.Content = "Installing...";
                    this.btnInstall.IsEnabled = false;
                    return;

                case InstallState.Installed:
                    this.btnInstall.Content = "Installed! Right-click to uninstall.";
                    this.btnInstall.IsEnabled = false;
                    return;
            }
            this.btnInstall.Content = "Install this app";
            this.btnInstall.IsEnabled = true;
        }

        #endregion Methods
    }
}