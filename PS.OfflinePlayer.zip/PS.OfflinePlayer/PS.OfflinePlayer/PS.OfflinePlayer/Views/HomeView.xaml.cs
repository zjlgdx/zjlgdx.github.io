﻿using System;
using System.ComponentModel;
using System.IO;
using PS.OfflinePlayer.ViewModels.Player;
using PS.SilverlightClientLib.Infrastructure.Cryptography;

namespace PS.OfflinePlayer.Views
{
    using System.Windows;
    using System.Windows.Controls;

    using ViewModels;

    public partial class HomeView : UserControl
    {
        #region Fields

        private readonly HomeVm vm;

        BackgroundWorker bw = new BackgroundWorker();
        

        #endregion Fields

        #region Constructors

        public HomeView()
        {
            this.InitializeComponent();
            this.vm = new HomeVm();
            base.DataContext = this.vm;
            bw.WorkerReportsProgress = true;
            bw.DoWork += new DoWorkEventHandler(bw_DoWork);
            bw.ProgressChanged += new ProgressChangedEventHandler(bw_ProgressChanged);
            bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bw_RunWorkerCompleted);
        }

        void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
             if (!(e.Error == null))
            {
                this.textBlock1.Text = ("Error: " + e.Error.Message);
            }

            else
            {
                this.textBlock1.Text = "Done!";
            }
        }

        void bw_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.textBlock1.Text = (e.ProgressPercentage.ToString() + "%");
        }

        void bw_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;

            int percent = 0;
            foreach (var module in this.vm.OfflineModules)
            {
                
                var vm = getVMModule(module.Tag);
                var couseTitle = module.CourseTitle;
                var moduleTitle = module.ModuleTitle;
                if (vm == null)
                {
                    continue;
                }

                var basePath = "G:\\pluralsight save folder";
                var coursePath = Path.Combine(basePath, RemoveInvalidCharactars(couseTitle));
                var modulePath = Path.Combine(coursePath, RemoveInvalidCharactars(moduleTitle));

                CreatePath(basePath);
                CreatePath(coursePath);
                CreatePath(modulePath);
                foreach (var clip in vm.Clips)
                {
                    using (var videoStream = CryptographyHelper.OpenBufferedDecryptionStream(clip.VideoFilePath, clip.VideoFileSize))
                    using (FileStream output = File.OpenWrite(Path.Combine(modulePath, RemoveInvalidCharactars(clip.Title) + ".wmv")))
                    {
                        CopyStream(videoStream, output);
                    }
                }

                percent++;
                int p = (int) ((decimal.Round(((decimal) percent/(decimal) this.vm.OfflineModules.Count), 2))*100);
                worker.ReportProgress(p);
            }
        }

        #endregion Constructors

        #region Methods

        public void OnActivated()
        {
            this.vm.OnActivated();
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            this.vm.About();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            this.vm.AddModule();
        }

        private void logout_Click(object sender, RoutedEventArgs e)
        {
            this.vm.SignOutIfUserAgrees();
        }

        private void Pause_Click(object sender, RoutedEventArgs e)
        {
            this.vm.PauseFetch();
        }

        private void Play_Click(object sender, RoutedEventArgs e)
        {
            this.vm.PlayModule((string) ((Button) sender).Tag);
        }

        private void ProgressUpdates_Click(object sender, RoutedEventArgs e)
        {
            this.vm.ShowProgressUpdatesDescriptionMessage();
        }

        private void Remove_Click(object sender, RoutedEventArgs e)
        {
            this.vm.RemoveModule((string) ((Button) sender).Tag);
        }

        private void Resume_Click(object sender, RoutedEventArgs e)
        {
            this.vm.ResumeFetch();
        }

        #endregion Methods

        // save to vedio
        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if (bw.IsBusy != true)
            {
                 
                bw.RunWorkerAsync();
            }
        }

        private static string RemoveInvalidCharactars(string path)
        {
           return path.Replace("/", " ")
                .Replace(":", " ")
                .Replace("*", " ")
                .Replace("?", " ")
                .Replace("<", " ")
                .Replace(">", " ")
                .Replace("|", " ")
                .Replace("\"", "");
        }

        private static void CreatePath(string path)
        {
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        private static void CopyStream(Stream input, Stream output)
        {
            input.CopyTo(output);


        }

        private ModuleVm getVMModule(string tag)
        {
            string[] strArray = tag.Split(new char[] { ':' }); 
            if (strArray.Length == 2)
            {
                string courseId = strArray[0];
                string moduleId = strArray[1];
                ModuleVm vm = new ModuleVmBuilder(courseId, moduleId).BuildModuleVm();
                //Navigator.Instance.ShowPlayerView(vm);
                return vm;
            }
            return null;
        }
    }
}