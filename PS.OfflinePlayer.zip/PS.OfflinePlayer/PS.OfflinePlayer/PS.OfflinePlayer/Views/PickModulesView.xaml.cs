﻿namespace PS.OfflinePlayer.Views
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;

    using SilverlightClientLib.Infrastructure.Shared;
    using SilverlightClientLib.Models.CatalogModel;
    using SilverlightClientLib.Models.OfflineModuleModel;

    using ViewModels;

    public partial class PickModulesView : UserControl
    {
        #region Fields

        private string currentCourseId = "";
        private PickModulesVm vm;

        #endregion Fields

        #region Constructors

        public PickModulesView()
        {
            this.InitializeComponent();
        }

        #endregion Constructors

        #region Properties

        private IEnumerable<CheckBox> CheckedBoxes
        {
            get
            {
                return this.LayoutRoot.Descendents<CheckBox>().Where<CheckBox>(delegate (CheckBox cb) {
                    if (cb.IsChecked.HasValue)
                    {
                        return cb.IsChecked.Value;
                    }
                    return false;
                }).ToArray<CheckBox>();
            }
        }

        #endregion Properties

        #region Methods

        public void SetCourseId(string newCourseId)
        {
            if (this.currentCourseId != newCourseId)
            {
                this.currentCourseId = newCourseId;
                this.LoadPage();
            }
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            this.Submit();
        }

        private void CourseList_Click(object sender, RoutedEventArgs e)
        {
            if (this.IsOkayToNavAwayWithoutSaving())
            {
                Navigator.Instance.ShowPickCourseView();
            }
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            if (this.IsOkayToNavAwayWithoutSaving())
            {
                Navigator.Instance.ShowHomeView();
            }
        }

        private bool IsOkayToNavAwayWithoutSaving()
        {
            if ((this.vm.PickSlotsStatus.SlotsPickedInModulePicker > 0) && (MessageBox.Show("Leave without adding these modules to the cache?", "You have unadded modules", MessageBoxButton.OKCancel) == MessageBoxResult.Cancel))
            {
                return false;
            }
            this.TurnOffAllCheckboxes();
            return true;
        }

        private void LayoutRoot_KeyDown(object sender, KeyEventArgs e)
        {
            if (Key.Enter == e.Key)
            {
                this.Submit();
            }
        }

        private void LoadPage()
        {
            Course course = Catalog.Instance.FindCourse(this.currentCourseId);
            if (course == null)
            {
                Navigator.Instance.ShowPickCourseView();
            }
            else
            {
                this.vm = new PickModulesVmBuilder().BuildPickModulesVm(course);
                base.DataContext = this.vm;
            }
        }

        private void Module_CheckChanged(object sender, RoutedEventArgs e)
        {
            if (this.CheckedBoxes.Count<CheckBox>() > OfflineModuleManifest.Instance.NumSlotsLeft)
            {
                MessageBox.Show("All cache slots are filled");
                ((CheckBox) sender).IsChecked = false;
            }
            this.vm.PickSlotsStatus.SlotsPickedInModulePicker = this.CheckedBoxes.Count<CheckBox>();
        }

        private void SelectAll_Click(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox box in this.LayoutRoot.Descendents<CheckBox>())
            {
                if (!this.vm.PickSlotsStatus.AreSlotsAvailable)
                {
                    break;
                }
                box.IsChecked = true;
            }
        }

        private void SelectNone_Click(object sender, RoutedEventArgs e)
        {
            this.TurnOffAllCheckboxes();
        }

        private void Submit()
        {
            var source = (from tag in (from cb in this.CheckedBoxes select cb.Tag).Cast<string>()
                select tag.Split(new char[] { ':' }) into parts
                select new { CourseId = parts[0], ModuleId = parts[1] }).ToArray();
            OfflineModuleManifest instance = OfflineModuleManifest.Instance;
            if (source.Count() > instance.NumSlotsLeft)
            {
                MessageBox.Show("You have selected {0} modules, but you only have {1} slots remaining in your offline cache.".FormatWith(new object[] { source.Count(), instance.NumSlotsLeft }));
            }
            else
            {
                this.TurnOffAllCheckboxes();
                foreach (var type in source)
                {
                    string courseId = type.CourseId;
                    string moduleId = type.ModuleId;
                    instance.AddModule(courseId, moduleId);
                }
                Navigator.Instance.ShowHomeView();
            }
        }

        private void TurnOffAllCheckboxes()
        {
            foreach (CheckBox box in this.LayoutRoot.Descendents<CheckBox>())
            {
                box.IsChecked = false;
            }
        }

        #endregion Methods
    }
}