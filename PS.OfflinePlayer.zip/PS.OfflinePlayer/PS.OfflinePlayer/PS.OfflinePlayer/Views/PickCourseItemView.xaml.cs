﻿namespace PS.OfflinePlayer.Views
{
    using System.Windows;
    using System.Windows.Controls;

    using ViewModels;

    public partial class PickCourseItemView : UserControl
    {
        #region Constructors

        public PickCourseItemView()
        {
            this.InitializeComponent();
        }

        #endregion Constructors

        #region Methods

        private void HyperlinkButton_Click(object sender, RoutedEventArgs e)
        {
            PickCourseItemVm dataContext = (PickCourseItemVm) base.DataContext;
            string id = dataContext.Id;
            Navigator.Instance.ShowPickModuleView(id);
        }

        #endregion Methods
    }
}