﻿namespace PS.OfflinePlayer.Views
{
    using System.Windows.Controls;

    public partial class PickSlotsStatus : UserControl
    {
        #region Constructors

        public PickSlotsStatus()
        {
            this.InitializeComponent();
        }

        #endregion Constructors
    }
}