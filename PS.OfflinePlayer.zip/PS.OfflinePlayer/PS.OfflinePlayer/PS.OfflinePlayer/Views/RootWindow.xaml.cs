﻿namespace PS.OfflinePlayer.Views
{
    using System.Windows;
    using System.Windows.Controls;

    public partial class RootWindow : UserControl
    {
        #region Constructors

        public RootWindow()
        {
            this.InitializeComponent();
        }

        #endregion Constructors

        #region Methods

        public void SetContent(UIElement content)
        {
            base.Content = content;
        }

        #endregion Methods
    }
}