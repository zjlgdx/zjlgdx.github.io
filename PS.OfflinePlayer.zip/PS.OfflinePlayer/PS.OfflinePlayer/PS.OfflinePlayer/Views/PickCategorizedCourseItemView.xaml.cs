﻿namespace PS.OfflinePlayer.Views
{
    using System.Windows.Controls;

    public partial class PickCategorizedCourseItemView : UserControl
    {
        public PickCategorizedCourseItemView()
        {
            this.InitializeComponent();
        }

    }
}

