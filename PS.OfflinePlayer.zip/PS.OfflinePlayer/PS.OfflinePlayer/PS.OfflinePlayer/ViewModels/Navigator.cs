﻿namespace PS.OfflinePlayer.ViewModels
{
    using System.Windows;

    using Player;

    using SilverlightClientLib.Infrastructure.App;
    using SilverlightClientLib.Models.Shared;

    using Views;

    public class Navigator
    {
        #region Fields

        private readonly RootWindow rootWindow = new RootWindow();

        private static Navigator theNavigator;

        private AboutView aboutViewMemo;
        private HomeView homeViewMemo;
        private PickCourseView pickCourseViewMemo;
        private PickModulesView pickModulesViewMemo;

        #endregion Fields

        #region Constructors

        private Navigator()
        {
        }

        #endregion Constructors

        #region Properties

        public static Navigator Instance
        {
            get
            {
                return (theNavigator ?? (theNavigator = new Navigator()));
            }
        }

        public ViewType ViewType
        {
            get; private set;
        }

        private static ScreenSizeTracker ScreenSizeTracker
        {
            get
            {
                return AppState.Instance.ScreenSizeTracker;
            }
        }

        private AboutView AboutView
        {
            get
            {
                return (this.aboutViewMemo ?? (this.aboutViewMemo = new AboutView()));
            }
        }

        private HomeView HomeView
        {
            get
            {
                return (this.homeViewMemo ?? (this.homeViewMemo = new HomeView()));
            }
        }

        private PickCourseView PickCourseView
        {
            get
            {
                return (this.pickCourseViewMemo ?? (this.pickCourseViewMemo = new PickCourseView()));
            }
        }

        private PickModulesView PickModulesView
        {
            get
            {
                return (this.pickModulesViewMemo ?? (this.pickModulesViewMemo = new PickModulesView()));
            }
        }

        private string PreferredScreenSizeKey
        {
            get
            {
                return this.ViewType.ToString();
            }
        }

        #endregion Properties

        #region Methods

        public void BeginTrackingSizeUpdates()
        {
            this.rootWindow.SizeChanged += new SizeChangedEventHandler(this.rootWindow_SizeChanged);
        }

        public void InitializeInstall()
        {
            Application.Current.RootVisual = this.rootWindow;
            this.ViewType = ViewType.Install;
            this.rootWindow.SetContent(new InstallView());
        }

        public void InitializeOOB()
        {
            Application.Current.RootVisual = this.rootWindow;
            this.ShowLoginView();
            this.BeginTrackingSizeUpdates();
        }

        public void ShowAboutView()
        {
            this.ShowPrimaryView(this.AboutView);
        }

        public void ShowHomeView()
        {
            this.ShowPrimaryView(this.HomeView);
            this.HomeView.OnActivated();
        }

        public void ShowLoginView()
        {
            LoginView window = new LoginView();
            this.ShowPrimaryView(window);
            window.Initialize();
        }

        public void ShowPickCourseView()
        {
            this.ShowPrimaryView(this.PickCourseView);
        }

        public void ShowPickModuleView(string courseId)
        {
            this.ShowPrimaryView(this.PickModulesView);
            this.PickModulesView.SetCourseId(courseId);
        }

        public void ShowPlayerView(ModuleVm vm)
        {
            this.ViewType = PS.OfflinePlayer.ViewModels.ViewType.Player;
            this.ResizeMainWindow();
            this.rootWindow.SetContent(new PlayerView(vm));
        }

        private ScreenSize MakeScreenSize(Size size)
        {
            if (!Application.Current.Host.Content.IsFullScreen)
            {
                return ScreenSize.MakeNormalScreenSize(size);
            }
            return ScreenSize.MakeFullScreenSize();
        }

        private void ResizeMainWindow()
        {
            ScreenSize size;
            if (ScreenSizeTracker.PreferredScreenSizes.TryGetValue(this.PreferredScreenSizeKey, out size))
            {
                AppMainWindowHelper.TrySetSize(size);
            }
        }

        private void rootWindow_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            ScreenSize size = this.MakeScreenSize(e.NewSize);
            ScreenSizeTracker.UpdatePreferredScreenSize(this.PreferredScreenSizeKey, size);
        }

        private void ShowPrimaryView(UIElement window)
        {
            this.ViewType = PS.OfflinePlayer.ViewModels.ViewType.Primary;
            this.ResizeMainWindow();
            this.rootWindow.SetContent(window);
        }

        #endregion Methods
    }
}