﻿namespace PS.OfflinePlayer.ViewModels
{
    using PS.SilverlightClientLib.Infrastructure.Shared;
    using PS.SilverlightClientLib.Models.CatalogModel;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class PickCategorizedCourseItemVmBuilder
    {
        private readonly PickCourseItemVmBuilder pickCourseItemVmBuilder = new PickCourseItemVmBuilder();

        public IEnumerable<PickCategoryItemVm> BuildPickCategorizedCourseItemVms()
        {
            ICatalog instance = Catalog.Instance;
            return Catalog.Instance.CategoryIds.Select<string, Category>(new Func<string, Category>(instance.FindCategory)).SkipNulls<Category>().Select<Category, PickCategoryItemVm>(new Func<Category, PickCategoryItemVm>(this.BuildPickCategoryItemVm)).ToArray<PickCategoryItemVm>();
        }

        private PickCategoryItemVm BuildPickCategoryItemVm(Category category)
        {
            return new PickCategoryItemVm { CategoryDisplayName = category.Title, Courses = this.BuildPickCourseItemVms(category.CourseIds) };
        }

        private IEnumerable<PickCourseItemVm> BuildPickCourseItemVms(IEnumerable<string> courseIds)
        {
            ICatalog instance = Catalog.Instance;
            return courseIds.Select<string, Course>(new Func<string, Course>(instance.FindCourse)).SkipNulls<Course>().Select<Course, PickCourseItemVm>(new Func<Course, PickCourseItemVm>(this.pickCourseItemVmBuilder.BuildPickCourseItemVm)).ToArray<PickCourseItemVm>();
        }
    }
}

