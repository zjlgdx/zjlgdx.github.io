﻿namespace PS.OfflinePlayer.ViewModels
{
    using System.Collections.Specialized;

    using SilverlightClientLib.Infrastructure.Notifications;
    using SilverlightClientLib.Models.OfflineModuleModel;

    public class PickSlotsStatusVm : ModelWithNotificationBase<PickSlotsStatusVm>
    {
        #region Fields

        private int slotsPickedInModulePicker;

        #endregion Fields

        #region Constructors

        public PickSlotsStatusVm()
        {
            NotifyCollectionChangedEventHandler handler = null;
            if (handler == null)
            {
                handler = (sender, e) => base.NotifyEntireModelChanged();
            }
            OfflineModuleManifest.Instance.OfflineModules.CollectionChanged += handler;
        }

        #endregion Constructors

        #region Properties

        public bool AreSlotsAvailable
        {
            get
            {
                return (this.SlotsTaken < this.TotalSlots);
            }
        }

        public int ProgressPercentage
        {
            get
            {
                return ((100 * this.SlotsTaken) / this.TotalSlots);
            }
        }

        public int SlotsPickedInModulePicker
        {
            get
            {
                return this.slotsPickedInModulePicker;
            }
            set
            {
                this.slotsPickedInModulePicker = value;
                base.NotifyEntireModelChanged();
            }
        }

        public int SlotsTaken
        {
            get
            {
                return (OfflineModuleManifest.Instance.OfflineModules.Count + this.slotsPickedInModulePicker);
            }
        }

        public int TotalSlots
        {
            get
            {
                return OfflineModuleManifest.Instance.GetMaxModulesToCache();
            }
        }

        #endregion Properties
    }
}