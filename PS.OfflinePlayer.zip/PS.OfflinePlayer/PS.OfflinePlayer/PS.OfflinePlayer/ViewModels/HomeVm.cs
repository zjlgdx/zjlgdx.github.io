﻿namespace PS.OfflinePlayer.ViewModels
{
    using System;
    using System.Collections.ObjectModel;
    using System.Collections.Specialized;
    using System.Linq;
    using System.Net.NetworkInformation;
    using System.Windows;

    using Player;

    using SilverlightClientLib.Infrastructure.Notifications;
    using SilverlightClientLib.Infrastructure.Shared;
    using SilverlightClientLib.Models.CatalogModel;
    using SilverlightClientLib.Models.OfflineModuleModel;
    using SilverlightClientLib.Models.Shared;
    using SilverlightClientLib.Models.UserProfileModel;

    public class HomeVm : ModelWithNotificationBase<HomeVm>
    {
        #region Fields

        private bool isPausedByUser;
        private bool isSignOutPending;
        private PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure.ModuleFetcher moduleFetcher;
        private ModuleDeleteCommand pendingDeleteCommand;

        #endregion Fields

        #region Constructors

        public HomeVm()
        {
            EventHandler handler = null;
            NetworkAddressChangedEventHandler handler2 = null;
            EventHandler handler3 = null;
            OfflineModuleManifest.Instance.OfflineModules.CollectionChanged += new NotifyCollectionChangedEventHandler(this.OfflineModules_CollectionChanged);
            if (handler == null)
            {
                handler = (sender, e) => base.NotifyEntireModelChanged();
            }
            OfflineClipViewLogger.Instance.Updated += handler;
            if (handler2 == null)
            {
                handler2 = (sender, e1) => base.NotifyEntireModelChanged();
            }
            NetworkChange.NetworkAddressChanged += handler2;
            if (handler3 == null)
            {
                handler3 = (sender, e2) => this.AbortFetchInProgress();
            }
            Application.Current.Exit += handler3;
            this.OfflineModules = OfflineModuleVmAssembler.AssembleOfflineModuleVms();
        }

        #endregion Constructors

        #region Properties

        public bool CanUserAddModule
        {
            get
            {
                return (OfflineModuleManifest.Instance.NumSlotsLeft != 0);
            }
        }

        public int CountOfOfflineModules
        {
            get
            {
                return this.OfflineModules.Count;
            }
        }

        public string FirstName
        {
            get
            {
                return UserProfile.Instance.FirstName;
            }
        }

        public bool IsPauseButtonEnabled
        {
            get
            {
                return this.IsFetchInProgress;
            }
        }

        public bool IsResumeButtonEnabled
        {
            get
            {
                return ((!this.IsFetchInProgress && this.DoAnyModulesNeedFetching()) && Network.IsAvailable);
            }
        }

        public int NumQueuedClipViews
        {
            get
            {
                return OfflineClipViewLogger.Instance.PendingClipViewsToTransfer();
            }
        }

        public int OfflineModuleCapacity
        {
            get
            {
                return OfflineModuleManifest.Instance.GetMaxModulesToCache();
            }
        }

        public ObservableCollection<OfflineModuleVm> OfflineModules
        {
            get; private set;
        }

        public int PercentCapacityUsed
        {
            get
            {
                return ((100 * this.OfflineModules.Count) / this.OfflineModuleCapacity);
            }
        }

        public Visibility QueuedClipViewVisiblity
        {
            get
            {
                if (OfflineClipViewLogger.Instance.PendingClipViewsToTransfer() != 0)
                {
                    return Visibility.Visible;
                }
                return Visibility.Collapsed;
            }
        }

        public Visibility RootGridVisibility
        {
            get
            {
                if (!this.isSignOutPending)
                {
                    return Visibility.Visible;
                }
                return Visibility.Collapsed;
            }
        }

        public string SignOutText
        {
            get
            {
                return string.Format("(not {0}?", this.FirstName);
            }
        }

        public Visibility SplashPanelVisibility
        {
            get
            {
                if (this.OfflineModules.Count != 0)
                {
                    return Visibility.Collapsed;
                }
                return Visibility.Visible;
            }
        }

        public string WebsiteUri
        {
            get
            {
                return Config.WebsiteHttpBaseUri;
            }
        }

        private bool IsFetchInProgress
        {
            get
            {
                return (null != this.ModuleFetcher);
            }
        }

        private PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure.ModuleFetcher ModuleFetcher
        {
            get
            {
                return this.moduleFetcher;
            }
            set
            {
                this.moduleFetcher = value;
                base.NotifyEntireModelChanged();
            }
        }

        #endregion Properties

        #region Methods

        public void About()
        {
            Navigator.Instance.ShowAboutView();
        }

        public void AddModule()
        {
            Navigator.Instance.ShowPickCourseView();
        }

        public void OnActivated()
        {
            this.isSignOutPending = false;
            if ((!this.isPausedByUser && Network.IsAvailable) && !this.IsFetchInProgress)
            {
                this.FetchNextIncompleteModuleAsync();
            }
        }

        public void PauseFetch()
        {
            this.isPausedByUser = true;
            this.AbortFetchInProgress();
        }

        public void PlayModule(string tag)
        {
            string[] strArray = ParseCourseAndModuleIdFromTag(tag);
            if (strArray.Length == 2)
            {
                string courseId = strArray[0];
                string moduleId = strArray[1];
                ModuleVm vm = new ModuleVmBuilder(courseId, moduleId).BuildModuleVm();
                Navigator.Instance.ShowPlayerView(vm);
            }
        }

        public void RemoveModule(string tag)
        {
            string[] strArray = ParseCourseAndModuleIdFromTag(tag);
            if (strArray.Length == 2)
            {
                string moduleId = strArray[1];
                if (!UserWantsToCancelRemove(moduleId))
                {
                    ModuleDeleteCommand command = new ModuleDeleteCommand(moduleId);
                    if (this.IsModuleBeingActivelyFetched(moduleId))
                    {
                        this.pendingDeleteCommand = command;
                        this.AbortFetchInProgress();
                    }
                    else
                    {
                        command.Execute();
                    }
                }
            }
        }

        public void ResumeFetch()
        {
            if (!Network.IsAvailable)
            {
                MessageBox.Show("You need to have an active network connection in order to fetch content", "Network Unavailable", MessageBoxButton.OK);
            }
            else
            {
                this.isPausedByUser = false;
                if (!this.IsFetchInProgress)
                {
                    this.FetchNextIncompleteModuleAsync();
                }
            }
        }

        public void ShowProgressUpdatesDescriptionMessage()
        {
            MessageBox.Show("Each time you view a clip offline, we track your progress locally. If this number is greater than zero, you should connect at the next convenient time to upload your progress.", "About progress updates", MessageBoxButton.OK);
        }

        public void SignOutIfUserAgrees()
        {
            if (MessageBox.Show("Signing out will clear your offline cache and close the application. Are you sure?", "Please confirm", MessageBoxButton.OKCancel) == MessageBoxResult.OK)
            {
                if (this.IsFetchInProgress)
                {
                    this.isSignOutPending = true;
                    this.AbortFetchInProgress();
                    base.NotifyEntireModelChanged();
                }
                else
                {
                    this.SignOut();
                }
            }
        }

        private static string[] ParseCourseAndModuleIdFromTag(string tag)
        {
            return tag.Split(new char[] { ':' });
        }

        private static bool UserWantsToCancelRemove(string moduleId)
        {
            Module module = Catalog.Instance.FindModule(moduleId);
            return ((module != null) && (MessageBoxResult.Cancel == MessageBox.Show("Remove {0}?".FormatWith(new object[] { module.Title }), "Confirm remove", MessageBoxButton.OKCancel)));
        }

        private void AbortFetchInProgress()
        {
            if (this.IsFetchInProgress)
            {
                this.ModuleFetcher.Abort();
            }
        }

        private bool DoAnyModulesNeedFetching()
        {
            return this.OfflineModules.Any<OfflineModuleVm>(x => !x.IsReadyToPlay);
        }

        private void FetchAsync(OfflineModule nextModule)
        {
            this.ModuleFetcher = new PS.SilverlightClientLib.Infrastructure.OfflineModuleInfrastructure.ModuleFetcher(nextModule, this.VmForModel(nextModule.ModuleId));
            this.ModuleFetcher.RequestCompleted += new EventHandler<LoadCompletedEventArgs>(this.moduleFetcher_RequestCompleted);
            this.ModuleFetcher.FetchModuleAsync();
        }

        private void FetchNextIncompleteModuleAsync()
        {
            OfflineModule nextIncompleteModule = this.GetNextIncompleteModule();
            if (nextIncompleteModule != null)
            {
                this.FetchAsync(nextIncompleteModule);
            }
        }

        private OfflineModule GetNextIncompleteModule()
        {
            return (from x in this.OfflineModules select x.ModuleId).Select<string, OfflineModule>(new Func<string, OfflineModule>(OfflineModuleManifest.Instance.FindModule)).OrderBy<OfflineModule, int>(delegate (OfflineModule x) {
                if (x.FetchState != FetchState.FetchInProgress)
                {
                    return 1;
                }
                return 0;
            }).FirstOrDefault<OfflineModule>(om => (om.FetchState != FetchState.FetchComplete));
        }

        private bool IsModuleBeingActivelyFetched(string moduleId)
        {
            return (this.IsFetchInProgress && (this.ModuleFetcher.ModuleId == moduleId));
        }

        private void moduleFetcher_RequestCompleted(object sender, LoadCompletedEventArgs args)
        {
            if (!this.SignedOut())
            {
                this.ModuleFetcher = null;
                if (args.Error != null)
                {
                    if (args.Error is NotAuthorizedException)
                    {
                        Navigator.Instance.ShowLoginView();
                    }
                    else if (args.Cancelled)
                    {
                        this.OnFetchCancellation();
                    }
                    else
                    {
                        MessageBox.Show("Fetch failed: please check your network connection and press Resume All when you're back online.");
                    }
                }
                else
                {
                    this.FetchNextIncompleteModuleAsync();
                }
            }
        }

        private void OfflineModules_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            OfflineModuleVmAssembler.UpdateOfflineModulesOnModelCollectionChanged(this.OfflineModules, e.OldItems, e.NewItems);
            base.NotifyEntireModelChanged();
        }

        private void OnFetchCancellation()
        {
            if (this.pendingDeleteCommand != null)
            {
                this.pendingDeleteCommand.Execute();
                this.pendingDeleteCommand = null;
                this.FetchNextIncompleteModuleAsync();
            }
        }

        private bool SignedOut()
        {
            if (this.isSignOutPending)
            {
                this.isSignOutPending = false;
                this.SignOut();
                return true;
            }
            return false;
        }

        private void SignOut()
        {
            CredentialHelper.DeleteCredentials();
            OfflineModuleManifest.Instance.OnSignOut();
            UserProfile.OnSignOut();
            Application.Current.MainWindow.Close();
        }

        private OfflineModuleVm VmForModel(string moduleId)
        {
            return this.OfflineModules.First<OfflineModuleVm>(x => (x.ModuleId == moduleId));
        }

        #endregion Methods
    }
}