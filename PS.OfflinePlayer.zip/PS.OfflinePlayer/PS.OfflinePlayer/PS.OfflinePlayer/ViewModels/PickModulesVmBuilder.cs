﻿namespace PS.OfflinePlayer.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows;

    using SilverlightClientLib.Infrastructure.Shared;
    using SilverlightClientLib.Models.CatalogModel;
    using SilverlightClientLib.Models.OfflineModuleModel;

    public class PickModulesVmBuilder
    {
        #region Fields

        private string courseId;
        private Dictionary<string, OfflineModule> offlineModules;

        #endregion Fields

        #region Methods

        public PickModulesVm BuildPickModulesVm(Course course)
        {
            this.offlineModules = OfflineModuleManifest.Instance.OfflineModules.ToDictionary<OfflineModule, string>(offlineModule => offlineModule.ModuleId);
            this.courseId = course.Id;
            PickModulesVm vm = new PickModulesVm {
                CourseTitle = course.Title
            };
            ICatalog instance = Catalog.Instance;
            vm.Modules = course.ModuleIds.Select<string, Module>(new Func<string, Module>(instance.FindModule)).SkipNulls<Module>().Select<Module, ModuleItemVm>(new Func<Module, ModuleItemVm>(this.AssembleModuleItemVm));
            return vm;
        }

        internal static string AssembleChooseProse()
        {
            OfflineModuleManifest instance = OfflineModuleManifest.Instance;
            string formatString = instance.OfflineModules.IsEmpty<OfflineModule>() ? "Choose up to {0}" : "You may choose {0} more";
            return (formatString.FormatWith(new object[] { instance.NumSlotsLeft }) + " module(s) for offline viewing.");
        }

        private Visibility AssembleChooseButtonVisibility(string moduleId)
        {
            if (!this.IsModuleCached(moduleId))
            {
                return Visibility.Visible;
            }
            return Visibility.Collapsed;
        }

        private ModuleItemVm AssembleModuleItemVm(Module module)
        {
            return new ModuleItemVm { CourseId = this.courseId, ModuleId = module.Id, ModuleTitle = module.Title, ChooseButtonVisibility = this.AssembleChooseButtonVisibility(module.Id) };
        }

        private bool IsModuleCached(string moduleId)
        {
            return this.offlineModules.ContainsKey(moduleId);
        }

        #endregion Methods
    }
}