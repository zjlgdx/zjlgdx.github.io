﻿namespace PS.OfflinePlayer.ViewModels
{
    using System.Collections.Generic;
    using SilverlightClientLib.Infrastructure.Notifications;

    public class PickCourseVm : ModelWithNotificationBase<PickCourseVm>
    {
        private readonly PickSlotsStatusVm pickSlotsStatus = new PickSlotsStatusVm();

        public IEnumerable<PickCategoryItemVm> Categories { get; set; }

        public PickSlotsStatusVm PickSlotsStatus
        {
            get
            {
                return this.pickSlotsStatus;
            }
        }
    }
}

