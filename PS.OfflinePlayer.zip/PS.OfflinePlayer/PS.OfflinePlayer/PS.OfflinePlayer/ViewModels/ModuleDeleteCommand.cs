﻿namespace PS.OfflinePlayer.ViewModels
{
    using SilverlightClientLib.Models.OfflineModuleModel;

    public class ModuleDeleteCommand
    {
        #region Fields

        private readonly string moduleId;

        #endregion Fields

        #region Constructors

        public ModuleDeleteCommand(string moduleId)
        {
            this.moduleId = moduleId;
        }

        #endregion Constructors

        #region Methods

        public void Execute()
        {
            OfflineModuleManifest.Instance.RemoveModule(this.moduleId);
        }

        #endregion Methods
    }
}