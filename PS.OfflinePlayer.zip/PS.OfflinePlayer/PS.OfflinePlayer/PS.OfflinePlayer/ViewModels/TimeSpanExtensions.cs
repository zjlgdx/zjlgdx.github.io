﻿namespace PS.OfflinePlayer.ViewModels
{
    using System;

    public static class TimeSpanExtensions
    {
        #region Methods

        public static string HowLongDescription(this TimeSpan span)
        {
            if (span.TotalMinutes < 2.0)
            {
                return "moments";
            }
            if (span.TotalHours < 2.0)
            {
                return string.Format("{0} minutes", (int) span.TotalMinutes);
            }
            if (span.TotalDays < 2.0)
            {
                return string.Format("{0} hours", (int) span.TotalHours);
            }
            if (span.TotalDays < 91.0)
            {
                return string.Format("{0} days", (int) span.TotalDays);
            }
            if (span.TotalDays < 730.0)
            {
                return string.Format("{0} months", ((int) span.TotalDays) / 30);
            }
            return string.Format("{0} years", ((int) span.TotalDays) / 0x16d);
        }

        #endregion Methods
    }
}