﻿namespace PS.OfflinePlayer.ViewModels
{
    using System;
    using System.Windows;

    using SilverlightClientLib.Models.Shared;

    public static class AppMainWindowHelper
    {
        #region Properties

        public static Window AppMainWindow
        {
            get
            {
                return Application.Current.MainWindow;
            }
        }

        private static Size CurrentSize
        {
            get
            {
                double width = AppMainWindow.Width;
                return new Size(width, AppMainWindow.Height);
            }
        }

        #endregion Properties

        #region Methods

        public static void SetSize(Size size)
        {
            Window appMainWindow = AppMainWindow;
            EnsureNotMinimized(appMainWindow);
            appMainWindow.Width = size.Width;
            appMainWindow.Height = size.Height;
        }

        public static void TrySetSize(ScreenSize screenSize)
        {
            Application.Current.Host.Content.IsFullScreen = screenSize.IsFullScreen;
            if (!screenSize.IsFullScreen)
            {
                Size currentSize = CurrentSize;
                try
                {
                    SetSize(screenSize.Size);
                }
                catch (ArgumentOutOfRangeException)
                {
                    try
                    {
                        SetSize(currentSize);
                    }
                    catch (ArgumentOutOfRangeException)
                    {
                    }
                }
            }
        }

        private static void EnsureNotMinimized(Window appMainWindow)
        {
            appMainWindow.WindowState = WindowState.Normal;
        }

        #endregion Methods
    }
}