﻿namespace PS.OfflinePlayer.ViewModels
{
    using System.Collections.Generic;

    public class PickCategoryItemVm
    {
        public string CategoryDisplayName { get; set; }

        public IEnumerable<PickCourseItemVm> Courses { get; set; }
    }
}

