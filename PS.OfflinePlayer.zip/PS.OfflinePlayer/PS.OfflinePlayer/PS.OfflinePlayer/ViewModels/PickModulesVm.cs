﻿namespace PS.OfflinePlayer.ViewModels
{
    using System.Collections.Generic;
    using SilverlightClientLib.Infrastructure.Notifications;

    public class PickModulesVm : ModelWithNotificationBase<PickModulesVm>
    {
        private readonly PickSlotsStatusVm pickSlotsStatus = new PickSlotsStatusVm();

        public string CourseTitle { get; set; }

        public IEnumerable<ModuleItemVm> Modules { get; set; }

        public PickSlotsStatusVm PickSlotsStatus
        {
            get
            {
                return this.pickSlotsStatus;
            }
        }
    }
}

