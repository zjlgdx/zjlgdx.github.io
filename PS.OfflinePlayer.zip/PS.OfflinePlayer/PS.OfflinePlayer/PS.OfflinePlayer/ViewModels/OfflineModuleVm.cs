﻿namespace PS.OfflinePlayer.ViewModels
{
    using System;
    using System.ComponentModel;
    using System.Windows;

    using SilverlightClientLib.Infrastructure.Notifications;
    using SilverlightClientLib.Infrastructure.Shared;
    using SilverlightClientLib.Models.OfflineModuleModel;

    public class OfflineModuleVm : ModelWithNotificationBase<OfflineModuleVm>
    {
        #region Fields

        private readonly string courseId;
        private readonly string courseTitle;
        private readonly string durationText;
        private readonly OfflineModule module;
        private readonly string moduleId;
        private readonly string moduleTitle;

        #endregion Fields

        #region Constructors

        public OfflineModuleVm(OfflineModule module, string courseTitle, string courseId, string moduleId, string moduleTitle, string durationText)
        {
            this.module = module;
            this.courseTitle = courseTitle;
            this.courseId = courseId;
            this.moduleId = moduleId;
            this.moduleTitle = moduleTitle;
            this.durationText = durationText;
            if (module == null)
            {
                throw new ArgumentNullException("module");
            }
            module.PropertyChanged += new PropertyChangedEventHandler(this.module_PropertyChanged);
        }

        #endregion Constructors

        #region Properties

        public string CourseId
        {
            get
            {
                return this.courseId;
            }
        }

        public string CourseTitle
        {
            get
            {
                return this.courseTitle;
            }
        }

        public string DurationText
        {
            get
            {
                return this.durationText;
            }
        }

        public string ExpiryText
        {
            get
            {
                if (!this.module.IsExpired)
                {
                    return ("Expires in " + ((TimeSpan) (this.module.ExpirationDateUtc - DateTime.UtcNow)).HowLongDescription());
                }
                return "Expired";
            }
        }

        public string FileSize
        {
            get
            {
                return FormatAsMB(new long?(this.module.TotalClipSizeInBytes));
            }
        }

        public Visibility FileSizeVisibility
        {
            get
            {
                if (!this.IsReadyToPlay)
                {
                    return Visibility.Visible;
                }
                return Visibility.Collapsed;
            }
        }

        public bool IsReadyToPlay
        {
            get
            {
                return (this.module.FetchState == FetchState.FetchComplete);
            }
        }

        public bool IsRemoveButtonEnabled
        {
            get
            {
                return (this.module.FetchState != FetchState.FetchInProgress);
            }
        }

        public string ModuleId
        {
            get
            {
                return this.moduleId;
            }
        }

        public string ModuleTitle
        {
            get
            {
                return this.moduleTitle;
            }
        }

        public Visibility PlayButtonVisibility
        {
            get
            {
                if (!this.IsReadyToPlay)
                {
                    return Visibility.Collapsed;
                }
                return Visibility.Visible;
            }
        }

        public int ProgressPercentage
        {
            get
            {
                return this.module.FetchProgress;
            }
        }

        public Visibility ProgressVisibility
        {
            get
            {
                if (this.module.FetchState != FetchState.FetchComplete)
                {
                    return Visibility.Visible;
                }
                return Visibility.Collapsed;
            }
        }

        public string Tag
        {
            get
            {
                return "{0}:{1}".FormatWith(new object[] { this.CourseId, this.ModuleId });
            }
        }

        #endregion Properties

        #region Methods

        private static string FormatAsMB(long? byteCount)
        {
            if (byteCount.HasValue)
            {
                object[] args = new object[] { byteCount / 0x100000L };
                return "{0} MB".FormatWith(args);
            }
            return "";
        }

        private void module_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.NotifyEntireModelChanged();
        }

        #endregion Methods
    }
}