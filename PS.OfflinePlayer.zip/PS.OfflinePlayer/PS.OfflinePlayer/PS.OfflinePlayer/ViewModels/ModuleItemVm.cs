﻿namespace PS.OfflinePlayer.ViewModels
{
    using System.Windows;

    using SilverlightClientLib.Infrastructure.Shared;

    public class ModuleItemVm : DependencyObject
    {
        #region Properties

        public Visibility ChooseButtonVisibility
        {
            get; set;
        }

        public string CourseId
        {
            get; set;
        }

        public string ModuleId
        {
            get; set;
        }

        public string ModuleTitle
        {
            get; set;
        }

        public string Tag
        {
            get
            {
                return "{0}:{1}".FormatWith(new object[] { this.CourseId, this.ModuleId });
            }
        }

        #endregion Properties
    }
}