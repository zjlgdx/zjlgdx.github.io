﻿namespace PS.OfflinePlayer.ViewModels
{
    #region Enumerations

    public enum ViewType
    {
        None,
        Install,
        Player,
        Primary
    }

    #endregion Enumerations
}