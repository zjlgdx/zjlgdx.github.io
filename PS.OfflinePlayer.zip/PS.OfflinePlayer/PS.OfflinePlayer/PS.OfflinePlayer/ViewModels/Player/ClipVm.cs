﻿namespace PS.OfflinePlayer.ViewModels.Player
{
    public class ClipVm
    {
        #region Fields

        public bool MayBeViewed;
        public string Title;
        public bool UserHasViewed;
        public string VideoFilePath;
        public long VideoFileSize;
        public int VideoLengthInSeconds;

        #endregion Fields
    }
}