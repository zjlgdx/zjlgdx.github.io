﻿namespace PS.OfflinePlayer.ViewModels.Player
{
    using System;
    using System.Linq;

    using SilverlightClientLib.Infrastructure.Shared;
    using SilverlightClientLib.Models.CatalogModel;
    using SilverlightClientLib.Models.OfflineModuleModel;

    public class ModuleVmBuilder
    {
        #region Fields

        private readonly string courseId;
        private readonly string moduleId;

        private Module module;
        private OfflineModule offlineModule;

        #endregion Fields

        #region Constructors

        public ModuleVmBuilder(string courseId, string moduleId)
        {
            this.courseId = courseId;
            this.moduleId = moduleId;
        }

        #endregion Constructors

        #region Methods

        public ModuleVm BuildModuleVm()
        {
            this.module = this.FindModuleInCatalog();
            this.offlineModule = this.FindOfflineModuleInManifest();
            return new ModuleVm { CourseId = this.courseId, ModuleRef = this.AssembleModuleRef(), Title = this.module.Title, Duration = this.module.Duration, Clips = this.AssembleClips() };
        }

        private ClipVm[] AssembleClips()
        {
            return this.module.Clips.Select<Clip, ClipVm>(new Func<Clip, ClipVm>(this.AssembleClipVm)).ToArray<ClipVm>();
        }

        private ClipVm AssembleClipVm(Clip clip)
        {
            return new ClipVm { MayBeViewed = true, UserHasViewed = false, Title = clip.Title, VideoFilePath = this.AssembleVideoFilePath(clip.ClipIndex), VideoLengthInSeconds = (int) clip.Duration.TotalSeconds, VideoFileSize = this.AssembleVideoFileSize(clip.ClipIndex) };
        }

        private ModuleRefVm AssembleModuleRef()
        {
            string[] strArray = this.moduleId.Split(new char[] { '/' });
            if (strArray.Length != 2)
            {
                throw new FormatException("Malformed module id: " + this.moduleId);
            }
            return new ModuleRefVm { Author = strArray[0], Name = strArray[1] };
        }

        private string AssembleVideoFilePath(int clipIndex)
        {
            OfflineClip offlineClip = this.GetOfflineClip(clipIndex);
            if (!offlineClip.LocalFileName.HasContent())
            {
                throw new InvalidOperationException("Offline clip {0}/{1} has not been fetched".FormatWith(new object[] { this.module.Id, clipIndex }));
            }
            return Paths.LocalClipPath(offlineClip.LocalFileName);
        }

        private long AssembleVideoFileSize(int clipIndex)
        {
            OfflineClip offlineClip = this.GetOfflineClip(clipIndex);
            if (!offlineClip.LocalFileName.HasContent())
            {
                throw new InvalidOperationException("Offline clip {0}/{1} has not been fetched".FormatWith(new object[] { this.module.Id, clipIndex }));
            }
            return offlineClip.FileSizeInBytes.ValueOrDefault<long>();
        }

        private Module FindModuleInCatalog()
        {
            Module module = Catalog.Instance.FindModule(this.moduleId);
            if (module == null)
            {
                throw new InvalidOperationException("Module not found: " + this.moduleId);
            }
            return module;
        }

        private OfflineModule FindOfflineModuleInManifest()
        {
            OfflineModule module = OfflineModuleManifest.Instance.FindModule(this.moduleId);
            if (module == null)
            {
                throw new InvalidOperationException("OfflineModule not found in maniest: " + this.moduleId);
            }
            return module;
        }

        private OfflineClip GetOfflineClip(int clipIndex)
        {
            OfflineClip clip = this.offlineModule.OfflineClips.Skip<OfflineClip>(clipIndex).FirstOrDefault<OfflineClip>();
            if (clip == null)
            {
                throw new InvalidOperationException("Couldn't find offline clip with index {0} (offlineModule clip count = {1})".FormatWith(new object[] { clipIndex, this.offlineModule.OfflineClips.Count<OfflineClip>() }));
            }
            return clip;
        }

        #endregion Methods
    }
}