﻿namespace PS.OfflinePlayer.ViewModels.Player
{
    using System;

    public class ModuleVm
    {
        #region Fields

        public ClipVm[] Clips;
        public string CourseId;
        public TimeSpan Duration;
        public ModuleRefVm ModuleRef;
        public string Title;

        #endregion Fields
    }
}