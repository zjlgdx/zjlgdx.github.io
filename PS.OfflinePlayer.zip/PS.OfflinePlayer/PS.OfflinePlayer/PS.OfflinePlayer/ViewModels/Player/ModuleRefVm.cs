﻿namespace PS.OfflinePlayer.ViewModels.Player
{
    public class ModuleRefVm
    {
        #region Fields

        public string Author;
        public string Name;

        #endregion Fields

        #region Methods

        public string ToModuleId()
        {
            return string.Format("{0}/{1}", this.Author, this.Name);
        }

        #endregion Methods
    }
}