﻿namespace PS.OfflinePlayer.ViewModels
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Linq;

    using SilverlightClientLib.Infrastructure.Shared;
    using SilverlightClientLib.Models.CatalogModel;
    using SilverlightClientLib.Models.OfflineModuleModel;

    public static class OfflineModuleVmAssembler
    {
        #region Methods

        public static ObservableCollection<OfflineModuleVm> AssembleOfflineModuleVms()
        {
            ObservableCollection<OfflineModuleVm> modules = new ObservableCollection<OfflineModuleVm>(OfflineModuleManifest.Instance.OfflineModules.Select<OfflineModule, OfflineModuleVm>(new Func<OfflineModule, OfflineModuleVm>(OfflineModuleVmAssembler.AssembleOfflineModuleVm)).SkipNulls<OfflineModuleVm>().ToArray<OfflineModuleVm>());
            SortOfflineModuleVms(modules);
            return modules;
        }

        public static void UpdateOfflineModulesOnModelCollectionChanged(ObservableCollection<OfflineModuleVm> offlineModules, IList oldItems, IList newItems)
        {
            if (oldItems != null)
            {
                RemoveOldItems(offlineModules, oldItems);
            }
            if (newItems != null)
            {
                AddNewItems(offlineModules, newItems);
            }
        }

        private static void AddNewItems(ICollection<OfflineModuleVm> offlineModules, IList newItems)
        {
            foreach (OfflineModule module in newItems)
            {
                OfflineModuleVm item = AssembleOfflineModuleVm(module);
                offlineModules.Add(item);
            }
        }

        private static string AssembleCourseTitle(string courseId)
        {
            Course course = Catalog.Instance.FindCourse(courseId);
            if (course != null)
            {
                return course.Title;
            }
            return "";
        }

        private static OfflineModuleVm AssembleOfflineModuleVm(OfflineModule offlineModule)
        {
            Module module = Catalog.Instance.FindModule(offlineModule.ModuleId);
            if (module == null)
            {
                return null;
            }
            string courseTitle = AssembleCourseTitle(offlineModule.CourseId);
            string courseId = offlineModule.CourseId;
            string moduleId = offlineModule.ModuleId;
            string title = module.Title;
            return new OfflineModuleVm(offlineModule, courseTitle, courseId, moduleId, title, "[{0}]".FormatWith(new object[] { module.Duration }));
        }

        private static void RemoveOldItems(ICollection<OfflineModuleVm> offlineModules, IList oldItems)
        {
            IEnumerator enumerator = oldItems.GetEnumerator();
            try
            {
                Func<OfflineModuleVm, bool> predicate = null;
                OfflineModule oldItem;
                while (enumerator.MoveNext())
                {
                    oldItem = (OfflineModule)enumerator.Current;
                    if (predicate == null)
                    {
                        predicate = x => (x.ModuleId == oldItem.ModuleId) && (oldItem.CourseId == x.CourseId);
                    }
                    OfflineModuleVm item = offlineModules.FirstOrDefault<OfflineModuleVm>(predicate);
                    if (item != null)
                    {
                        offlineModules.Remove(item);
                    }
                }
            }
            finally
            {
                IDisposable disposable = enumerator as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
            }
        }

        private static IEnumerable<OfflineModuleVm> SortModules(IEnumerable<OfflineModuleVm> modules)
        {
            string courseId = modules.First<OfflineModuleVm>().CourseId;
            Course course = Catalog.Instance.FindCourse(courseId);
            if (course == null)
            {
                return Enumerable.Empty<OfflineModuleVm>();
            }

            Dictionary<string, int> mapModuleToOrdinal = course.ModuleIds
                .Select((((moduleId, index) => new { moduleId = moduleId, index = index })))
                .ToDictionary(x => x.moduleId, x => x.index);
            return (from x in modules
                    orderby mapModuleToOrdinal[x.ModuleId]
                    select x);
        }

        private static void SortOfflineModuleVms(ObservableCollection<OfflineModuleVm> modules)
        {
            IGrouping<string, OfflineModuleVm>[] source = (from x in modules
                                                           group x by x.CourseTitle into x
                                                           orderby x.Key
                                                           select x).ToArray<IGrouping<string, OfflineModuleVm>>();
            List<OfflineModuleVm> items = new List<OfflineModuleVm>();
            foreach (IEnumerable<OfflineModuleVm> enumerable in source.Select<IGrouping<string, OfflineModuleVm>, IEnumerable<OfflineModuleVm>>(new Func<IGrouping<string, OfflineModuleVm>, IEnumerable<OfflineModuleVm>>(OfflineModuleVmAssembler.SortModules)))
            {
                items.AddRange(enumerable);
            }
            modules.Clear();
            modules.AddRange<OfflineModuleVm>(items);
        }

        #endregion Methods
    }
}