﻿namespace PS.OfflinePlayer.ViewModels
{
    public static class Constants
    {
        #region Fields

        public const string InstallWindowName = "Install";
        public const string MainWindowName = "Main";
        public const string MobileFaqUrl = "http://support.pluralsight.com/knowledgebase/topics/3887-mobile-players-and-offline-viewing";
        public const string PlayerWindowName = "Player";

        #endregion Fields
    }
}