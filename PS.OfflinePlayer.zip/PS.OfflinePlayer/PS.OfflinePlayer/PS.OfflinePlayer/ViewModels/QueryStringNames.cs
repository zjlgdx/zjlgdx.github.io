﻿namespace PS.OfflinePlayer.ViewModels
{
    public static class QueryStringNames
    {
        #region Fields

        public const string Id = "id";

        #endregion Fields
    }
}