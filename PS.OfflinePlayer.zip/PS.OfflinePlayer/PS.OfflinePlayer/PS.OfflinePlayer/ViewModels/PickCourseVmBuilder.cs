﻿namespace PS.OfflinePlayer.ViewModels
{
    using SilverlightClientLib.Infrastructure.Shared;
    using SilverlightClientLib.Models.OfflineModuleModel;

    public class PickCourseVmBuilder
    {
        internal static string AssembleChooseProse()
        {
            OfflineModuleManifest instance = OfflineModuleManifest.Instance;
            string formatString = instance.OfflineModules.IsEmpty<OfflineModule>() ? "Choose up to {0}" : "You may choose {0} more";
            return (formatString.FormatWith(new object[] { instance.NumSlotsLeft }) + " module(s) for offline viewing.");
        }

        public PickCourseVm BuildPickCourseVm()
        {
            PickCategorizedCourseItemVmBuilder builder = new PickCategorizedCourseItemVmBuilder();
            return new PickCourseVm { Categories = builder.BuildPickCategorizedCourseItemVms() };
        }
    }
}

