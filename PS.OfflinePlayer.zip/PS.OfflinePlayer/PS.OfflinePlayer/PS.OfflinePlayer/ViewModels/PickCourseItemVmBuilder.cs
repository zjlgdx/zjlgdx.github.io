﻿namespace PS.OfflinePlayer.ViewModels
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using SilverlightClientLib.Infrastructure.Shared;
    using SilverlightClientLib.Models.CatalogModel;

    public class PickCourseItemVmBuilder
    {
        #region Methods

        public PickCourseItemVm BuildPickCourseItemVm(Course course)
        {
            return new PickCourseItemVm { Title = course.Title, Id = course.Id, Level = course.Level, Author = this.AssembleAuthorDisplayName(course.ModuleIds), AuthorTooltip = this.AssembleAuthorTooltip(course.ModuleIds), Duration = "[{0}]".FormatWith(new object[] { course.Duration }), Description = course.Description };
        }

        private static string[] GetAuthorNames(IEnumerable<string> moduleIds)
        {
            ICatalog instance = Catalog.Instance;
            return (from module in moduleIds.Select<string, Module>(new Func<string, Module>(instance.FindModule)).SkipNulls<Module>() select module.AuthorDisplayName).Distinct<string>().ToArray<string>();
        }

        private string AssembleAuthorDisplayName(IEnumerable<string> moduleIds)
        {
            string[] authorNames = GetAuthorNames(moduleIds);
            if (authorNames.Count<string>() == 0)
            {
                return "";
            }
            if (1 == authorNames.Count<string>())
            {
                return authorNames.First<string>();
            }
            return (authorNames.First<string>() + ", et al.");
        }

        private string AssembleAuthorTooltip(IEnumerable<string> moduleIds)
        {
            string[] authorNames = GetAuthorNames(moduleIds);
            return ("Authors: " + string.Join(", ", authorNames));
        }

        #endregion Methods
    }
}